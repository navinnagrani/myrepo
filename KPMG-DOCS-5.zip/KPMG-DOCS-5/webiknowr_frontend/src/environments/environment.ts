// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
 firebaseConfig : {
    apiKey: "AIzaSyCRQPQ3XasR8zyQTt-07CFXbj3KE44tkHI",
    authDomain: "webiknowr-4eaed.firebaseapp.com",
    databaseURL: "https://webiknowr-4eaed.firebaseio.com",
    projectId: "webiknowr-4eaed",
    storageBucket: "webiknowr-4eaed.appspot.com",
    messagingSenderId: "917648645378",
    appId: "1:917648645378:web:2d8183ba96db65b08fb61b",
    measurementId: "G-0B3P8PJVGK"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
