import { AngularFirestore } from '@angular/fire/firestore';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ContactSuccessComponent } from './../dialogs/contact-success/contact-success.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  myForm: FormGroup;

  constructor( private dialog: MatDialog, private fb:FormBuilder,private afs:AngularFirestore) { }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      name:['',[Validators.required]],
      email:['',[Validators.required, Validators.email]],
      message:['',[Validators.required]]
     
    })
  }

  openDialog() {

    const dialogConfig = new MatDialogConfig();
  
   // dialogConfig.disableClose = true;
   // dialogConfig.autoFocus = true;
   
  
    this.dialog.open(ContactSuccessComponent, dialogConfig);
   
  }

  submitForm(){

    this.afs.collection('contact').add(this.myForm.value);
    this.myForm.reset();
    this.openDialog();
  }
  
}
