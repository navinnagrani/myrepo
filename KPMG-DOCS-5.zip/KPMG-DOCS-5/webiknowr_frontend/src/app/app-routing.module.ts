import { WatchComponent } from './watch/watch/watch.component';
import { ProfileComponent } from './user/dashboard/profile/profile.component';
import { AttendeeComponent } from './user/dashboard/attendee/attendee.component';
import { HostSuccessComponent } from './dialogs/host-success/host-success.component';
import { FaqComponent } from './faq/faq.component';
import { DashboardHostOrganizerComponent } from './user/dashboard/host/organizer/organizer.component';
import { DashboardHomeComponent } from './user/dashboard/home/home.component';
import { TimelineComponent } from './user/dashboard/host/timeline/timeline.component';
import { HostDashboardComponent } from './user/host-dashboard/host-dashboard.component';
import { DashboardComponent } from './user/dashboard/dashboard.component';
import { AuthService } from './service/auth.service';
import { CategoryComponent } from './webinar/category/category.component';
import { UserProfileComponent } from './user/user-profile/user-profile.component';
import { HostGuestComponent } from './host/host-guest/host-guest.component';
import { WebinarDetailsComponent } from './webinar-details/webinar-details.component';
import { HostComponent } from './host/host/host.component';
import { AllSpeakerComponent } from './home/popular-speaker/all-speaker/all-speaker.component';
import { AllEventsComponent } from './home/upcoming-events/all-events/all-events.component';
import { PopularSpeakerComponent } from './home/popular-speaker/popular-speaker.component';
import { NavigationComponent } from './navigation/navigation/navigation.component';
import { HomeComponent } from './home/home/home.component';
import { LoginComponent } from './login/login/login.component';
import { ListenComponent } from './listen/listen/listen.component';
import { NgModule } from '@angular/core';
import { PreloadAllModules,Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { RecommendationSearchComponent } from './home/recommendation-search/recommendation-search.component';
import { PodcastComponent } from './listen/podcast/podcast.component';
import { StoriesComponent } from './listen/stories/stories.component';
import { AngularFireAuthGuard, redirectLoggedInTo, redirectUnauthorizedTo } from '@angular/fire/auth-guard';
import { IndustryComponent } from './webinar/industry/industry.component';
import { AdminComponent } from './admin/admin.component';
import { SummaryComponent } from './user/dashboard/host/summary/summary.component';
import { DashboardHostSpeakersComponent } from './user/dashboard/host/speakers/speakers.component';
import { DashboardHostScheduleComponent } from './user/dashboard/host/dashboard-host-schedule/dashboard-host-schedule.component';
import { DashboardHostRegistrantsComponent } from './user/dashboard/host/dashboard-host-registrants/dashboard-host-registrants.component';
import { CreateProfileComponent } from './login/create-profile/create-profile.component';

const redirectUnauthorizedToHostGuest = () => redirectUnauthorizedTo(['host/guest']);
const redirectLoggedInToAttend = () => redirectLoggedInTo(['attend']);
const redirectLoggedInToHost = () => redirectLoggedInTo(['host']);

const redirectUnauthorizedUserProfile = () => redirectUnauthorizedTo(['login']);
const redirectLoggedInUserProfile = () => redirectLoggedInTo(['user/dashboard/home']);
var hostUserId:string;
const routes: Routes = [
  {
    path : 'home',
  
    component : HomeComponent 
  },
  {
    path : '',
    component : HomeComponent 
  },
  {
    path : 'attend',
    component : AllEventsComponent
  },
  {
    path : 'home/attend',
    component : AllEventsComponent
  }
  ,
  {
    path : 'webinar/:id',
    component : WebinarDetailsComponent
  },
  {
    path : 'host',
    component : HostComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectUnauthorizedToHostGuest ,
      redirectLoggedInToHost}
  },
  {
    path : 'host/guest',
    component : HostGuestComponent,
 
  },
  {
    path : 'host/guest/login',
    component : LoginComponent,
 
  },
  {
    path : 'speakers',
    component : AllSpeakerComponent
  },
  {
    path : 'contact',
    component : ContactComponent
  },
  {
    path : 'login',
    component : LoginComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectLoggedInUserProfile }
  },
  {
    path : 'login/create-profile',
    component : CreateProfileComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: redirectUnauthorizedUserProfile }
     
  },
  {
    path : 'host/login',
    component : LoginComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectLoggedInToHost }
  }
  ,
  {
    path : 'user-profile',
    component : UserProfileComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectUnauthorizedUserProfile }
  },
  {
    path : 'user-profile/host',
    component : HostComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectUnauthorizedUserProfile }
  },
  {
    path : 'user-profile/:id',
    component : UserProfileComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectUnauthorizedUserProfile }
  },
  {
    path : 'category/:name',
    component : CategoryComponent,
   
  },
  {
    path : 'industry/:name',
    component : IndustryComponent,
  
  }
  ,
  {
    path : 'admin',
    component : AdminComponent,
    canActivate: [AngularFireAuthGuard],
     data: { authGuardPipe: redirectUnauthorizedUserProfile }
  
  },
  {
    path : 'user/dashboard',
    component : DashboardComponent,
    children: [
      {
        path: 'home',
        component: DashboardHomeComponent,
    },
      {
          path: 'host',
          component: TimelineComponent,
          
      },{
        path: 'host/summary',
        component: SummaryComponent
    },{
      path: 'host/summary/organizer',
      component: DashboardHostOrganizerComponent
  },{
    path: 'host/summary/speakers',
    component: DashboardHostSpeakersComponent
},{
  path: 'host/summary/schedule',
  component: DashboardHostScheduleComponent
},{
  path: 'host/summary/registrants',
  component: DashboardHostRegistrantsComponent
},
{
  path: 'attendee',
  component: AttendeeComponent,
  
},
{
  path: 'attendee/webinar/:id',
  component: WebinarDetailsComponent,
  
},{
  path: 'profile',
  component: ProfileComponent,
  
}
  ],
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: redirectUnauthorizedUserProfile }
  },
  {
    path : 'user/host-dashboard',
    component : HostDashboardComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: redirectUnauthorizedUserProfile }
    
  },
  {
    path : 'faq',
    component : FaqComponent,
   
  },
  {
    path : 'watch',
    component : WatchComponent
  },
  {
    path : 'home/watch',
    component : WatchComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'top', initialNavigation: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { 

  constructor(){
    /*
    let user=JSON.parse(localStorage.getItem('user'));
    hostUserId=user.uid;
    */
  }
}
