import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-speaker-all',
  templateUrl: './speaker-all.component.html',
  styleUrls: ['./speaker-all.component.css']
})
export class SpeakerAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
