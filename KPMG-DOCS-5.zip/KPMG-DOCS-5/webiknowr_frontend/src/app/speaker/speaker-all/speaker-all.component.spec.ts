import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpeakerAllComponent } from './speaker-all.component';

describe('SpeakerAllComponent', () => {
  let component: SpeakerAllComponent;
  let fixture: ComponentFixture<SpeakerAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpeakerAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpeakerAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
