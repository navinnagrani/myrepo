import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHostSpeakersComponent } from './speakers.component';

describe('SpeakersComponent', () => {
  let component: DashboardHostSpeakersComponent;
  let fixture: ComponentFixture<DashboardHostSpeakersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHostSpeakersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHostSpeakersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
