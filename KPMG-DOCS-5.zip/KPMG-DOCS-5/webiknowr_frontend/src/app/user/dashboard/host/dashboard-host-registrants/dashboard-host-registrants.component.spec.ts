import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHostRegistrantsComponent } from './dashboard-host-registrants.component';

describe('DashboardHostRegistrantsComponent', () => {
  let component: DashboardHostRegistrantsComponent;
  let fixture: ComponentFixture<DashboardHostRegistrantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHostRegistrantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHostRegistrantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
