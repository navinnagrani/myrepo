import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHostOrganizerComponent } from './organizer.component';

describe('DashboardHostOrganizerComponent', () => {
  let component: DashboardHostOrganizerComponent;
  let fixture: ComponentFixture<DashboardHostOrganizerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHostOrganizerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHostOrganizerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
