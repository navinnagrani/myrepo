import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHostScheduleComponent } from './dashboard-host-schedule.component';

describe('DashboardHostScheduleComponent', () => {
  let component: DashboardHostScheduleComponent;
  let fixture: ComponentFixture<DashboardHostScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHostScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHostScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
