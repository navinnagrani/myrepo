import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardHostSettingsComponent } from './dashboard-host-settings.component';

describe('DashboardHostSettingsComponent', () => {
  let component: DashboardHostSettingsComponent;
  let fixture: ComponentFixture<DashboardHostSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardHostSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardHostSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
