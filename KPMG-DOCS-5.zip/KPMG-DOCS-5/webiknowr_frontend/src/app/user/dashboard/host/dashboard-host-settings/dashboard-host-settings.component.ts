import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-host-settings',
  templateUrl: './dashboard-host-settings.component.html',
  styleUrls: ['./dashboard-host-settings.component.css']
})
export class DashboardHostSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
