import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';
import { Webinar } from 'src/app/interfaces/webinars.model';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {

  webinarsCollection: AngularFirestoreCollection<Webinar>;
  constructor(private firestore: AngularFirestore) { 
    this.webinarsCollection=firestore.collection("webinars");
  }

  deleteWebinar(webinar:Webinar){
   // this.firestore.collection("webinars-users-mapping").doc(`webinar/${webinar.id}`).delete();
    return this.webinarsCollection.doc(webinar.id.toString()).delete();
  }
}
