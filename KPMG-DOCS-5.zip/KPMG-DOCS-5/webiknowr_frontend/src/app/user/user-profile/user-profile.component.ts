import { CommunicationServiceService } from './../../service/communication-service.service';
import { ActivatedRoute } from '@angular/router';
import { UserProfileService } from './user-profile.service';
import { Webinar } from './../../interfaces/webinars.model';
import { AllEventService } from './../../home/upcoming-events/all-events/all-event.service';
import { Observable } from 'rxjs';
import { User } from './../../interfaces/user.model';
import { AuthService } from './../../service/auth.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  status:string;
  searchText: string;
  webinars: Array<Webinar>=[];
  originalWebinarList: Webinar[];
  id:string;
  filteredWebinars: Array<Webinar>; 
  constructor(public authService:AuthService,public allEventService:AllEventService,
    public userProfileService:UserProfileService, private route: ActivatedRoute, private commService:CommunicationServiceService) { 

  

  }

  async ngOnInit(): Promise<void> {

    this.id = this.route.snapshot.paramMap.get('id');

    const user=await this.authService.isLoggedIn();

    console.log(user.uid);
    this.allEventService.getWebinarsOfHost(user.uid).subscribe(data =>{
     // console.log(data);
      this.webinars=data;
      this.originalWebinarList=this.webinars;
     // console.log(this.originalWebinarList);
    });

    this.commService.searchText=null;
    this.commService.categoryName=null;
    this.commService.industryName=null;
  }

  filterByStatus(status){
    console.log(status);
    this.webinars=this.originalWebinarList;
    if(status=='All'){
      return;
    }
   this.filteredWebinars=this.webinars.filter(data=>{
      
      if(data.status==status){
        return data;
      }
    });
    console.log(this.filteredWebinars);

    this.webinars=this.filteredWebinars;
  }

  calculateStatusClass(status){

    if(status=='Approved'){
      return 'status-approved';
    }else if(status=='Rejected'){
      return 'status-rejected';
    }if(status=='Awaiting Approval'){
      return 'status-pending';
    }
  }

  delete(webinar){
    if(confirm("Do you really want to delete the webinar")){
      console.log("delete");
      this.userProfileService.deleteWebinar(webinar);

    
    }
  }
}
