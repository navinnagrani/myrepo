import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-host-dashboard',
  templateUrl: './host-dashboard.component.html',
  styleUrls: ['./host-dashboard.component.css']
})
export class HostDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
