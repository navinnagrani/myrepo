import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snackbar',
  templateUrl: './snackbar.component.html',
  styles: [`
  .snackbar{
    color: white;
  }
`]
})
export class SnackbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
