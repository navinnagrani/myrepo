import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostGuestComponent } from './host-guest.component';

describe('HostGuestComponent', () => {
  let component: HostGuestComponent;
  let fixture: ComponentFixture<HostGuestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostGuestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostGuestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
