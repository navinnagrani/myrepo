import { BackendService } from './service/backend.service';
import { DashboardHomeComponent } from './user/dashboard/home/home.component';
import { AdminService } from './admin/admin.service';
import { environment } from './../environments/environment.prod';
import { AllEventService } from './home/upcoming-events/all-events/all-event.service';
import { BrowserModule, Meta,Title } from '@angular/platform-browser';
import { NgModule ,ModuleWithProviders} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatButtonModule} from '@angular/material/button';

import { FlexLayoutModule } from '@angular/flex-layout';
import { RecommendationSearchComponent } from './home/recommendation-search/recommendation-search.component';
import { ContactComponent } from './contact/contact.component';
import {MatCardModule} from '@angular/material/card';
import { PopularSpeakerComponent } from './home/popular-speaker/popular-speaker.component';
import { UpcomingEventsComponent } from './home/upcoming-events/upcoming-events.component';
import { SearchComponent } from './search/search.component';
import {MatMenuModule} from '@angular/material/menu';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatChipsModule} from '@angular/material/chips';
import { FooterComponent } from './footer/footer.component';
import { WebinarDetailsComponent } from './webinar-details/webinar-details.component';
import { HomeComponent } from './home/home/home.component';
import { ListenComponent } from './listen/listen/listen.component';
import { LoginComponent } from './login/login/login.component';
import { WatchComponent } from './watch/watch/watch.component';
import { NavigationComponent } from './navigation/navigation/navigation.component';
import { SpeakerAllComponent } from './speaker/speaker-all/speaker-all.component';
import { WebinarAllComponent } from './watch/webinar-all/webinar-all.component';
import { WebinarDetailComponent } from './watch/webinar-detail/webinar-detail.component';
import { CommentsComponent } from './watch/webinar-detail/comments/comments.component';
import { WebinarRecommendationComponent } from './watch/webinar-detail/webinar-recommendation/webinar-recommendation.component';
import { AllEventsComponent } from './home/upcoming-events/all-events/all-events.component';
import { AllSpeakerComponent } from './home/popular-speaker/all-speaker/all-speaker.component';
import { PodcastComponent } from './listen/podcast/podcast.component';
import { StoriesComponent } from './listen/stories/stories.component';
import { HostComponent } from './host/host/host.component';
import {MatInputModule} from '@angular/material/input';
import { SearchPipe } from './home/upcoming-events/search.pipe';
import {MatSelectModule} from '@angular/material/select';
import {MatDialogModule} from "@angular/material/dialog";
import { DialogComponent } from './home/dialog/dialog.component';
import { WebinarDialogComponent } from './home/dialog/webinar-dialog/webinar-dialog.component';
import {MatStepperModule} from '@angular/material/stepper';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatRadioModule} from '@angular/material/radio';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import { SnackbarComponent } from './host/host/snackbar/snackbar.component';
import { NgImageSliderModule } from 'ng-image-slider';
import { NgxAuthFirebaseUIModule } from 'ngx-auth-firebaseui';
import { HostGuestComponent } from './host/host-guest/host-guest.component';
import { UserProfileComponent } from './user/user-profile/user-profile.component';
import { HttpClientModule } from '@angular/common/http';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { FeaturedEventsComponent } from './home/featured-events/featured-events.component';

import { NguCarouselModule } from '@ngu/carousel';
import { CategoryComponent } from './webinar/category/category.component';
import { IndustryComponent } from './webinar/industry/industry.component';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import { ShareComponent } from './dialogs/share/share.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { LoginPopupComponent } from './dialogs/login-popup/login-popup.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { HostSuccessComponent } from './dialogs/host-success/host-success.component';
import { HeadingComponent } from './home/heading/heading.component';
import { NgMatSearchBarModule } from 'ng-mat-search-bar';
import { NgxPaginationModule } from 'ngx-pagination';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { NgxFeedbackModule } from 'ngx-feedback';
import { FeedbackComponent } from './dialogs/feedback/feedback.component';
import { ContactSuccessComponent } from './dialogs/contact-success/contact-success.component';
import { AdminComponent } from './admin/admin.component';
import { MatTableModule } from '@angular/material/table';
import { FilterPipe } from './home/upcoming-events/all-events/filter.pipe';
import { AngularFireAnalyticsModule, ScreenTrackingService, UserTrackingService } from '@angular/fire/analytics';
import { DashboardComponent } from './user/dashboard/dashboard.component';
import { HostDashboardComponent } from './user/host-dashboard/host-dashboard.component';
import { TimelineComponent } from './user/dashboard/host/timeline/timeline.component';
import { SummaryComponent } from './user/dashboard/host/summary/summary.component';
import { DashboardHostOrganizerComponent } from './user/dashboard/host/organizer/organizer.component';
import { DashboardHostSpeakersComponent } from './user/dashboard/host/speakers/speakers.component';
import { DashboardHostScheduleComponent } from './user/dashboard/host/dashboard-host-schedule/dashboard-host-schedule.component';
import { DashboardHostRegistrantsComponent } from './user/dashboard/host/dashboard-host-registrants/dashboard-host-registrants.component';
import { DashboardHostSettingsComponent } from './user/dashboard/host/dashboard-host-settings/dashboard-host-settings.component';
import { FaqComponent } from './faq/faq.component';
import { ClipboardModule, Clipboard } from '@angular/cdk/clipboard'
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { AngularFirePerformanceModule, PerformanceMonitoringService } from '@angular/fire/performance';
import { AttendeeComponent } from './user/dashboard/attendee/attendee.component';
import { ToastrModule } from 'ngx-toastr';
import {NgxImageCompressService} from 'ngx-image-compress';
import { MomentTimezonePickerModule } from 'moment-timezone-picker';
import { LazyLoadImageModule } from 'ng-lazyload-image'; 
import {
  NgxUiLoaderModule,
  NgxUiLoaderConfig,
  SPINNER,
  POSITION,
  PB_DIRECTION
} from 'ngx-ui-loader';
import { ProfileComponent } from './user/dashboard/profile/profile.component';
import { SafePipe } from './safe.pipe';
import { SummaryEditComponent } from './user/dashboard/host/summary/summary-edit/summary-edit.component';
import { WatchRecordingPopupComponent } from './watch/watch-recording-popup/watch-recording-popup.component';
import { NbThemeModule, NbLayoutModule } from '@nebular/theme';
import { NbEvaIconsModule } from '@nebular/eva-icons';
import { QuillModule } from 'ngx-quill';
import { CreateProfileComponent } from './login/create-profile/create-profile.component';
import {NgxIntlTelInputModule} from 'ngx-intl-tel-input';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {NgcCookieConsentModule, NgcCookieConsentConfig} from 'ngx-cookieconsent';
import { CreateProfileSuccessComponent } from './dialogs/create-profile-success/create-profile-success.component';
const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  bgsColor: 'purple',
  fgsColor: 'purple',
  bgsPosition: POSITION.centerCenter,
  bgsSize: 60,
  bgsType: SPINNER.threeStrings, // background spinner type
  fgsType: SPINNER.threeStrings, // foreground spinner type
  pbDirection: PB_DIRECTION.leftToRight, // progress bar direction
  pbThickness: 5 // progress bar thickness
};

const cookieConfig:NgcCookieConsentConfig = {
  cookie: {
    domain: 'localhost' // or 'your.domain.com' // it is mandatory to set a domain, for cookies to work properly (see https://goo.gl/S2Hy2A)
  },
  palette: {
    popup: {
      background: '#000'
    },
    button: {
      background: '#f1d600'
    }
  },
  theme: 'edgeless',
  type: 'opt-out'
};
 

@NgModule({
  declarations: [
    AppComponent,
    RecommendationSearchComponent,
    ContactComponent,
    PopularSpeakerComponent,
    UpcomingEventsComponent,
    SearchComponent,
    FooterComponent,
    WebinarDetailsComponent,
    HomeComponent,
    ListenComponent,
    LoginComponent,
    WatchComponent,
    NavigationComponent,
    SpeakerAllComponent,
    WebinarAllComponent,
    WebinarDetailComponent,
    CommentsComponent,
    WebinarRecommendationComponent,
    AllEventsComponent,
    AllSpeakerComponent,
    PodcastComponent,
    StoriesComponent,
    HostComponent,
    SearchPipe,
    DialogComponent,
    WebinarDialogComponent,
    SnackbarComponent,
    HostGuestComponent,
    UserProfileComponent,
    FeaturedEventsComponent,
    CategoryComponent,
    IndustryComponent,
    ShareComponent,
    LoginPopupComponent,
    HostSuccessComponent,
    HeadingComponent,
    FeedbackComponent,
    ContactSuccessComponent,
    AdminComponent,
    FilterPipe,
    DashboardComponent,
    HostDashboardComponent,
    TimelineComponent,
    DashboardHomeComponent,
    SummaryComponent,
    DashboardHostOrganizerComponent,
    DashboardHostSpeakersComponent,
    DashboardHostScheduleComponent,
    DashboardHostRegistrantsComponent,
    DashboardHostSettingsComponent,
    FaqComponent,
    AttendeeComponent,
    ProfileComponent,
    SafePipe,
    SummaryEditComponent,
    WatchRecordingPopupComponent,
    CreateProfileComponent,
    CreateProfileSuccessComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatSidenavModule,
    MatButtonModule,
    FlexLayoutModule,
    MatCardModule,
    MatMenuModule,
    FormsModule,
    ReactiveFormsModule,
    MatChipsModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    MatStepperModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAnalyticsModule,
    AngularFireDatabaseModule,
    AngularFireStorageModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    MatSnackBarModule,
    NgImageSliderModule,
    NgxAuthFirebaseUIModule.forRoot(environment.firebaseConfig,
      () => 'webiknowr',
     {
       enableFirestoreSync: true, // enable/disable autosync users with firestore
       toastMessageOnAuthSuccess: false, // whether to open/show a snackbar message on auth success - default : true
       toastMessageOnAuthError: false, // whether to open/show a snackbar message on auth error - default : true
      
     }),
    MatCheckboxModule,
    MatExpansionModule,
    MatTabsModule,
    MatTableModule,
    NgImageSliderModule,
    HttpClientModule,
    MatButtonToggleModule,
  
    NguCarouselModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    CarouselModule,
    NgMatSearchBarModule,
    NgxPaginationModule,
    MatSlideToggleModule,
    NgxFeedbackModule,
    MatSortModule,
    ClipboardModule,
    MatAutocompleteModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    ToastrModule.forRoot({
      timeOut: 5000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
  QuillModule.forRoot(),
  NgxIntlTelInputModule,
  FontAwesomeModule,
  NgcCookieConsentModule.forRoot(cookieConfig),
  MomentTimezonePickerModule,
  LazyLoadImageModule
  
    
  ],
  providers: [
    AllEventService,
    AdminService,
    BackendService,
    ScreenTrackingService,
    UserTrackingService,
    Clipboard,
    PerformanceMonitoringService,
    NgxImageCompressService,
    Meta,
    Title,
    {
      provide: STEPPER_GLOBAL_OPTIONS, useValue: {showError: true}
    },{ 
      provide: HAMMER_GESTURE_CONFIG, 
      useClass: HammerGestureConfig 
  }
  ],
  bootstrap: [AppComponent],
  entryComponents: [DialogComponent,WebinarDialogComponent,ShareComponent]
})
export class AppModule { 
 
}
