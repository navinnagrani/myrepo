export interface FeeInfo{
    "feeInINR": string;
    "paid": string;
} 