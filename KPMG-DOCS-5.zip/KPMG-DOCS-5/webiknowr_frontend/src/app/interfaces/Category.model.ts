export interface Category{
    name:string;
}