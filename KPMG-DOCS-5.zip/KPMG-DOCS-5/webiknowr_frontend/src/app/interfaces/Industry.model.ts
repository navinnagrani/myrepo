export interface Industry{
    name: string;
}