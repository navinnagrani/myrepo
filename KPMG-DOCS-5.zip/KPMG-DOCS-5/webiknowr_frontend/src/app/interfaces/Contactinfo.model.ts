export interface Contactinfo{
    "name": string;
    "about":string;
    "profileUrl": string;
    "email": string;
    "mobileNo": string;
    "logo":string;
    "designation":string;
    "creationDate":Date
} 