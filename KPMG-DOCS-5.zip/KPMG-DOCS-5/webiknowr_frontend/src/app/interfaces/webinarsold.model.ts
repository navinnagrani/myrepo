import { Organizer } from './Organizer.model';
import { Speaker } from './Speaker.model';
import { Schedule } from './Schedule.model';
import { Category } from './Category.model';

import { Tag } from '../host/host/host.component';
import { Industry } from './Industry.model';

  export class Webinar {
      id:string;
      title: string;
      img: string;
      schedule:Schedule;
     
      category: Category[];
      industry: Industry[];
      tags:Tag[];
      speakers:Speaker[];
    
      duration:number;
      language:string;
      views:number;
      organizer:Organizer;
      fees:string;
      price:string;
      description:string;
      formLink:string;
      meetingLink:string;
      recorded:string;
      status:string;
      hostUserId:string;
      uniqueId:number;
    }
  
  export const webinars: Webinar[] = [
   
  ];
  