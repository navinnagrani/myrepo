export class Schedule{

    "startDate": string;
    "endDate": string;
    "startTime": string;
    "endTime": string;
    "durationInMinutes": number;
}