export interface Webinarinfo{

    "title": string;
    "description": string;
    "formLink": string;
    "posterUrl": string;
    "meetingLink": string;
}
