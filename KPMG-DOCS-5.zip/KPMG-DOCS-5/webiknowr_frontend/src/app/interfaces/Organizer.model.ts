import { Contactinfo } from './contactinfo.model';
export interface Organizer{

        "id": string;
        "contactInfo": Contactinfo;
}