export interface RecordingInfo{
    "recordingLink": string;
    "recorded": boolean;
    "views":number;
    "duration":number
}