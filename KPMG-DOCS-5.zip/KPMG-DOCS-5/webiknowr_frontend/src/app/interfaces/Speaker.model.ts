import { Contactinfo } from './Contactinfo.model';
export interface Speaker
{
    "id": string;
   
    "contactInfo": Contactinfo;
    
  } 