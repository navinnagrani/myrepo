import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-speaker',
  templateUrl: './all-speaker.component.html',
  styleUrls: ['./all-speaker.component.css']
})
export class AllSpeakerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
