import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllSpeakerComponent } from './all-speaker.component';

describe('AllSpeakerComponent', () => {
  let component: AllSpeakerComponent;
  let fixture: ComponentFixture<AllSpeakerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllSpeakerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllSpeakerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
