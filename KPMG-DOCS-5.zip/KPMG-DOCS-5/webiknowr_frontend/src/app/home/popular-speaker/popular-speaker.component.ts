import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-speaker',
  templateUrl: './popular-speaker.component.html',
  styleUrls: ['./popular-speaker.component.scss']
})
export class PopularSpeakerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

  speakerList =[
    {
      title:'Bill Gates',
      img:'assets/billgates.jpg'
    },
    {
      title:'Amish Tripathi',
      img:'assets/amish.jpg'
    },
    {
      title:'Elon Musk',
      img:'assets/elon.jpg'
    },
    {
      title:'Amish Tripathi',
      img:'assets/amish.jpg'
    },
    {
      title:'Elon Musk',
      img:'assets/elon.jpg'
    }
    ,
    {
      title:'Amish Tripathi',
      img:'assets/amish.jpg'
    }
  ]


  

}
