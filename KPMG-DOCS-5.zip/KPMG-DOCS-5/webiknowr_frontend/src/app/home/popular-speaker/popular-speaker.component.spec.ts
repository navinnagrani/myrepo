import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PopularSpeakerComponent } from './popular-speaker.component';

describe('PopularSpeakerComponent', () => {
  let component: PopularSpeakerComponent;
  let fixture: ComponentFixture<PopularSpeakerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PopularSpeakerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PopularSpeakerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
