import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecommendationSearchComponent } from './recommendation-search.component';

describe('RecommendationSearchComponent', () => {
  let component: RecommendationSearchComponent;
  let fixture: ComponentFixture<RecommendationSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecommendationSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecommendationSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
