import { AllEventService } from './../upcoming-events/all-events/all-event.service';
import { Category } from './../../interfaces/Category.model';
import { CategoryService } from './../../service/category.service';
import { Component, OnInit } from '@angular/core';
import { trigger, transition, animate, style } from '@angular/animations'

@Component({
  selector: 'app-recommendation-search',
  templateUrl: './recommendation-search.component.html',
  styleUrls: ['./recommendation-search.component.scss'],
  animations: [
    trigger('slideAboutMeImage', [
      transition(':enter', [
        style({transform: 'translatex(-100%)'}),
        animate('1000ms ease-in', style({transform: 'translatex(0%)'}))
      ]),
      transition(':leave', [
        animate('1000ms ease-in', style({transform: 'translatex(-100%)'}))
      ])
    ]),
    trigger('slideAboutMeText', [
      transition(':enter', [
        style({transform: 'translatex(100%)'}),
        animate('1000ms ease-in', style({transform: 'translatex(0%)'}))
      ]),
      transition(':leave', [
        animate('1000ms ease-in', style({transform: 'translatex(0%)'}))
      ])
    ]) 
  ]
})
export class RecommendationSearchComponent implements OnInit {

  categories: Category[];
  categoryList =[];
  constructor(private categoryService:CategoryService,private allEventService:AllEventService) { 


  }

  ngOnInit(): void {
    this.categoryService.getCategories().subscribe(data=>{
      console.log(data);
      this.categories=data;
    })
  }

  setAll(event,name){
    console.log(event);
    if(event.checked){
      this.categoryList.push(name);
    }else{
      let i=this.categoryList.indexOf(name);
      console.log(i);
      this.categoryList.splice(i,1);
    }
    console.log(this.categoryList);
  }

  searchForRecommendations(){
    this.allEventService.getWebinars();
  }
}
