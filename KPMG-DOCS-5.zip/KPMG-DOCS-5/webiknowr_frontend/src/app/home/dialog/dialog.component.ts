import { Webinar } from './../../interfaces/webinars.model';
import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  form: FormGroup;
    description:string;

    webinars: Array<Webinar>;
    selectedWebinar:Webinar;
    topicFormControl=new FormControl();
  durationFormControl=new FormControl();
  languageFormControl=new FormControl();
  speakersFormControl=new FormControl();

  topicValue: any[];
  durationValue: any[];
  speakersValue: any[];
  languageValue: any[];

  list5: Array<Webinar> = this.webinars; 
    constructor(
        private fb: FormBuilder,
        private dialogRef: MatDialogRef<DialogComponent>,
        @Inject(MAT_DIALOG_DATA) data) {
          console.log(data);
        this.selectedWebinar = data;
    }

    ngOnInit() {
        this.form = this.fb.group({
            description: [this.description, []]

        });
    }

    save() {
        this.dialogRef.close(this.webinars);
    }

    close() {
        this.dialogRef.close();
    }

    topics=[
      "IT","Artificial Intelligence","Food"
    ]
  
    durationList=[
      "1-5 minutes","5-10 minutes","10-30 minutes","30-60 minutes","1-2 hours",">2 hours"
    ]
  
    speakersList=[
      "Bill Gates","Elon Musk","Sachin Tendulkar","Amish Tripathi"
    ]
  
    languages=[
      "English","Hindi","Marathi"
    ]

    filterTopic(){
      var finalTopicList=[];
      var finalSpeakerList=[];
      var finalDurationList=[];
      var finalLanguageList=[];
   
      var list4=[];
      
       console.log(this.topicValue);
       if(this.topicValue!=undefined){
         for(let i=0;i<this.topicValue.length;i++){  
        
           let num=0;
           console.log(this.topicValue[i]);
           if(!list4.includes(this.topicValue[i]) ){
             console.log('inside');
             for(let k=0;k<this.list5.length;k++){
             console.log(this.list5[k]);
               if(this.topicValue[i]== this.list5[k].category){
                   list4.push(this.topicValue[i]);
                   finalTopicList.push(this.list5[k]);
               }
             }
           }
         }
       }
       
      
       console.log(list4);
       console.log(finalTopicList);
       this.webinars=finalTopicList;
       if(this.topicValue!=undefined){
         if(this.topicValue.length==0){
           this.webinars=this.list5;
         }
       }
   
     //speaker
   
     if(finalTopicList.length>0){
       // 1. selecting first topic 
       this.list5=finalTopicList;
     }else if(finalDurationList.length>0){
       //selecting first speaker
       //selected topic but no topics matched
       this.list5=finalDurationList;
     }else if(finalLanguageList.length>0){
       //selecting first speaker
       //selected topic but no topics matched
       this.list5=finalLanguageList;
     }
       for(let i=0;i<this.speakersValue.length;i++){  
        
         let num=0;
         console.log(this.speakersValue[i]);
         if(!list4.includes(this.speakersValue[i]) ){
           console.log('inside');
           for(let k=0;k<this.list5.length;k++){
           console.log(this.list5[k]);
             if(this.speakersValue[i]== this.list5[k].speakers){
                 list4.push(this.speakersValue[i]);
                 finalSpeakerList.push(this.list5[k]);
             }
           }
         }
       }
   
       console.log(list4);
       console.log(finalSpeakerList);
       this.webinars=finalSpeakerList
       if(this.speakersValue!=undefined){
         if(this.speakersValue.length==0){
           this.webinars=this.list5;
         }
       }
     }
}


