import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebinarDialogComponent } from './webinar-dialog.component';

describe('WebinarDialogComponent', () => {
  let component: WebinarDialogComponent;
  let fixture: ComponentFixture<WebinarDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebinarDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebinarDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
