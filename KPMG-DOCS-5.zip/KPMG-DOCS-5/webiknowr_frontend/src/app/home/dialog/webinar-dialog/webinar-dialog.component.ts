import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webinar-dialog',
  templateUrl: './webinar-dialog.component.html',
  styleUrls: ['./webinar-dialog.component.css']
})
export class WebinarDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
