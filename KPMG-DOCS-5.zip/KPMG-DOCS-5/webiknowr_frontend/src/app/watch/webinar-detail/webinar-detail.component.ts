import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webinar-detail',
  templateUrl: './webinar-detail.component.html',
  styleUrls: ['./webinar-detail.component.css']
})
export class WebinarDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
