import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webinar-recommendation',
  templateUrl: './webinar-recommendation.component.html',
  styleUrls: ['./webinar-recommendation.component.css']
})
export class WebinarRecommendationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
