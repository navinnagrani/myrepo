import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebinarRecommendationComponent } from './webinar-recommendation.component';

describe('WebinarRecommendationComponent', () => {
  let component: WebinarRecommendationComponent;
  let fixture: ComponentFixture<WebinarRecommendationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebinarRecommendationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebinarRecommendationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
