import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebinarAllComponent } from './webinar-all.component';

describe('WebinarAllComponent', () => {
  let component: WebinarAllComponent;
  let fixture: ComponentFixture<WebinarAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebinarAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebinarAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
