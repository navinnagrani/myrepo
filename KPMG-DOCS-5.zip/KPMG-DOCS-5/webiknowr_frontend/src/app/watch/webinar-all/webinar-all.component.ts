import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webinar-all',
  templateUrl: './webinar-all.component.html',
  styleUrls: ['./webinar-all.component.css']
})
export class WebinarAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
