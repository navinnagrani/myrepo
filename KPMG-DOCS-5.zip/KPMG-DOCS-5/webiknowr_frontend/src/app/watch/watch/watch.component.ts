import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Industry } from './../../interfaces/Industry.model';
import { Category } from './../../interfaces/Category.model';
import { ShareComponent } from 'src/app/dialogs/share/share.component';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { CommunicationServiceService } from './../../service/communication-service.service';
import { CategoryService } from './../../service/category.service';
import { Observable, Subscription } from 'rxjs';
import { FormControl } from '@angular/forms';
import { AllEventService } from './../../home/upcoming-events/all-events/all-event.service';
import { MatDialog } from '@angular/material/dialog';
import { Webinar } from './../../interfaces/webinars.model';
import { MatDialogConfig } from '@angular/material/dialog';
import { DialogComponent } from './../../home/dialog/dialog.component';
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { AngularFirestoreCollection } from '@angular/fire/firestore/public_api';
import * as moment from 'moment';
import { IndustryService } from 'src/app/service/industry.service';
import { Router } from '@angular/router';
import { WatchRecordingPopupComponent } from '../watch-recording-popup/watch-recording-popup.component';

@Component({
  selector: 'app-watch',
  templateUrl: './watch.component.html',
  styleUrls: ['./watch.component.scss']
})
export class WatchComponent implements OnInit {

  webinars: Array<Webinar>=[];
  originalWebinars: Array<Webinar>; 
  categories: Array<Category>;
  industries: Array<Industry>;
  allFlag=false;
  todayFlag=false;
  tomorrowFlag=false;
  weekFlag=false;
  config: any;
  sort:any;
  totalLength:number;
  searchText:string;
  priceFilterChecked=true;
  dataSource : MatTableDataSource<Webinar>;
  typeOfWebinar='recording';
  @ViewChild(MatPaginator) paginator: MatPaginator;
    //addedy by preksha for homr to attend page
    @ViewChild("multipleCategories") multipleCategories: any;
    @ViewChild("multipleIndustries") multipleIndustries: any;
  
  todoCollectionRef: AngularFirestoreCollection<Webinar>;
  webinars$: Observable<Webinar>;
cat:Category={
  "name":""
};
  //formcontrols
  topicFormControl=new FormControl();
  durationFormControl=new FormControl();
  languageFormControl=new FormControl();
  speakersFormControl=new FormControl();

  topicValue: any[];
  durationValue: any[];
  speakersValue: any[];
  languageValue: any[];
  priceFilter:string;


  categoryFormControl=new FormControl();
  industryFormControl=new FormControl();
  priceFormControl=new FormControl();
  categoryFilterValue:any[];
  industryFilterValue: any[];
  priceFilterValue: any[];
  selectedVal: string='1';
  list1: any[];
 

  subscriptions: Subscription[] = [];
  subscription1$: Subscription; 
  subscription2$: Subscription;
  subscription3$: Subscription;

  constructor(private dialog: MatDialog, 
    private allEventService:AllEventService,
    private categoryService:CategoryService,
    private industryService:IndustryService,

    private router:Router,
    private commService:CommunicationServiceService,
    private ngxService: NgxUiLoaderService,
    private _ref: ChangeDetectorRef
    ) { 

      this.config = {
        itemsPerPage: 20,
        currentPage: 1,
        totalItems: this.totalLength
      };
      this.searchText=this.commService.searchText;

    }

   
    pageChanged(event){
      this.config.currentPage = event;
    }
  openDialog(selectedWebinar:Webinar) {

    const dialogConfig = new MatDialogConfig();

   // dialogConfig.disableClose = true;
   // dialogConfig.autoFocus = true;
   dialogConfig.width="500px";
   // console.log(selectedWebinar);
    dialogConfig.data = selectedWebinar;

    this.dialog.open(ShareComponent, dialogConfig);
   

      
}



openWebinarDetails(id){
this.router.navigate(['/webinar',id]);
}

testFilter(){

  //console.log(this.categoryFilterValue);
  this.cat.name="Design - UI/UX";
  this.categoryFilterValue.push("Design - UI/UX");
}

 async ngOnInit(): Promise<any> {
   
   // console.log(this.searchText);
   this.ngxService.start();
   // Do something here...
   
   this.subscription1$=this.allEventService.getRecordedWebinars().subscribe(data =>{
    this.ngxService.stop();
      //console.log(data);
      const sorted = data.sort((a, b) => {
        const dt1 = Date.parse(`${a.schedule.startDate} ${a.schedule.startTime}`)
        const dt2 = Date.parse(`${b.schedule.startDate} ${b.schedule.startTime}`)
      
        return dt2 - dt1
      
      })
      // console.log(sorted)
      var arr=sorted.reverse();
     // console.log(arr)
      
      this.webinars=arr;
      this.originalWebinars=this.webinars;
      //console.log( this.webinars.length);
      this.totalLength=this.webinars.length;
    });
     
    
    this.subscription2$=this.categoryService.getCategories().subscribe(data=>{
      //console.log(data);
      this.categories=data;
    })

    this.subscription3$=this.industryService.getIndustries().subscribe(data=>{
      //console.log(data);
      this.industries=data;
    })

    this.subscriptions.push(this.subscription1$);
    this.subscriptions.push(this.subscription2$);
    this.subscriptions.push(this.subscription3$);

    this.showAllWebinars();

    
   //addedy by preksha for homr to attend page
   if(this.commService.categoryName){
    this.multipleCategories.writeValue([this.commService.categoryName]);
    this.categoryFormControl.setValue([this.commService.categoryName]);
    /*this.categoryFilterValue=[];
   this.categoryFilterValue.push(this.commService.categoryName);*/
  }

  //addedy by preksha for homr to attend page
  if (this.commService.industryName) {
    this.multipleIndustries.writeValue([this.commService.industryName]);
    this.industryFormControl.setValue([this.commService.industryName]);
    /*this.industryFilterValue = [];
    this.industryFilterValue.push(this.commService.industryName);*/

  }
  }

  
   //function to remove category from active filters chips
   removeCatergory(category: Category, multipleCategories): void {
    const index = this.categoryFormControl.value.indexOf(category);
    if (index >= 0) {
      let updatedValue = Object.assign([],this.categoryFormControl.value);
      updatedValue.splice(index, 1);
      this.categoryFormControl.patchValue( updatedValue);
      multipleCategories.writeValue(updatedValue);
    }

  }
  //function to remove industry from active filters chips
  removeIndustry(industry: Industry, multipleIndustries): void {
    const index = this.industryFormControl.value.indexOf(industry);
    if (index >= 0) {
      let updatedValue = Object.assign([],this.industryFormControl.value);
      updatedValue.splice(index, 1);
      this.industryFormControl.patchValue( updatedValue);
      multipleIndustries.writeValue(updatedValue);
    }

  }

  //function to remove duration from active filters chips
  removeDuration(duration, multipleDuration): void {
    const index = this.durationFormControl.value.indexOf(duration);
    if (index >= 0) {
      let updatedValue = Object.assign([],this.durationFormControl.value);
      updatedValue.splice(index, 1);
      this.durationFormControl.patchValue(updatedValue);
      multipleDuration.writeValue(updatedValue);
    }

  }
  
  //function to remove priceFilter from active filters chips
  removePrice(price): void {
    this.priceFilter = '';

  }
//function to remove priceFilter from active filters chips
removeSearch(): void {
  this.searchText = '';

}

  
  
  public onValChange(val: string) {
    this.selectedVal = val;
  }

 selectPost(webinar) {
   
  }
  

  durationList=[
    
    {
      value:"30-60 minutes",
      min:"30",
      max:"60"
    },
    {
      value:"1-2 hours",
      min:"60",
      max:"120"
    },
    {
      value:"more than 2 hours",
      min:"120",
      max:"1000"
    }]

  showFilters=false;
  toggleFilters(){
this.showFilters=!this.showFilters;
    if(!this.showFilters){
  
    }
  }

  resetFilters(){
  
  }

  showAllWebinars(){
    this.allFlag=true;
  this.todayFlag=false;
  this.tomorrowFlag=false;
  this.weekFlag=false;

this.webinars=this.originalWebinars;
  }
  showTodayWebinars(){

    this.allFlag=false;
    this.todayFlag=true;
    this.tomorrowFlag=false;
    this.weekFlag=false;

    this.webinars=this.originalWebinars;
    var momentDate = new Date(); // Replace event.value with your date value
    var formattedDate = moment(momentDate).format("YYYY-MM-DD");
    //console.log(formattedDate);
    this.webinars=this.webinars.filter(data=>{
     if(data.schedule.startDate===formattedDate){
       return data;
     }

    });
  }
  showTomorrowWebinars(){

    this.allFlag=false;
    this.todayFlag=false;
    this.tomorrowFlag=true;
    this.weekFlag=false;

    this.webinars=this.originalWebinars;
    var momentDate = new Date(); 
    momentDate.setDate(momentDate.getDate()+1);// Replace event.value with your date value
    var formattedDate = moment(momentDate).format("YYYY-MM-DD");
    //console.log(formattedDate);
    this.webinars=this.webinars.filter(data=>{
      
     if(data.schedule.startDate===formattedDate){
       return data;
     }

    });
  }

  showThisWeekWebinars(){

    this.allFlag=false;
  this.todayFlag=false;
  this.tomorrowFlag=false;
  this.weekFlag=true;

    this.webinars=this.originalWebinars;
    
    var thisWeekDate = new Date(); 
    thisWeekDate.setDate(thisWeekDate.getDate()+6);
    var formattedThisWeekDate = moment(thisWeekDate).format("YYYY-MM-DD");

    var todayDate = new Date(); 
  
    var formattedTodayDate = moment(todayDate).format("YYYY-MM-DD");

    var tomorrowDate = new Date(); 
    tomorrowDate.setDate(tomorrowDate.getDate()+1);
    var formattedTomorrowDate = moment(tomorrowDate).format("YYYY-MM-DD");
    


    
    this.webinars=this.webinars.filter(data=>{
     
      
     if(moment(data.schedule.startDate).isBefore(formattedThisWeekDate)
     && moment(data.schedule.startDate).isAfter(formattedTodayDate) ){
       return data;
     }

    });
  }

  applySort(sortValue){

    if(sortValue='price-low-high'){


    }
  }
  favoriteSelected: boolean=false;
  toggleFavorite(){

    this.favoriteSelected=!this.favoriteSelected;
  }


  compare(a:Webinar,b:Webinar){

  }

  applySorting(type){
    if(type=='Newest'){
      this.webinars.sort((a,b)=>a.schedule.startDate.localeCompare(b.schedule.startDate));
    }else if(type=='Oldest'){
      this.webinars.sort((a,b)=>b.schedule.startDate.localeCompare(a.schedule.startDate));
    }

//console.log(this.webinars);
  }


  

 hideloader() { 
  
    // Setting display of spinner 
    // element to none 
    document.getElementById('loading') 
        .style.display = 'none'; 
} 


ngOnDestroy() {
  this.subscriptions.forEach((subscription) => subscription.unsubscribe())
}

routeToDetails(id){
  this.router.navigate(['/webinar',id]);
  
}

openRecordingDialog(selectedWebinar:Webinar) {

  const dialogConfig = new MatDialogConfig();

 // dialogConfig.disableClose = true;
 // dialogConfig.autoFocus = true;
 //dialogConfig.width="500px";
 // console.log(selectedWebinar);
  dialogConfig.data = selectedWebinar;

  this.dialog.open(WatchRecordingPopupComponent, dialogConfig);
 

    
}
}
