import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatchRecordingPopupComponent } from './watch-recording-popup.component';

describe('WatchRecordingPopupComponent', () => {
  let component: WatchRecordingPopupComponent;
  let fixture: ComponentFixture<WatchRecordingPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatchRecordingPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatchRecordingPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
