import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Webinar } from 'src/app/interfaces/webinars.model';

@Component({
  selector: 'app-watch-recording-popup',
  templateUrl: './watch-recording-popup.component.html',
  styleUrls: ['./watch-recording-popup.component.css']
})
export class WatchRecordingPopupComponent implements OnInit {
webinar:Webinar;
  constructor(private dialogRef: MatDialogRef<WatchRecordingPopupComponent>,
    @Inject(MAT_DIALOG_DATA) data,private route:Router) {
this.webinar=data;
console.log(data);
     }

  ngOnInit(): void {
  }

}
