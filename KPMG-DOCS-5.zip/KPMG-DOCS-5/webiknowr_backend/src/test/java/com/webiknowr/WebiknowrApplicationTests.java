package com.webiknowr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebiknowrApplicationTests {

	@Test
	void contextLoads() {
	}

}
