package com.webiknowr.repo;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Host;
import com.webiknowr.entity.Webinar;

@Repository
public interface WebinarRepo extends CrudRepository<Webinar, String>{


}
