package com.webiknowr.model;

import java.util.Date;

public class SpeakerBO {

	private int id;
	private String name;
	private String email;
	private String mobile;
	private String about;
	private String profileUrl;
	private String designation;
	private String logo;
	private Date creationDate;
	private Date updationDate;
	private String createdBy;
	private String updatedBy;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getProfileUrl() {
		return profileUrl;
	}
	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getUpdationDate() {
		return updationDate;
	}
	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "SpeakerBO [id=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + ", about=" + about
				+ ", profileUrl=" + profileUrl + ", designation=" + designation + ", logo=" + logo + ", creationDate="
				+ creationDate + ", updationDate=" + updationDate + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + "]";
	}
	
	
}
