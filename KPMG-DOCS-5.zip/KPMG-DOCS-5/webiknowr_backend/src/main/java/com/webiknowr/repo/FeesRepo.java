package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Fees;
import com.webiknowr.entity.Webinar;

@Repository
public interface FeesRepo extends CrudRepository<Fees, String>{

}
