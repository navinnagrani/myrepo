package com.webiknowr.model;

import java.util.Date;
import java.util.List;
import java.util.Set;


import com.webiknowr.entity.Category;
import com.webiknowr.entity.Industry;
import com.webiknowr.entity.Organizer;
import com.webiknowr.entity.Schedule;
import com.webiknowr.entity.Speaker;
import com.webiknowr.entity.Tag;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WebinarBO {

	private String id;
	private String title;
	private String description;
	private String posterUrl;
	private String FormLink;
	private String statusValue;
	private String isFeatured;
	private String isApproved;
	private String userId;
	private int categoryId;
	private String categoryName;
	private String industryName;
	private Category category;
	private int industryId;
	private Industry industry;
	private String isPaid;
	private String feesInINR;
	private Organizer organizer;
	private List<Speaker> speaker;
	private Schedule schedule;
	private Set<Tag> tag;
	private Date creationDate;
	private Date updationDate;
	private String isDeleted;
	private int regCount;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPosterUrl() {
		return posterUrl;
	}
	public void setPosterUrl(String posterUrl) {
		this.posterUrl = posterUrl;
	}
	public String getFormLink() {
		return FormLink;
	}
	public void setFormLink(String formLink) {
		FormLink = formLink;
	}
	public String getStatusValue() {
		return statusValue;
	}
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	public String getIsFeatured() {
		return isFeatured;
	}
	public void setIsFeatured(String isFeatured) {
		this.isFeatured = isFeatured;
	}
	public String getIsApproved() {
		return isApproved;
	}
	public void setIsApproved(String isApproved) {
		this.isApproved = isApproved;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getIndustryName() {
		return industryName;
	}
	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getIndustryId() {
		return industryId;
	}
	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}
	public Industry getIndustry() {
		return industry;
	}
	public void setIndustry(Industry industry) {
		this.industry = industry;
	}
	public String getIsPaid() {
		return isPaid;
	}
	public void setIsPaid(String isPaid) {
		this.isPaid = isPaid;
	}
	public String getFeesInINR() {
		return feesInINR;
	}
	public void setFeesInINR(String feesInINR) {
		this.feesInINR = feesInINR;
	}
	public Organizer getOrganizer() {
		return organizer;
	}
	public void setOrganizer(Organizer organizer) {
		this.organizer = organizer;
	}
	public List<Speaker> getSpeaker() {
		return speaker;
	}
	public void setSpeaker(List<Speaker> speaker) {
		this.speaker = speaker;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}
	public Set<Tag> getTag() {
		return tag;
	}
	public void setTag(Set<Tag> tag) {
		this.tag = tag;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getUpdationDate() {
		return updationDate;
	}
	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}
	public String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
	public int getRegCount() {
		return regCount;
	}
	public void setRegCount(int regCount) {
		this.regCount = regCount;
	}
	
	@Override
	public String toString() {
		return "WebinarBO [id=" + id + ", title=" + title + ", description=" + description + ", posterUrl=" + posterUrl
				+ ", FormLink=" + FormLink + ", statusValue=" + statusValue + ", isFeatured=" + isFeatured
				+ ", isApproved=" + isApproved + ", userId=" + userId + ", categoryId=" + categoryId + ", categoryName="
				+ categoryName + ", industryName=" + industryName + ", category=" + category + ", industryId="
				+ industryId + ", industry=" + industry + ", isPaid=" + isPaid + ", feesInINR=" + feesInINR
				+ ", organizer=" + organizer + ", speaker=" + speaker + ", schedule=" + schedule + ", tag=" + tag
				+ ", creationDate=" + creationDate + ", updationDate=" + updationDate + ", isDeleted=" + isDeleted
				+ "]";
	}
	
	
}
