package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Organizer;

@Repository
public interface OrganizerRepo extends CrudRepository<Organizer, Integer>{

}
