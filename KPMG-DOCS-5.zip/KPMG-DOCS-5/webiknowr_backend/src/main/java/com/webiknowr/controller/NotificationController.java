package com.webiknowr.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.twilio.Twilio;
import com.webiknowr.entity.Webinar;
import com.webiknowr.model.EmailRequest;
import com.webiknowr.model.ResponseDef;

import sendinblue.ApiClient;
import sendinblue.ApiException;
import sendinblue.Configuration;
import sendinblue.auth.ApiKeyAuth;
import sibApi.SmtpApi;
import sibModel.CreateSmtpEmail;
import sibModel.SendSmtpEmail;
import sibModel.SendSmtpEmailSender;
import sibModel.SendSmtpEmailTo;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
@RestController
@RequestMapping("/notification")
@CrossOrigin(origins="*",allowedHeaders="*")
public class NotificationController {
	
	@CrossOrigin
	@PostMapping("sendMail")
	public ResponseEntity<ResponseDef> sendMail(@RequestBody EmailRequest emailRequest) {
		 	ApiClient defaultClient = Configuration.getDefaultApiClient();
	        
	        // Configure API key authorization: api-key
	        ApiKeyAuth apiKey = (ApiKeyAuth) defaultClient.getAuthentication("api-key");
	        apiKey.setApiKey("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");
	        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
	        //apiKey.setApiKeyPrefix("Token");

	        // Configure API key authorization: partnerKey
	        ApiKeyAuth partnerKey = (ApiKeyAuth) defaultClient.getAuthentication("partner-key");
	        partnerKey.setApiKey("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");
	        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
	        //partnerKey.setApiKeyPrefix("Token");

	        //AccountApi apiInstance = new AccountApi();
	        
	        ResponseDef response= new ResponseDef(); 
	        
	        
	        SmtpApi apiInstance = new SmtpApi();
	    	Map<String,String> map=new HashMap<>();
	        
	        SendSmtpEmail sendSmtpEmail = new SendSmtpEmail(); // SendSmtpEmail | Values to send a transactional email
	        
	        SendSmtpEmailTo sendSmtpEmailTo = new SendSmtpEmailTo();
	        
	        SendSmtpEmailSender sendSmtpEmailSender= new SendSmtpEmailSender();
	        sendSmtpEmailSender.setEmail("webiknowr@gmail.com");
	        sendSmtpEmailSender.setName("webiknowr");
	        sendSmtpEmail.setSender(sendSmtpEmailSender);
	        
	        sendSmtpEmailTo.setEmail(emailRequest.getToEmail());
		       // sendSmtpEmailTo.setName("Ashish Agawal");
		        List<SendSmtpEmailTo> list=new ArrayList<>();
		        list.add(sendSmtpEmailTo);
		        sendSmtpEmail.setTo(list);
	        switch (emailRequest.getType()) {
	        
	        case "registration":
	        	
	        	sendSmtpEmail.setTemplateId(2L);
	        	map.put("userName", emailRequest.getUserName());
	 	        map.put("webinarName", emailRequest.getWebinarName());
	 	        map.put("schedule", emailRequest.getSchedule());
	 	        map.put("organizerName", emailRequest.getOrganizerName());
	 	       
	 	        sendSmtpEmail.setParams(map); 
	 	        break; 
	        case "submission":
	        	
	        	sendSmtpEmail.setTemplateId(1L);
	        	map.put("userName", emailRequest.getUserName());
	        	map.put("webinarName", emailRequest.getWebinarName());
		 	    map.put("schedule", emailRequest.getSchedule());
		 	    map.put("organizerName", emailRequest.getOrganizerName());
		 	       
		 	    sendSmtpEmail.setParams(map);
	   
	 	        break;
	        case "signup":
	        	
	        	sendSmtpEmail.setTemplateId(4L);
	        	 map.put("userName", emailRequest.getUserName());
		 	     
	        	 sendSmtpEmail.setParams(map);
	 	        break;
	        	
	        }
	        		 
	        try {
	        	System.out.println(sendSmtpEmail);
	        	 CreateSmtpEmail result = apiInstance.sendTransacEmail(sendSmtpEmail);
	        	 System.out.println(result);
	        	 response.setMessage("Email of type "+emailRequest.getType()+" sent successfully! to "+emailRequest.getToEmail());
	        	 response.setHttpStatus(HttpStatus.OK);
	        	 return new ResponseEntity<ResponseDef>(response,HttpStatus.OK);
	           
	        } catch (ApiException e) {
	        	e.printStackTrace();
	            System.err.println("Exception when calling AccountApi#getAccount");
	           
	            response.setMessage("Email of type "+emailRequest.getType()+" failed! to "+emailRequest.getToEmail()+" due to "+e.getMessage());
	        	 response.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
	        	 return new ResponseEntity<ResponseDef>(response,HttpStatus.EXPECTATION_FAILED);
	        }
	}

}
