package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Host;
import com.webiknowr.entity.Webinar;

@Repository
public interface HostRepo extends CrudRepository<Host, String>{

}
