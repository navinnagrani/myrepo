package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Schedule;
import com.webiknowr.entity.Webinar;

@Repository
public interface ScheduleRepo extends CrudRepository<Schedule, String>{

}
