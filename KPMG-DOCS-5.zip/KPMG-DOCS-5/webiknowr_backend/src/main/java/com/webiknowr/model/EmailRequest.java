package com.webiknowr.model;

public class EmailRequest {
 private String type;
 private String webinarName;
 private String schedule;
 private String organizerName;
 private String posterUrl;
 private String toEmail;
 private String userName;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getWebinarName() {
	return webinarName;
}
public void setWebinarName(String webinarName) {
	this.webinarName = webinarName;
}
public String getSchedule() {
	return schedule;
}
public void setSchedule(String schedule) {
	this.schedule = schedule;
}
public String getOrganizerName() {
	return organizerName;
}
public void setOrganizerName(String organizerName) {
	this.organizerName = organizerName;
}
public String getPosterUrl() {
	return posterUrl;
}
public void setPosterUrl(String posterUrl) {
	this.posterUrl = posterUrl;
}
public String getToEmail() {
	return toEmail;
}
public void setToEmail(String toEmail) {
	this.toEmail = toEmail;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
@Override
public String toString() {
	return "EmailRequest [type=" + type + ", webinarName=" + webinarName + ", schedule=" + schedule + ", organizerName="
			+ organizerName + ", posterUrl=" + posterUrl + ", toEmail=" + toEmail + ", userName=" + userName + "]";
}
 
 
}
