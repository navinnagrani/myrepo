package com.webiknowr.repo;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Speaker;

@Repository
public interface SpeakerRepo extends CrudRepository<Speaker, Integer>{

	//List<Speaker> findByWebinarId(int id);
}
