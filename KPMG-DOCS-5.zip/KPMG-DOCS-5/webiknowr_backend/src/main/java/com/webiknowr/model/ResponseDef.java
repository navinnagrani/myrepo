package com.webiknowr.model;

import org.springframework.http.HttpStatus;

import com.webiknowr.entity.User;

public class ResponseDef {

	private String message;
	private boolean result;
	private HttpStatus httpStatus;
	
	private Object object;
	
	private String errorMessage;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
	
	public Object getObject() {
		return object;
	}
	public void setObject(Object object) {
		this.object = object;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "ResponseDef [message=" + message + ", result=" + result + ", httpStatus=" + httpStatus + ", object="
				+ object + ", errorMessage=" + errorMessage + "]";
	}
	
	
	
	
	
	
}
