package com.webiknowr.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="industry")
public class Industry {
 
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="industry_seq")
	@SequenceGenerator(name = "industry_seq", sequenceName = "industry_seq", initialValue = 1, allocationSize=1)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Lob
	@Column(name="imgIndustry")
	private byte[] img;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public byte[] getImg() {
		return img;
	}

	public void setImg(byte[] img) {
		this.img = img;
	}

	@Override
	public String toString() {
		return "Industry [id=" + id + ", name=" + name + ", img=" + img + "]";
	}
	
	
}
