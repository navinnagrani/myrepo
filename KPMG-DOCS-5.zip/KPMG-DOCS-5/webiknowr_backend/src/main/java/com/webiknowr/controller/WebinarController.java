package com.webiknowr.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.webiknow.mapper.WebinarMapper;
import com.webiknowr.entity.Category;
import com.webiknowr.entity.Industry;
import com.webiknowr.model.ResponseDef;
import com.webiknowr.entity.Speaker;
import com.webiknowr.entity.User;
import com.webiknowr.entity.Webinar;
import com.webiknowr.model.CategoryBO;
import com.webiknowr.model.EmailRequest;
import com.webiknowr.model.IndustryBO;
import com.webiknowr.model.WebinarBO;
import com.webiknowr.service.WebinarService;

import sendinblue.ApiClient;
import sendinblue.ApiException;
import sendinblue.Configuration;
import sendinblue.auth.ApiKeyAuth;
import sibApi.AccountApi;
import sibApi.SmtpApi;
import sibModel.CreateSmtpEmail;
import sibModel.GetAccount;
import sibModel.SendSmtpEmail;
import sibModel.SendSmtpEmailSender;
import sibModel.SendSmtpEmailTo;

@RestController
@RequestMapping("/webinar")
@CrossOrigin(origins="*",allowedHeaders="*")
public class WebinarController {

	@Autowired
	WebinarService webinarService;
	 //ashish
	@Autowired
	WebinarMapper webinarMapper;
	
	
	@CrossOrigin
	@PostMapping("/save")
	public ResponseEntity<Webinar> saveWebinar(@RequestBody Webinar webinarRequest) {
		
		try {
			System.out.println(webinarRequest);
			Webinar webinar=webinarService.saveWebinar(webinarRequest);
			System.out.println(webinar);
			return new ResponseEntity<Webinar>(webinar,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<Webinar>(webinarRequest,HttpStatus.EXPECTATION_FAILED);
		}
		
		
	}
	 
	@CrossOrigin
	@PostMapping("/saveList")
	public ResponseEntity<List<Webinar>> saveWebinarList(@RequestBody List<Webinar> webinarRequest) {
		List<Webinar> webinar=null;
		try {
			
			webinar=webinarService.saveWebinarList(webinarRequest);
		
			return new ResponseEntity<List<Webinar>>(webinar,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Webinar>>(webinar,HttpStatus.EXPECTATION_FAILED);
		}
		
		
	}
	
	@CrossOrigin
	@GetMapping("/allWebinars")
	public ResponseEntity<List<WebinarBO>> listAllWebinar(){
		
		List<Webinar> webinarList=null;
		List<WebinarBO> webinarListNew=new ArrayList<>();
		try {
			webinarList=webinarService.listAllWebinars();
			//System.out.println(webinarList);
			for(Webinar web:webinarList) {
				
				WebinarBO webinarBO=webinarMapper.map(web);
				webinarListNew.add(webinarBO);
				
			}
			//System.out.println(webinarListNew);
			return new ResponseEntity<List<WebinarBO>>(webinarListNew,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<WebinarBO>>(webinarListNew,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@GetMapping("/allCategories")
	public ResponseEntity<List<Category>> listAllCategories(){
		
		System.out.println("inside getcategorues");
		List<Category> categoryList=null;
		List<CategoryBO> categoryBOList=new ArrayList<>();
		try {
			categoryList=webinarService.listOfCategories();
			/*
			for(Category c:categoryList) {
				CategoryBO cat=new CategoryBO();
				cat.setName(c.getName());
				String s=new String(c.getImg());
				System.out.println(s);
				cat.setImg(s);
				categoryBOList.add(cat);
				break;
			}*/
			System.out.println("categoryList"+categoryList);
			return new ResponseEntity<List<Category>>(categoryList,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Category>>(categoryList,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@GetMapping("/allIndustries")
	public ResponseEntity<List<Industry>> listAllIndustries(){
		
		System.out.println("inside getcategorues");
		List<Industry> industryList=null;
		List<IndustryBO> industryBOList=new ArrayList<>();
		try {
			industryList=webinarService.listOfIndustries();
			
			/*
			for(Industry c:industryList) {
				IndustryBO cat=new IndustryBO();
				cat.setName(c.getName());
				String s=new String(c.getImg());
				cat.setImg(s);
				industryBOList.add(cat);
			}
			*/
			System.out.println("industryList"+industryList);
			return new ResponseEntity<List<Industry>>(industryList,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Industry>>(industryList,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@GetMapping("/getWebinarById")
	public ResponseEntity<Webinar> findOne(@RequestParam int id){
		
		System.out.println("inside getWebinarById");
		Webinar webinar=null;
		try {
			webinar=webinarService.getWebinarById(id);
			System.out.println("webinar"+webinar);
			return new ResponseEntity<Webinar>(webinar,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<Webinar>(webinar,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@GetMapping("/getWebinarByHost")
	public ResponseEntity<List<Webinar>> findOneByHost(@RequestParam String hostId){
		
		System.out.println("inside getWebinarByHost");
		List<Webinar> webinar=null;
		try {
			webinar=webinarService.listByHostId(hostId);
			System.out.println("webinar"+webinar);
			return new ResponseEntity<List<Webinar>>(webinar,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Webinar>>(webinar,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@PostMapping("/saveUser")
	public ResponseEntity<ResponseDef> saveUser(@RequestBody User user){
		
		System.out.println("inside getWebinarById");
		ResponseDef response= new ResponseDef();
		try {
			User u=webinarService.saveUser(user);
			System.out.println("user"+u);
			response.setHttpStatus(HttpStatus.ACCEPTED);
			response.setObject(u);
			return new ResponseEntity<ResponseDef>(response,HttpStatus.ACCEPTED);
			
		}catch (DataIntegrityViolationException e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
			response.setObject(user);
			response.setErrorMessage("User already exists with the given email id");
			return new ResponseEntity<ResponseDef>(response,HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
			response.setObject(user);
			response.setErrorMessage(e.getMessage());
			return new ResponseEntity<ResponseDef>(response,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@PostMapping("/saveUserList")
	public ResponseEntity<Boolean> saveUserList(@RequestBody List<User> userList){
		
		System.out.println("inside getWebinarById");
		User user=null;
		try {
			user=webinarService.saveUser(userList);
			
			return new ResponseEntity<Boolean>(true,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<Boolean>(false,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@GetMapping("/users")
	public ResponseEntity<List<User>> getUserList(){
		
		System.out.println("inside getWebinarById");
		List<User> userList=null;
		try {
			userList=webinarService.getUsers();
			
			return new ResponseEntity<List<User>>(userList,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<User>>(userList,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@PostMapping("/saveCategory")
	public ResponseEntity<List<Category>> saveUser(@RequestBody List<CategoryBO> category){
		
		System.out.println("inside getWebinarById");
		List<Category> category1=new ArrayList<>();
		try {
			
			for(CategoryBO i:category) {
				Category c=new Category();
				byte[] decodedByte = i.getImg().getBytes();
				c.setName(i.getName());
				c.setImg(decodedByte);
				category1.add(c);
			}
			
			
			
			
			category1=webinarService.saveCategory(category1);
			System.out.println("category"+category1);
			return new ResponseEntity<List<Category>>(category1,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Category>>(category1,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@DeleteMapping("/deleteWebinar")
	public boolean deleteWebinar(@RequestParam String id){
		return webinarService.deleteWebinar(id);
		
	}
	
	@CrossOrigin
	@PostMapping("/saveIndustry")
	public ResponseEntity<List<Industry>> saveIndustry(@RequestBody List<IndustryBO> industry){
		
		System.out.println("inside getWebinarById");
		List<Industry> category1=new ArrayList<>();
		try {
			
			for(IndustryBO i:industry) {
				Industry c=new Industry();
				byte[] decodedByte = i.getImg().getBytes();
				c.setName(i.getName());
				c.setImg(decodedByte);
				category1.add(c);
			}
			
			category1=webinarService.saveIndustry(category1);
			System.out.println("category"+category1);
			return new ResponseEntity<List<Industry>>(category1,HttpStatus.ACCEPTED);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<List<Industry>>(category1,HttpStatus.EXPECTATION_FAILED);
		}
		
	}
	
	@CrossOrigin
	@PostMapping("sendMail")
	public ResponseEntity<ResponseDef> sendMail(@RequestBody EmailRequest emailRequest) {
		 	ApiClient defaultClient = Configuration.getDefaultApiClient();
	        
	        // Configure API key authorization: api-key
	        ApiKeyAuth apiKey = (ApiKeyAuth) defaultClient.getAuthentication("api-key");
	        apiKey.setApiKey("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");
	        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
	        //apiKey.setApiKeyPrefix("Token");

	        // Configure API key authorization: partnerKey
	        ApiKeyAuth partnerKey = (ApiKeyAuth) defaultClient.getAuthentication("partner-key");
	        partnerKey.setApiKey("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");
	        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
	        //partnerKey.setApiKeyPrefix("Token");

	        //AccountApi apiInstance = new AccountApi();
	        
	        ResponseDef response= new ResponseDef();
	        
	        
	        SmtpApi apiInstance = new SmtpApi();
	    	Map<String,String> map=new HashMap<>();
	        
	        SendSmtpEmail sendSmtpEmail = new SendSmtpEmail(); // SendSmtpEmail | Values to send a transactional email
	        
	        SendSmtpEmailTo sendSmtpEmailTo = new SendSmtpEmailTo();
	        
	        SendSmtpEmailSender sendSmtpEmailSender= new SendSmtpEmailSender();
	        sendSmtpEmailSender.setEmail("webiknowr@gmail.com");
	        sendSmtpEmailSender.setName("webiknowr");
	        sendSmtpEmail.setSender(sendSmtpEmailSender);
	        
	        sendSmtpEmailTo.setEmail(emailRequest.getToEmail());
		       // sendSmtpEmailTo.setName("Ashish Agawal");
		        List<SendSmtpEmailTo> list=new ArrayList<>();
		        list.add(sendSmtpEmailTo);
		        sendSmtpEmail.setTo(list);
	        switch (emailRequest.getType()) {
	        
	        case "registration":
	        	
	        	sendSmtpEmail.setTemplateId(2L);
	        
	 	        map.put("webinarName", emailRequest.getWebinarName());
	 	        map.put("schedule", emailRequest.getSchedule());
	 	        map.put("organizerName", emailRequest.getOrganizerName());
	 	       
	 	        sendSmtpEmail.setParams(map);
	 	        break;
	        case "submission":
	        	
	        	sendSmtpEmail.setTemplateId(1L);
	   
	 	        break;
	        	
	        }
	        		 
	        try {
	        	System.out.println(sendSmtpEmail);
	        	 CreateSmtpEmail result = apiInstance.sendTransacEmail(sendSmtpEmail);
	        	 System.out.println(result);
	        	 response.setErrorMessage("Email of type "+emailRequest.getType()+" sent successfully! to "+emailRequest.getToEmail());
	        	 response.setHttpStatus(HttpStatus.OK);
	        	 return new ResponseEntity<ResponseDef>(response,HttpStatus.OK);
	           
	        } catch (ApiException e) {
	        	//e.printStackTrace();
	            System.err.println("Exception when calling AccountApi#getAccount");
	           
	            response.setErrorMessage("Email of type "+emailRequest.getType()+" failed! to "+emailRequest.getToEmail()+" due to "+e.getMessage());
	        	 response.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
	        	 return new ResponseEntity<ResponseDef>(response,HttpStatus.EXPECTATION_FAILED);
	        }
	}
	
	
	
}
