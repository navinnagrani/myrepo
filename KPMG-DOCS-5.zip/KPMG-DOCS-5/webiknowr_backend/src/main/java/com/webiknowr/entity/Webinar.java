package com.webiknowr.entity;

import java.util.Arrays;
import java.util.Date;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
@Entity
@Table(name="webinar")
public class Webinar  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	
	@Column(name="id")
	/* @GeneratedValue(generator = "UUID")
    @GenericGenerator(
        name = "UUID", 
    strategy = "org.hibernate.id.UUIDGenerator"
    )*/
	
	private String id;
	
	@Column(name="title")
	private String title;
	
	@Transient
	private String description;
	
	@Lob
	@Column(name="description")
	private byte[] descr;
	
	@Transient
	private String posterUrl;
	
	@Lob
	@Column(name="poster_url")
	private byte[] photo;
	
	@Column(name="form_link")
	private String FormLink;
	
	@Column(name="status")
	private String statusValue;
	
	@Column(name="featured")
	private String isFeatured;
	
	@Column(name="is_approved")
	private String isApproved;
	
	@Column(name="host_user_id")
	private String userId;
	
	@Column(name="category_id")
	private int categoryId;
	
	@Transient
	private String categoryName;
	
	@Transient
	private String industryName;
	
	@OneToOne(targetEntity = Category.class,cascade=CascadeType.MERGE)
	@JoinColumn(name="category_id",referencedColumnName = "id",insertable = false,updatable = false)
	private Category category;
	
	@Column(name="industry_id")
	private int industryId;

	@OneToOne(targetEntity = Industry.class,cascade=CascadeType.MERGE)
	@JoinColumn(name="industry_id",referencedColumnName = "id",insertable = false,updatable = false)
	private Industry industry;
	
	@Column(name="is_paid")
	private String isPaid;
	
	@Column(name="fees")
	private String feesInINR;
	
	

	
	@OneToOne(targetEntity = Organizer.class,cascade=CascadeType.ALL)
	@JoinColumn(name="organizer_id",referencedColumnName = "id",insertable = true,updatable = false)
	private Organizer organizer;
	
	
	
	@OneToMany(targetEntity = Speaker.class,cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	 @JoinTable(name = "webinar_speaker",
     joinColumns = {@JoinColumn(name = "webinar_id")},
     inverseJoinColumns = {@JoinColumn(name = "speaker_id")}
		)
	//@JoinColumn(name="id",insertable = true,updatable = false)
	private List<Speaker> speaker;
	
	
	 
	@OneToOne(targetEntity = Schedule.class,cascade=CascadeType.ALL)
	@JoinColumn(name="schedule_id",referencedColumnName = "id",insertable = true,updatable = false)
	private Schedule schedule;
	
	

	
	@OneToMany(targetEntity = Tag.class,cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	 @JoinTable(name = "webinar_tag",
     joinColumns = {@JoinColumn(name = "webinar_id")},
     inverseJoinColumns = {@JoinColumn(name = "tag_id")}
		)
	//@JoinColumn(name="tag_id",referencedColumnName = "id",insertable = true,updatable = false)
	private Set<Tag> tag;
	
	@Column(name="create_date",updatable = false)
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP) 
	private Date creationDate;
	
	@Column(name="update_date") 
	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date updationDate;

	@Column(name="is_deleted")
	private String isDeleted;
	
	@Column(name="reg_count")
	private int regCount;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPosterUrl() {
		return posterUrl;
	}

	public void setPosterUrl(String posterUrl) {
		this.posterUrl = posterUrl;
	}

	public String getFormLink() {
		return FormLink;
	}

	public void setFormLink(String formLink) {
		FormLink = formLink;
	}

	public String getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	public String getIsFeatured() {
		return isFeatured;
	}

	public void setIsFeatured(String isFeatured) {
		this.isFeatured = isFeatured;
	}

	public String getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(String isApproved) {
		this.isApproved = isApproved;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getIndustryId() {
		return industryId;
	}

	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}

	public String getIsPaid() {
		return isPaid;
	}

	public void setIsPaid(String isPaid) {
		this.isPaid = isPaid;
	}

	public String getFeesInINR() {
		return feesInINR;
	}

	public void setFeesInINR(String feesInINR) {
		this.feesInINR = feesInINR;
	}

	public Organizer getOrganizer() {
		return organizer;
	}

	public void setOrganizer(Organizer organizer) {
		this.organizer = organizer;
	}

	public List<Speaker> getSpeaker() {
		return speaker;
	}

	public void setSpeaker(List<Speaker> speaker) {
		this.speaker = speaker;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public Set<Tag> getTag() {
		return tag;
	}

	public void setTag(Set<Tag> tag) {
		this.tag = tag;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getUpdationDate() {
		return updationDate;
	}

	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	public byte[] getDescr() {
		return descr;
	}

	public void setDescr(byte[] descr) {
		this.descr = descr;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public int getRegCount() {
		return regCount;
	}

	public void setRegCount(int regCount) {
		this.regCount = regCount;
	}

	@Override
	public String toString() {
		return "Webinar [id=" + id + ", title=" + title + ", description=" + description + ", descr="
				+ Arrays.toString(descr) + ", posterUrl=" + posterUrl + ", photo=" + Arrays.toString(photo)
				+ ", FormLink=" + FormLink + ", statusValue=" + statusValue + ", isFeatured=" + isFeatured
				+ ", isApproved=" + isApproved + ", userId=" + userId + ", categoryId=" + categoryId + ", categoryName="
				+ categoryName + ", industryName=" + industryName + ", category=" + category + ", industryId="
				+ industryId + ", industry=" + industry + ", isPaid=" + isPaid + ", feesInINR=" + feesInINR
				+ ", organizer=" + organizer + ", speaker=" + speaker + ", schedule=" + schedule + ", tag=" + tag
				+ ", creationDate=" + creationDate + ", updationDate=" + updationDate + ", isDeleted=" + isDeleted
				+ ", regCount=" + regCount + "]";
	}
	
	
}
