package com.webiknowr.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.webiknowr.entity.Category;
import com.webiknowr.entity.Industry;
import com.webiknowr.entity.User;
import com.webiknowr.entity.Webinar;

public interface WebinarService {

	public Webinar saveWebinar(Webinar webinar);
	public List<Webinar> saveWebinarList(List<Webinar> webinarList);
	public List<Webinar> listAllWebinars();
	List<Category> listOfCategories();
	List<Industry> listOfIndustries();
	public Webinar getWebinarById(int id);
	
	public User saveUser(User user);
	public User saveUser(List<User> user);
	
	public List<Webinar> listByHostId(String hostId);
	
	public List<Category> saveCategory(List<Category> category);
	
	public List<Industry> saveIndustry(List<Industry> industry);
	
	public boolean deleteWebinar(String id);
	List<User> getUsers();
}
