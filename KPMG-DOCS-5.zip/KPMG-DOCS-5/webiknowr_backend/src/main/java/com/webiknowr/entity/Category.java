package com.webiknowr.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
@Entity
@Table(name="category")
public class Category {
 
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="category_seq")
	@SequenceGenerator(name = "category_seq", sequenceName = "category_seq", initialValue = 1, allocationSize=1)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	 @Lob
	@Column(name="img")
	private byte[] img;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public byte[] getImg() {
		return img;
	}

	public void setImg(byte[] img) {
		this.img = img;
	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", img=" + img + "]";
	}
	
	
}
