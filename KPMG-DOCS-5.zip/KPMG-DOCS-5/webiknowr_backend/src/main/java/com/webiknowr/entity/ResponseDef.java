package com.webiknowr.entity;

import org.springframework.http.HttpStatus;

public class ResponseDef {

	private String message;
	private boolean result;
	private HttpStatus httpStatus;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
	@Override
	public String toString() {
		return "ResponseDef [message=" + message + ", result=" + result + ", httpStatus=" + httpStatus + "]";
	}
	
	
	
	
	
}
