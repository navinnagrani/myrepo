package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Webinar;
import com.webiknowr.entity.WebinarInfo;

@Repository
public interface WebinarInfoRepo extends CrudRepository<WebinarInfo, String>{

}
