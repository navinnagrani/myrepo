package com.webiknowr.serviceImpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webiknowr.entity.Category;
import com.webiknowr.entity.Host;
import com.webiknowr.entity.Industry;
import com.webiknowr.entity.Speaker;
import com.webiknowr.entity.Webinar;
import com.webiknowr.repo.CategoryRepo;
import com.webiknowr.repo.IndustryRepo;
import com.webiknowr.repo.SpeakerRepo;
import com.webiknowr.repo.TagRepo;
import com.webiknowr.repo.UserRepo;
import com.webiknowr.repo.WebinarRepo;
import com.webiknowr.service.WebinarService;
import com.webiknowr.entity.Tag;
import com.webiknowr.entity.User;

@Service
public class WebinarServiceImpl implements WebinarService{

	@Autowired
	private WebinarRepo webinarRepo;
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	@Autowired
	private IndustryRepo industryRepo;
	
	@Autowired
	private SpeakerRepo speakerRepo;
	
	@Autowired
	private TagRepo tagRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	
	@Override
	public Webinar saveWebinar(Webinar webinar) {
		
		webinar.getOrganizer().setCreationDate( new Date( System.currentTimeMillis()));
		webinar.getSpeaker().forEach(i->{
			i.setCreationDate(new Date( System.currentTimeMillis()));
			byte[] speakerByte = i.getLogo().getBytes();
			i.setPhoto(speakerByte);
			i.setAboutSpeaker(i.getAbout().getBytes());
		});
		webinar.getSchedule().setCreationDate( new Date( System.currentTimeMillis()));
		webinar.getTag().forEach(i->{
			i.setCreationDate(new Date( System.currentTimeMillis()));
		});
		
		webinar.setPhoto(webinar.getPosterUrl().getBytes());
		webinar.getOrganizer().setPhoto(webinar.getOrganizer().getLogo().getBytes());
		webinar.setDescr(webinar.getDescription().getBytes());
		webinar.getOrganizer().setAboutOrganizer(webinar.getOrganizer().getAbout().getBytes());
		
		Category cat=categoryRepo.findByName(webinar.getCategoryName());
		webinar.setCategoryId(cat.getId());
		
		Industry ind=industryRepo.findByName(webinar.getIndustryName());
		webinar.setIndustryId(ind.getId());
		
		
		Webinar wb=webinarRepo.save(webinar);
		/*
		List<Speaker> list=wb.getSpeaker();
		List<Tag> list1=wb.getTag();
		list.forEach(i->{
			
			i.setWebinarId(Integer.parseInt(wb.getId()));
			speakerRepo.save(i);
		});
		
		list1.forEach(i->{
			
			i.setWebinarId(Integer.parseInt(wb.getId()));
			tagRepo.save(i);
		});
		*/
		return wb;
		
	}

	@Override
	public List<Webinar> listAllWebinars() {
		
		List<Webinar> list=(List<Webinar>) webinarRepo.findAll();
		
		try {
			/*
			list.forEach(i->{
				System.out.println(i);
				//List<Speaker> speakerList=speakerRepo.findByWebinarId(Integer.parseInt(i.getId()));
				//List<Tag> tagsList=tagRepo.findByWebinarId(Integer.parseInt(i.getId()));
				System.out.println(speakerList);
				i.setSpeaker(speakerList);
				i.setTag(tagsList);
				
			});
			*/
			System.out.println(list);
		
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return list;
		
	}

	@Override
	public List<Category> listOfCategories() {
		return (List<Category>) categoryRepo.findAll();
		
	}
	
	@Override
	public List<Industry> listOfIndustries() {
		return (List<Industry>) industryRepo.findAll();
		
	}

	@Override
	public Webinar getWebinarById(int id) {
		// TODO Auto-generated method stub
		Optional<Webinar> webinar=webinarRepo.findById(String.valueOf(id));
		Webinar wb =new Webinar();
		/*
		if(webinar.isPresent()) {
			wb=webinar.get();
			List<Speaker> speakerList=speakerRepo.findByWebinarId(Integer.parseInt(wb.getId()));
			List<Tag> tagList=tagRepo.findByWebinarId(Integer.parseInt(wb.getId()));
			wb.setSpeaker(speakerList);
			wb.setTag(tagList);
			
		}
		*/
		return wb;
	}

	@Override
	public User saveUser(User u) {
		// TODO Auto-generated method stub
		if(u.getBio()!=null) {
			byte[] b=u.getBio().getBytes();
			u.setAbout(b);
		}
		if(u.getInterest()!=null && !u.getInterest().isEmpty()) {
			String s=u.getInterest().stream().collect(Collectors.joining(","));
			u.setInterests(s);
		}
		System.out.println(u);
		
		
		return userRepo.save(u);
	}
	
	@Override
	public List<User> getUsers(){
		return (List<User>) userRepo.findAll();
	}
	
	@Override
	public User saveUser(List<User> userList) {
		// TODO Auto-generated method stub
		
		for(User u:userList) {
			
			if(u.getBio()!=null) {
				byte[] b=u.getBio().getBytes();
				u.setAbout(b);
			}
			if(u.getInterest()!=null && !u.getInterest().isEmpty()) {
				String s=u.getInterest().stream().collect(Collectors.joining(","));
				u.setInterests(s);
			}
			System.out.println(u);
			userRepo.save(u);
		}
		
		return null;
	}

	@Override
	public List<Webinar> listByHostId(String hostId) {
		// TODO Auto-generated method stub
		Host h=new Host();
		h.setUserId(hostId);
		
		//System.out.println(webinarRepo.findByHost(h));
		return null;
	}

	@Override
	public List<Category> saveCategory(List<Category> category) {
		// TODO Auto-generated method stub
		
		return (List<Category>) categoryRepo.saveAll(category);
		
	
	}

	@Override
	public List<Industry> saveIndustry(List<Industry> industry) {
		// TODO Auto-generated method stub
		return (List<Industry>) industryRepo.saveAll(industry);
		
	}

	@Override
	public boolean deleteWebinar(String id) {
		// TODO Auto-generated method stub
		
		webinarRepo.deleteById(id);
		return false;
	}

	@Override
	public List<Webinar> saveWebinarList(List<Webinar> webinarList) {
		// TODO Auto-generated method stub
		for(Webinar webinar:webinarList) {
			webinar.getOrganizer().setCreationDate( new Date( System.currentTimeMillis()));
			webinar.getSpeaker().forEach(i->{
				i.setCreationDate(new Date( System.currentTimeMillis()));
				byte[] speakerByte = i.getLogo().getBytes();
				i.setPhoto(speakerByte);
				i.setAboutSpeaker(i.getAbout().getBytes());
			});
			webinar.getSchedule().setCreationDate( new Date( System.currentTimeMillis()));
			webinar.getTag().forEach(i->{
				i.setCreationDate(new Date( System.currentTimeMillis()));
			});
			
			webinar.setPhoto(webinar.getPosterUrl().getBytes());
			webinar.getOrganizer().setPhoto(webinar.getOrganizer().getLogo().getBytes());
			webinar.setDescr(webinar.getDescription().getBytes());
			webinar.getOrganizer().setAboutOrganizer(webinar.getOrganizer().getAbout().getBytes());
			
			Category cat=categoryRepo.findByName(webinar.getCategoryName());
			if(null!=cat)
				webinar.setCategoryId(cat.getId());
			else
				webinar.setCategoryId(1); 
			
			Industry ind=industryRepo.findByName(webinar.getIndustryName());
			if(null!=ind)
				webinar.setIndustryId(ind.getId());
			else
				webinar.setIndustryId(1);
			
			webinarRepo.save(webinar);
		}
		return webinarList;
	}
}
