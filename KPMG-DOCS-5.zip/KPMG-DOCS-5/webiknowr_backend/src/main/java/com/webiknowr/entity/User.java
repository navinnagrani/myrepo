package com.webiknowr.entity;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="user_seq")
	@SequenceGenerator(name = "user_seq", sequenceName = "user_seq", initialValue = 1, allocationSize=1)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String displayName;
	
	@Column(name="email_id")
	private String email;
	
	@Column(name="mobile_no")
	private String phoneNumber;
	
	@Column(name="provider")
	private String providerId;
	
	@Column(name="photo_url")
	private String photoURL;
	
	@Column(name="uid")
	private String uid;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="creation_date")
	private Date creationDate;
	
	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updation_date")
	private Date updationDate;
	
	@Column(name="dob")
	private String dob;
	
	@Column(name="state")
	private String state;
	
	@Column(name="country")
	private String country;
	
	@Column(name="city")
	private String city;
	
	@Column(name="sex")
	private String sex;
	
	@Column(name="roles")
	private String roles;
	
	@Column(name="profile_completed")
	private String profileCompleted;
	
	@Column(name="interest")
	private String interests;
	
	@Transient
	private List<String> interest;
	
	@Column(name="designation")
	private String designation;
	
	@Lob
	@Column(name="bio")
	private byte[] about;
	
	@Transient
	private String bio;
	
	@Column(name="occupation")
	private String occupation;
	
	@Column(name="company")
	private String company;
	
	@Column(name="organizer_type")
	private String organizerType;
	
	@Column(name="college")
	private String college;
	
	@Column(name="website")
	private String website;
	
	@Column(name="organizer_industry")
	private String organizerIndustry;
	
	@Column(name="organizer_location")
	private String organizerLocation;
	
	@Column(name="speaker_fav_topics")
	private String speakerFavTopics;
	
	@Column(name="linkedin_profile")
	private String linkedinProfile;
	
	@Column(name="facebook_profile")
	private String facebookProfile;
	
	@Column(name="twitter_profile")
	private String twitterProfile;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getPhotoURL() {
		return photoURL;
	}

	public void setPhotoURL(String photoURL) {
		this.photoURL = photoURL;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getUpdationDate() {
		return updationDate;
	}

	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getProfileCompleted() {
		return profileCompleted;
	}

	public void setProfileCompleted(String profileCompleted) {
		this.profileCompleted = profileCompleted;
	}

	

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public byte[] getAbout() {
		return about;
	}

	public void setAbout(byte[] about) {
		this.about = about;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getOrganizerType() {
		return organizerType;
	}

	public void setOrganizerType(String organizerType) {
		this.organizerType = organizerType;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getOrganizerIndustry() {
		return organizerIndustry;
	}

	public void setOrganizerIndustry(String organizerIndustry) {
		this.organizerIndustry = organizerIndustry;
	}

	public String getOrganizerLocation() {
		return organizerLocation;
	}

	public void setOrganizerLocation(String organizerLocation) {
		this.organizerLocation = organizerLocation;
	}

	public String getSpeakerFavTopics() {
		return speakerFavTopics;
	}

	public void setSpeakerFavTopics(String speakerFavTopics) {
		this.speakerFavTopics = speakerFavTopics;
	}

	public String getLinkedinProfile() {
		return linkedinProfile;
	}

	public void setLinkedinProfile(String linkedinProfile) {
		this.linkedinProfile = linkedinProfile;
	}

	public String getFacebookProfile() {
		return facebookProfile;
	}

	public void setFacebookProfile(String facebookProfile) {
		this.facebookProfile = facebookProfile;
	}

	public String getTwitterProfile() {
		return twitterProfile;
	}

	public void setTwitterProfile(String twitterProfile) {
		this.twitterProfile = twitterProfile;
	}
	

	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public List<String> getInterest() {
		return interest;
	}

	public void setInterest(List<String> interest) {
		this.interest = interest;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", displayName=" + displayName + ", email=" + email + ", phoneNumber=" + phoneNumber
				+ ", providerId=" + providerId + ", photoURL=" + photoURL + ", uid=" + uid + ", creationDate="
				+ creationDate + ", updationDate=" + updationDate + ", dob=" + dob + ", state=" + state + ", country="
				+ country + ", city=" + city + ", sex=" + sex + ", roles=" + roles + ", profileCompleted="
				+ profileCompleted + ", interest=" + interest + ", designation=" + designation + ", about="
				+ Arrays.toString(about) + ", bio=" + bio + ", occupation=" + occupation + ", company=" + company
				+ ", organizerType=" + organizerType + ", college=" + college + ", website=" + website
				+ ", organizerIndustry=" + organizerIndustry + ", organizerLocation=" + organizerLocation
				+ ", speakerFavTopics=" + speakerFavTopics + ", linkedinProfile=" + linkedinProfile
				+ ", facebookProfile=" + facebookProfile + ", twitterProfile=" + twitterProfile + "]";
	}

	

	
	

}
