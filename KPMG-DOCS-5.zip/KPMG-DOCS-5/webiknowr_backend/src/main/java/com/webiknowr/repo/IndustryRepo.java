package com.webiknowr.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webiknowr.entity.Industry;
import com.webiknowr.entity.Webinar;

@Repository
public interface IndustryRepo extends CrudRepository<Industry, String>{

	Industry findByName(String name);
}
