package com.webiknow.mapper;

import org.springframework.stereotype.Component;

import com.webiknowr.entity.Speaker;
import com.webiknowr.entity.Webinar;
import com.webiknowr.model.WebinarBO;

@Component
public class WebinarMapper {

	
	public WebinarBO map(Webinar webinar) {
		
		WebinarBO webinarBO=new WebinarBO();
		
		//category
		webinarBO.setCategoryName(webinar.getCategory().getName());
		webinarBO.setCategoryId(webinar.getCategoryId());	
		
		//industry
		webinarBO.setIndustryId(webinar.getIndustryId());
		webinarBO.setIndustryName(webinar.getIndustry().getName());
		
		//webinarinfo
		
		webinarBO.setId(webinar.getId());
		webinarBO.setDescription(new String(webinar.getDescr()));
		webinarBO.setPosterUrl(new String(webinar.getPhoto()));
		webinarBO.setTitle(webinar.getTitle());
		webinarBO.setUserId(webinar.getUserId());
		webinarBO.setIsApproved(webinar.getIsApproved());
		webinarBO.setIsFeatured(webinar.getIsFeatured());
		webinarBO.setFormLink(webinar.getFormLink());
		webinarBO.setRegCount(webinar.getRegCount());
		
		//fees
		webinarBO.setIsPaid(webinar.getIsPaid());
		webinarBO.setFeesInINR(webinar.getFeesInINR());
		
		//dates
		webinarBO.setCreationDate(webinar.getCreationDate());
		webinarBO.setUpdationDate(webinar.getUpdationDate());
		
		//schedule
		webinarBO.setSchedule(webinar.getSchedule());
		
		//tags
		webinarBO.setTag(webinar.getTag());
		
		//organizer
		webinarBO.setOrganizer(webinar.getOrganizer());
		webinarBO.getOrganizer().setLogo(new String(webinar.getOrganizer().getPhoto()));
		webinarBO.getOrganizer().setPhoto(null);
		webinarBO.getOrganizer().setAbout(new String(webinar.getOrganizer().getAboutOrganizer()));
		webinarBO.getOrganizer().setAboutOrganizer(null);
		
		//speaker
		webinarBO.setSpeaker(webinar.getSpeaker());
		for(Speaker speaker:webinarBO.getSpeaker()) {
			speaker.setLogo(new String(speaker.getPhoto()));
			speaker.setAbout(new String(speaker.getAboutSpeaker()));
			speaker.setPhoto(null);
			speaker.setAboutSpeaker(null);
		}
		
		return webinarBO;
	}
	
}
