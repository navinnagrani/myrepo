package com.multidatasource.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.multidatasource.model.Person;


public interface PersonRepo extends JpaRepository<Person, Long> {

}
