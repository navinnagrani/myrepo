package com.multidatasource.database.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.multidatasource.model.Person;
import com.multidatasource.repository.PersonRepoH2;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "h2EntityManagerFactory", transactionManagerRef = "h2TransactionManager" , repositoryBaseClass = PersonRepoH2.class)
public class H2Config {
	
	@Bean
    @ConfigurationProperties(prefix="db2.datasource-h2")
    public DataSourceProperties h2DataSourceProperties() {
        return new DataSourceProperties();
    }

	@Bean(name = "h2Datasource")
	@ConfigurationProperties(prefix = "db2.datasource-h2")
	public DataSource h2Datasource() {
		DataSourceProperties derbyDataSourceProperties = h2DataSourceProperties();
        return DataSourceBuilder.create()
       .driverClassName(derbyDataSourceProperties.getDriverClassName())
       .url(derbyDataSourceProperties.getUrl())
       .username(derbyDataSourceProperties.getUsername())
       .password(derbyDataSourceProperties.getPassword())
       .build();
	}
	
	
	@Bean(name = "h2EntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(h2Datasource()).packages(Person.class).persistenceUnit("db2").build();
	}
	
	
	@Bean(name = "h2TransactionManager")
	public PlatformTransactionManager h2TransactionManager(@Qualifier("h2EntityManagerFactory") EntityManagerFactory h2EntityManagerFactory) {
		return new JpaTransactionManager(h2EntityManagerFactory);
	}
}
