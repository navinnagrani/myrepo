package com.multidatasource.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.multidatasource.model.Person;

public interface PersonRepoH2 extends JpaRepository<Person, Long>{

}
