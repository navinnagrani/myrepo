package com.multidatasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiDataSourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiDataSourceApplication.class, args);
	}
	//https://www.techgeeknext.com/spring-boot/spring-boot-multiple-datasources-jpa
	
	//using jdbcTemplate
	//https://dzone.com/articles/using-multiple-datasources-with-springboot-applica
}
