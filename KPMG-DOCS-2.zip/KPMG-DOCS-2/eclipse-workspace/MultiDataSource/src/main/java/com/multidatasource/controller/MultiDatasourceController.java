package com.multidatasource.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multidatasource.model.Person;
import com.multidatasource.repository.PersonRepo;
import com.multidatasource.repository.PersonRepoH2;


@RestController
@RequestMapping("/multisource")
public class MultiDatasourceController {
	
	@Autowired
	PersonRepo personRepo;
	
	@Autowired
	PersonRepoH2 personRepoH2;
	
	@PostMapping("/derby")
	public ResponseEntity<Person> createPerson(@RequestBody Person person) {
		try {
			Person personCreated = personRepo.save(person);
			return new ResponseEntity<>(personCreated, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/h2db")
	public ResponseEntity<Person> createPersonH2(@RequestBody Person person) {
		try {
			Person personCreated = personRepoH2.save(person);
			return new ResponseEntity<>(personCreated, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/h2db/{id}")
	ResponseEntity<Optional<Person>> getAllCustomers(@PathVariable("id") long id) {
		try {
			Optional<Person> p = personRepoH2.findById(id);
			return new ResponseEntity<>(p,HttpStatus.OK);
			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
