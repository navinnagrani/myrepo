package com.multidatasource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDataSourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
