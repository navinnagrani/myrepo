create schema metaphor;

set schema metaphor;

create table products(
productid int,
name varchar(45),
description varchar(200),
price int,
imageUrl varchar(300)
);

select * from metaphor.products;

insert into metaphor.products values(7,"Product7","This is product 3 description.The product is really cool",700,"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1VJQYCv2jq3M2P4d-zPBxfyBqJJs5bTTOlQ&usqp=CAU")

create table metaphor.customer(
firsname varchar(50),
lastname varchar(50),
mobilenumber BIGINT,
email varchar(100),
password varchar(100)
)

select * from METAPHOR.CUSTOMER

delete from metaphor.customer;


create table student_plac(
studentid int,
studentname varchar(30),
company varchar(30),
salary BIGINT
)

select * from student_plac;

insert into student_plac values(1,'navin','jp',20000)
insert into student_plac values(2,'ram','morgan',30000)
insert into student_plac values(3,'gansham','kpmg',40000)
insert into student_plac values(4,'rubal','morgan',50000)
insert into student_plac values(5,'kamal','jp',30000)

select * from student_plac

select company,salary from student_plac
where salary = (select max(salary) from student_plac)

select company,sum(salary) from student_plac
group by company
having sum(salary) > 50000
select company , sum(salary) as tot_sal from student_plac
group by company


employee(
empid
orgid
empsal
empname
)

org(
orgid
orgname
)

select d.orgname,max(e.empsal) as maxsal
from employee e where e.empsal < (select max(empsal) from org d where d.orgid = e.orgid)
group by d.orgname


select * from book;

select author from BOOK
group by author
having (count(*) > 2)
