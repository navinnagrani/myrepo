package com.metaphor.service;

import java.util.List;

import com.metaphor.model.Customer;
import com.metaphor.model.Product;

public interface ProductService {
	
	public List<Product> getAllProducts();

	public boolean createNewCustomer(Customer customer);

	public boolean checklogin(String email, String password);

}
