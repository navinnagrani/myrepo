package com.metaphor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.metaphor.model.Customer;
import com.metaphor.model.Product;
import com.metaphor.model.Products;
import com.metaphor.service.ProductService;

@RestController
@RequestMapping("/metaphor")
@CrossOrigin(origins="*",allowedHeaders="*")
public class ProductController {

	@Autowired
	ProductService productService;
	
	@GetMapping("/getProducts")
	ResponseEntity<List<Product>> getAllProducts() {
		List<Product> products = productService.getAllProducts();
		return ResponseEntity.ok().body(products);
		
	}
	
	@PostMapping("/signup")
	ResponseEntity<Boolean> createNewCustomer(@RequestBody Customer customer) {
		boolean created = productService.createNewCustomer(customer);
		if(created)
			return ResponseEntity.ok().body(created);
		else
			return ResponseEntity.badRequest().body(created);
	}
	
	@GetMapping("/login")
	ResponseEntity<Boolean> checklogin(@RequestParam String email,@RequestParam String password) {
		boolean result = productService.checklogin(email,password);
		if(result)
			return ResponseEntity.ok().body(result);
		else
			return ResponseEntity.ok(result);
	}
}
