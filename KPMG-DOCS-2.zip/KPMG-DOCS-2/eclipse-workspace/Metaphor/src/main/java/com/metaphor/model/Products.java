package com.metaphor.model;

import java.io.Serializable;
import java.util.List;

public class Products implements Serializable {
	List<Product> productList;

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	
	
	
}
