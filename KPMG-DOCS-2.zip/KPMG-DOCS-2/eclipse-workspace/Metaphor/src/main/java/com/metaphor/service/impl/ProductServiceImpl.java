package com.metaphor.service.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.metaphor.model.Customer;
import com.metaphor.model.Product;
import com.metaphor.model.Products;
import com.metaphor.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService{
	private Connection connect = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
	
	public Connection connectDb() throws Exception {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
			connect = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true");
		} catch (Exception e) {
			throw e;
		} 
		return connect;
	}
	
	public List<Product> getAllProducts() {
		Products products = new Products();
		Product product;
		List<Product> productList = new ArrayList<Product>();
		try {
			Connection connect = connectDb();
			Statement statement = connect.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM METAPHOR.PRODUCTS");
			while(rs.next()) {
				product = new Product();
				product.setId(rs.getInt("productid"));
				product.setName(rs.getString("name"));
				product.setDescription(rs.getString("description"));
				product.setPrice(rs.getInt("price"));
				if(rs.getString("imageurl") != null) {
					product.setImageUrl(rs.getString("imageurl"));
				}
				productList.add(product);
			}
			products.setProductList(productList);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return productList;
	}

	@Override
	public boolean createNewCustomer(Customer customer) {
		try {
			Connection connect = connectDb();
			PreparedStatement preparedStmt = connect.prepareStatement("INSERT INTO METAPHOR.CUSTOMER VALUES(?,?,?,?,?)");
			preparedStmt.setString (1, customer.getFirstName());
			preparedStmt.setString (2, customer.getLastName());
			preparedStmt.setLong (3, customer.getMobileNumber());
			preparedStmt.setString (4, customer.getEmail());
			preparedStmt.setString (5, customer.getPassword());
			boolean created = preparedStmt.executeUpdate()==1 ? true : false;
			return created;
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean checklogin(String email, String password) {
		try {
			Connection connect = connectDb();
			PreparedStatement preparedStmt = connect.prepareStatement("SELECT PASSWORD FROM METAPHOR.CUSTOMER where EMAIL=?");
			preparedStmt.setString (1, email);
			ResultSet rs = preparedStmt.executeQuery();
			while(rs.next()) {
				if(rs.getString("password").equals(password))
					return true;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
