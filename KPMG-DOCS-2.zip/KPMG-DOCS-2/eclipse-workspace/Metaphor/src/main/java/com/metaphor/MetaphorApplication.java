package com.metaphor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetaphorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetaphorApplication.class, args);
	}

}
