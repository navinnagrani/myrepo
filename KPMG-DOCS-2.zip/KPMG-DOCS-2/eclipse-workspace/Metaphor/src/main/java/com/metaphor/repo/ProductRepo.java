package com.metaphor.repo;

import org.springframework.data.repository.CrudRepository;

import com.metaphor.model.Product;

public interface ProductRepo extends CrudRepository<Product,Integer> {

}
