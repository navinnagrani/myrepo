package com.crm.model;

import javax.persistence.*;
import lombok.*;

@Data
@Entity
public class Contact {
	public @Id @GeneratedValue Long id;
	public String firstName;
	public String lastName;
	public String email;
	
	
	public Contact() {}


	public Contact(String firstName, String lastName, String email) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}
	
	
	
	
	
}
