package com.crm.model;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.*;

@Component
public class DemoLoader implements CommandLineRunner{
	
	@Autowired
	private final ContactRepository repository;
	
	@Autowired
	public DemoLoader(ContactRepository repository) {
		this.repository = repository;
	}
	
	@Override
	public void run(String...strings) throws Exception{
		this.repository.save(new Contact("Navin","Nagrani","navin26@gmail.com"));
	}
}
