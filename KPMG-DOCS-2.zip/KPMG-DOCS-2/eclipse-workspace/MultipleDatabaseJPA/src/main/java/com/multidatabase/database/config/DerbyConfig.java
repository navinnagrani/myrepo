package com.multidatabase.database.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;

import com.multidatabase.model.Creature;
import com.multidatabase.repo.DerbyRepo;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {"com.multidatabase.repo"},entityManagerFactoryRef = "derbyEntityManagerFactory",transactionManagerRef = "derbyTransactionManager")
public class DerbyConfig {
	
	@Primary
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource-derby")
	public DataSourceProperties derbyDatasourceProperties() {
		return new DataSourceProperties();
	}
	
	@Primary
	@Bean(name = "derbyDatasource")
	public DataSource derbyDatasource() {
		return ((DataSourceProperties) derbyDatasourceProperties()).initializeDataSourceBuilder()
                .type(HikariDataSource.class).build();
	}
	
	@Primary
	@Bean(name = "derbyEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean derbyEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(derbyDatasource()).packages(Creature.class).persistenceUnit("db1").build();
	}
	
	@Primary
	@Bean
    public PlatformTransactionManager derbyTransactionManager(
            final @Qualifier("derbyEntityManagerFactory") LocalContainerEntityManagerFactoryBean derbyEntityManagerFactory) {
        return new JpaTransactionManager(derbyEntityManagerFactory.getObject());
    }
	

}
