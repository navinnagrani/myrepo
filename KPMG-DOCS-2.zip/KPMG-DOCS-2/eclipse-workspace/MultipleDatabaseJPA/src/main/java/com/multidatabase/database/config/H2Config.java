package com.multidatabase.database.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.multidatabase.model.Creature;
import com.multidatabase.repo.H2Repo;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(repositoryBaseClass = H2Repo.class,entityManagerFactoryRef = "h2EntityManagerFactory",transactionManagerRef = "h2TransactionManager")
public class H2Config {
	
	@Bean
	@ConfigurationProperties(prefix = "db2.datasource-h2")
	public DataSourceProperties h2DatasourceProperties() {
		return new DataSourceProperties();
	}
	
	@Bean(name="h2Datasource")
	public DataSource h2Datasource() {
		return ((DataSourceProperties) h2DatasourceProperties()).initializeDataSourceBuilder()
                .type(HikariDataSource.class).build();
	}
	
	@Bean(name = "h2EntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean h2EntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(h2Datasource()).packages(Creature.class).persistenceUnit("db2").build();
	}
	
	@Bean
    public PlatformTransactionManager h2TransactionManager(
            final @Qualifier("h2EntityManagerFactory") LocalContainerEntityManagerFactoryBean h2EntityManagerFactory) {
        return new JpaTransactionManager(h2EntityManagerFactory.getObject());
    }

}
