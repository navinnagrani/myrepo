package com.multidatabase.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.multidatabase.model.Creature;


public interface DerbyRepo extends JpaRepository<Creature, Long> {

}
