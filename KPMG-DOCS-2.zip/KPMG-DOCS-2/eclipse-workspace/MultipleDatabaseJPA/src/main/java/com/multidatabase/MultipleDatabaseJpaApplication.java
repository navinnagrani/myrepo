package com.multidatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleDatabaseJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipleDatabaseJpaApplication.class, args);
	}

}
