package com.multidatabase.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multidatabase.model.Creature;
import com.multidatabase.repo.DerbyRepo;
import com.multidatabase.repo.H2Repo;

@RestController
@RequestMapping("/multidatabase")
public class MultipleDatabaseController {
	
	@Autowired
	DerbyRepo derbyRepo;
	
	@Autowired
	H2Repo h2Repo;
	
	@PostMapping("/derby")
	public ResponseEntity<Creature> createPerson(@RequestBody Creature creature) {
		try {
			Creature creatureCreated = derbyRepo.save(creature);
			return new ResponseEntity<>(creatureCreated, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/h2db")
	public ResponseEntity<Creature> createPersonH2(@RequestBody Creature creature) {
		try {
			Creature creatureCreated = h2Repo.save(creature);
			return new ResponseEntity<>(creatureCreated, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/h2db/{id}")
	ResponseEntity<Optional<Creature>> getAllCustomers(@PathVariable("id") long id) {
		try {
			Optional<Creature> p = h2Repo.findById(id);
			return new ResponseEntity<>(p,HttpStatus.OK);
			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
