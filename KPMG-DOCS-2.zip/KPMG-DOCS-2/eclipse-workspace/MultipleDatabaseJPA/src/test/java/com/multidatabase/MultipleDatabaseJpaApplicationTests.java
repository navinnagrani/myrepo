package com.multidatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipleDatabaseJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
