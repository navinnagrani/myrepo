set schema test

CREATE TABLE customer
(
id BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
name VARCHAR(30) NOT NULL,
email VARCHAR(100),
mobilenumber BIGINT,
address VARCHAR(1024),
interest VARCHAR(30),
CONSTRAINT primary_key PRIMARY KEY (id)
);

drop table customer

delete from customer

select * from customer;


create table employees(
id bigint,
name varchar(30),
sal int,
age int,
city varchar(30)
)

drop table employees



select name,sal 
from Employees a 
where 2 = 
(select count(distinct sal) 
from Employees b 
where a.sal <= b.sal)
AND AGE between 20 and 25
AND city = 'mumbai'


create table product_table(
id int,
name varchar(30),
primary key(id)
)

create table customer_table(
id int,
name varchar(30),
primary key(id)
)

create table transaction_table(
transactionid int,
customerid int,
productid int,
FOREIGN KEY (customerid) REFERENCES customer_table(id),
FOREIGN KEY (productid) REFERENCES product_table(id)
)

select count(productid) from transaction_table
where customerid in (select id from CUSTOMER_TABLE)

create table EMP(
id int,
name varchar(30)
)
insert into "USER"."EMP" ("ID", "NAME") values(1, 'test')
insert into "USER"."EMP" ("ID", "NAME") values(2, 'test')
insert into "USER"."EMP" ("ID", "NAME") values(3, 'xyz')
insert into "USER"."EMP" ("ID", "NAME") values(4, 'xjm')
insert into "USER"."EMP" ("ID", "NAME") values(5, 'xyz')
insert into "USER"."EMP" ("ID", "NAME") values(6, 'test')

DELETE from EMP
WHERE id NOT IN (
    SELECT min(id)
    FROM EMP
    GROUP BY name
);

delete from emp;



create table companies (
      name varchar(30) not null,
      country varchar(30) not null,
      unique(name)
  );
  
create table trades (
      id integer not null,
      seller varchar(30) not null,
      buyer varchar(30) not null,
      value integer not null,
      unique(id)
  );
  
 
SELECT DeptID, EmpName, Salary FROM EmpDetails WHERE (DeptID,Salary) 
IN (SELECT DeptID, MAX(Salary) FROM EmpDetails GROUP BY DeptID)
