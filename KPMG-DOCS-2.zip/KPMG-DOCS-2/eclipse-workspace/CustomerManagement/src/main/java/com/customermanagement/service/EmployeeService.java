package com.customermanagement.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.customermanagement.model.Customer;
import com.customermanagement.model.Employee;
import com.customermanagement.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepo;

	public Employee checkEmployee(Employee employeeCreds) {
		Employee e = employeeRepo.findByEmailAndPassword(employeeCreds.getEmail(), employeeCreds.getPassword());
		if(e!=null) {
			return e;
		}
		return null;
	}

	public Employee findById(long id) {
		Optional<Employee> emp = employeeRepo.findById(id);
		if(emp!=null) {
			return emp.get();
		}
		return null;
	}

	public Employee updatedEmployee(Employee employee, long employeeid) {
		Optional<Employee> employeeData = employeeRepo.findById(employeeid);

		if (employeeData.isPresent()) {
			Employee employeeUpdated = employeeData.get();
			employeeUpdated.setPassword(employee.getPassword());
			employeeRepo.save(employeeUpdated);
			return employeeUpdated;
		} else {
			return null;
		}
	}
}
