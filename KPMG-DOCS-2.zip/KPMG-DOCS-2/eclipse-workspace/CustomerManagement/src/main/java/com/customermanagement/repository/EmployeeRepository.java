package com.customermanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customermanagement.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	
	public Employee findByEmailAndPassword(String email,String password);
	
	//public Employee loadByEmail(String email);
}
