package com.customermanagement.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.customermanagement.model.Customer;
import com.customermanagement.service.CustomerService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/crm")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@GetMapping("/getCustomers")
	ResponseEntity<List<Customer>> getAllCustomers() {
		try {
			List<Customer> customers = customerService.getAllCustomers();
			if (customers.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(customers, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/customer")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
		try {
//			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yy'T'HH:mm:ss");
//			LocalDateTime createdDateTime = LocalDateTime.parse(customer.getCreatedDateTime(), formatter);
			Customer customerCreated = customerService.createCustomer(customer);
			return new ResponseEntity<>(customerCreated, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PatchMapping("/updatecustomer/{customerId}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public ResponseEntity<Customer> updateTutorial(@RequestBody Customer customer,@PathVariable("customerId") long customerId) {
		
		try {
			Customer customerUpdated = customerService.updatedCustomer(customer,customerId);
			return new ResponseEntity<>(customerUpdated, HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
}
