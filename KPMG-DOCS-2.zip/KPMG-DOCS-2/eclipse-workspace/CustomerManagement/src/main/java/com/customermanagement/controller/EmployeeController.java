package com.customermanagement.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customermanagement.model.Customer;
import com.customermanagement.model.Employee;
import com.customermanagement.service.EmployeeService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/crm")
public class EmployeeController {

	
	@Autowired
	EmployeeService employeeService;
	
	
	@PostMapping("/checkLogin")
	ResponseEntity<Employee> checkLogin(@RequestBody Employee employeeCreds) {
		try {
			Employee emp = employeeService.checkEmployee(employeeCreds);
			if(emp != null) {
				return new ResponseEntity<>(emp, HttpStatus.OK);
			}
			return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/getEmployee/{id}")
	ResponseEntity<Employee> getEmployee(@PathVariable("id") long id) {
		try {
			Employee emp = employeeService.findById(id);
			if(emp != null) {
				return new ResponseEntity<>(emp, HttpStatus.OK);
			}
			return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PatchMapping("/updateemployee/{employeeid}")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public ResponseEntity<Employee> updateTutorial(@RequestBody Employee employee,@PathVariable("employeeid") long employeeid) {
		
		try {
			Employee employeeUpdated = employeeService.updatedEmployee(employee,employeeid);
			if(employeeUpdated != null) {
				return new ResponseEntity<>(employeeUpdated, HttpStatus.OK);
			}
			return new ResponseEntity<>(null, HttpStatus.NOT_MODIFIED);
		} catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
