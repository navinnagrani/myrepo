package com.customermanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;
import com.customermanagement.model.Customer;
import com.customermanagement.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepo;
	
	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

	public Customer createCustomer(Customer customer) {
		Customer customerCreated = customerRepo.save(new Customer(customer.getName(), customer.getEmail(),
				customer.getMobileNumber(), customer.getAddress(), customer.getInterest(),customer.getCreatedDateTime()));
		return customerCreated;
	}

	public Customer updatedCustomer(Customer customer, long id) {
		
		Optional<Customer> customerData = customerRepo.findById(id);

		if (customerData.isPresent()) {
			Customer customerUpdated = customerData.get();
			customerUpdated.setName(customer.getName());
			customerUpdated.setEmail(customer.getEmail());
			customerUpdated.setMobileNumber(customer.getMobileNumber());
			customerUpdated.setAddress(customer.getAddress());
			customerRepo.save(customerUpdated);
			return customerUpdated;
		} else {
			return null;
		}
		
	}

}
