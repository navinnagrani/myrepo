package com.parle.service;

import com.parle.model.Plan;

public interface PlanService {
	
	public String savePlan(Plan plan);
}
