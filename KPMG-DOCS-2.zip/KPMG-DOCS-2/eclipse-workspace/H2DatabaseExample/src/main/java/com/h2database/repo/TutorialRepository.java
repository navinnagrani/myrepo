package com.h2database.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.h2database.model.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {

}
