package com.test.package4.designpattern;


/*
 * Theory
 * Prototype is a creational design pattern that is based on the concept of copying an existing object to create a new one. 
 * This pattern delegates the copying process to the object that is being copied. 
 * It commonly uses an interface that contains the clone() method.
 * 
 * When we can apply the prototype?
 * 1.	When your code shouldn't depend on a class that creates prototype objects. This can occur when 
 * you are working with objects which were passed to you from a 3rd-party code via some interface. 
 * In this case, you simply can't rely on them, because these classes are unknown. Prototype pattern allows 
 * working around these classes by providing an interface that works with any object that supports the copying process.
 * 2.	When you want to reduce the number of subclasses that only differ by the way they initialize objects. 
 * The pattern lets you use a set of pre-built objects, configured in various ways, as prototypes.
 */

abstract class PrototypeAbstract {
	protected abstract PrototypeAbstract clone();
}

class DuckPrototype extends PrototypeAbstract {
	String name;
	
	public DuckPrototype() {}
	
	void eat() {}
	
	void makeEggs() {}
	
	String voice () {return "quack";}

	@Override
	protected PrototypeAbstract clone() { return new DuckPrototype(); }

}

class PigeonPrototype extends PrototypeAbstract {
	String name;
	
	public PigeonPrototype() {}
	
	void eat() {}
	
	void makeEggs() {}
	
	String voice () {return "quack";}

	@Override
	protected PrototypeAbstract clone() { return new PigeonPrototype(); }

}

public class Prototype {

}
