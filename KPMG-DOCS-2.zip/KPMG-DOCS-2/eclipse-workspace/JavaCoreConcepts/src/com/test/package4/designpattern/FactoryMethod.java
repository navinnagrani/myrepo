package com.test.package4.designpattern;



/*
 * Theory
 * Factory method is a creational design pattern that describes how you can, through interface or abstract class, 
 * make a method to create objects which could be overridden in subclasses.
 * Describe how to solve recurring design problems to write more flexible and reusable code.
 * It solves the following two problems:
	Defining a separate object creation method in the form of a factory
	Allowing subclasses to call factory for object creation
	
	Through Bird interface we can 'make' different types of birds.They all share the same functions they 
	inherited from a bird interface, but they also added new methods.
 */
/*
 * When we can apply the factory method?
 * There are few situations where you can use this pattern:
1.	It's useful when you don't know the exact types of objects your code should work with. 
If your application has to expand the types of objects it works with, it will be easier with the factory method. 
You will only need to create a new factory subclass that will override factory method in it.
2.	A lot of frameworks and libraries are made with the factory method in mind, which allows you to modify them in your code. 
So if you are writing a framework that in your plans will be used by other people, you could apply the factory method 
making possible the extensions of your code.
3.	This pattern could also be used when you want to save system resources by reusing existing objects instead of 
rebuilding new ones each time.

Main disadvantage is a more complicated code that consists of a lot of subclasses needed to implement it.
 */
interface Bird {
	public static final String name = "";
	
	void eat();
	void makeEggs();
}

class Duck implements Bird {

	@Override
	public void eat() {}

	@Override
	public void makeEggs() {}
	
	void fly() {}
	
	void swim() {}
	
	String voice() { return "Quack";}
	
}

class Pigeon implements Bird {

	@Override
	public void eat() {}

	@Override
	public void makeEggs() {}
	
	void fly() {}
	
	String voice() { return "Coo";}
	
}

class Chicken implements Bird {

	@Override
	public void eat() {}

	@Override
	public void makeEggs() {}
	
	String voice() { return "Cluck";}
	
}
public class FactoryMethod {

}
