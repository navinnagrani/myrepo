package com.test.package4.designpattern;


/*
 * Theory
 * 
 * When you want to reduce the number of subclasses that only differ by the way they initialize objects. 
 * The pattern lets you use a set of pre-built objects, configured in various ways, as prototypes.
 * 
 * It solves two problems:
 * 1.	Keeping only one instance of an object is useful when you want to control access to some shared resources. 
 * When you create one object of a class, if you use singleton pattern, you will always have that same object. 
 * In case you'll try to create another one, the code will return the first initiated object each time.
 * 2.	Providing global access point to allow all clients to use the initiated instances. 
 * When you address this problem, you also should squeeze all the code regarding the 
 * first problem in one class, to avoid it being scattered all over your code.
 * 
 * Usage of singleton
 * singleton should be used in situations when you need to keep only one instance of a class that is available to all clients. 
 * 1.	For example, the most common example is the LogManager class that allows keeping logs of your application runtime. 
 * It doesn't need to have more than one instance and should be accessible to all application classes. 
 * 2.	Another time when this pattern should be 
 * implemented is when you need to isolate your instance and have only singleton class control over it.
*/

class EagerInitialization {
	private static final EagerInitialization instance = new EagerInitialization();

	private EagerInitialization() {
	}

	public static EagerInitialization getInstance() {
		return instance;
	}
}

class LazyInitialization {
	// private instance, so that it can be
	// accessed by only by getInstance() method
	private static LazyInitialization instance;

	private LazyInitialization()
	  {
	    // private constructor
	  }

	// method to return instance of class
	public static LazyInitialization getInstance() {
		if (instance == null) {
			// if instance is null, initialize
			instance = new LazyInitialization();
		}
		return instance;
	}
}

public class Singleton {

}
