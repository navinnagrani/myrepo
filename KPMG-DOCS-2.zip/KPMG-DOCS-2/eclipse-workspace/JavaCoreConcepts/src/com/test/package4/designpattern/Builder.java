package com.test.package4.designpattern;


/*
 * Theory
 * 
 * Builder pattern is a creational design pattern that allows you to create objects step by step. 
 * This approach allows creating fundamentally the same objects using one constructor, 
 * but they can be modified to depict different types of objects.
 * The main goal of the builder pattern is to separate the construction of a complex object from its representation so that 
 * the same construction process can create different representations
 * 
 * For example, you have a restaurant that serves different types of dishes to guests. 
 * All dishes need to be cooked and they all consist of food ingredients that should be prepared and added. 
 * The basic way to recreate this situation in form of code will be creating a dish class that will be 
 * extended to a set of different subclasses to cover all combinations of the parameters. 
 * This solution will spawn a large number of subclasses 
 * which will make a really complex hierarchy that you need to extend every time when you need to add a new parameter.
 * 
 * Builder as a solution
 * 
 * The point of builder is to organize separate construction classes called builders. 
 * These classes will create separate objects with their set of parameters. 
 * They all work with pre-made steps that are defined in a builder interface. 
 * In our example, these steps are associated with food, so they will be something like cook(), salt(), pepper(), etc.
 * 
 * You can also have a separate class called director. 
 * It defines the order in which to execute the building steps, while the builder implements those steps. 
 * This isn't necessary, but this class might be a good place to put various construction routines 
 * so you can reuse them in your program. It also hides the construction process from the client.
 * So when you need a specific dish, you should call a specific builder that creates it.
 * 
 * In our system, a guest will make an order for a dish to the director. 
 * Then the director will send an order to the builder interface which will call a specific builder 
 * class that will make an order for this guest.
 * 
 * When to use Builder Pattern ?
 * You should use this pattern when you want your code to be able to create different representations of some product. 
 * Builder will allow you to reuse the same construction for them. 
 * However, it will require creating multiple new classes which might make your code more complex.
 * 
 * 
 */

public class Builder {

}
