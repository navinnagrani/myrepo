package com.test.package1;

public class A {
	protected void m1() {
		System.out.println("This is protected method in pkg-1");
	}
	void m2() {
		System.out.println("This is default method in pkg-1");
	}
}
