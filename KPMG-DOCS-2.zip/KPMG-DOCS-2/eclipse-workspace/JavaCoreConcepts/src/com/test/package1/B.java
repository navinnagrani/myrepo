package com.test.package1;

public class B {
	
	void test() {
		A a1 = new A();
		a1.m1();
		a1.m2();
	}
	
}
