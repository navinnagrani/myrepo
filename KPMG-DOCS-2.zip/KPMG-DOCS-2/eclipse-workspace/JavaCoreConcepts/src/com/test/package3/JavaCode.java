package com.test.package3;

import java.util.PriorityQueue;

public class JavaCode {
		
	public static void main(String[] args) {
		PriorityQueue<String> p = new PriorityQueue<String>();
		p.add("carrot");
		p.add("apple");
		p.add("banana");
		System.out.println(p.poll()+" :"+p.peek());
		
		}

}
