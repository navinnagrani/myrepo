package com.test.package3;

import java.io.FileNotFoundException;
import java.io.IOException;

class A {
	void m1() throws IOException {
		/*
		 * 1.FileNotFoundException alone can be allowed in super class and if we dont
		 * throw any exception in child class it will be fine
		 * 2.throws IOException in super class method will work fine and if we dont
		 * declare any exception in base class overrirden method that will also be fine
		 * 3.If super class have any Parent Exception , it is fine , but base class
		 * overridden method can or cannot have only its Child Exception
		 */
	}
}
class B extends A {
	@Override
	void m1() throws FileNotFoundException {
		/*
		 * 1.throws IOException is not allowed in the base class since
		 * it is the parent exception
		 * 2.Child Exceptions are not allowed in base class overridden method if we dont 
		 * declare any Parent Exception in super class method
		 */
	}
}

public class ExceptionHandlingHierarchy {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
