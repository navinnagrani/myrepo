package com.test.package3;

import java.util.stream.Stream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

class Color {
	private String name;
	public Color(String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		return true;
	}
	
	@Override
	public int hashCode() {
		return 1;
	}
}
public class NewClass<T> {
	static long calculate(int pos,int prev,int left,int k) {
	    if(pos==k) {
	        if(left==0) {
	            return 1;
	        } else {
	            return 0;
	            
	        }
	    }   
	    if(left==0) {
	        return 0;
	    }
	    long ans = 0;
	    for(int i=prev;i<=left;i++) {
	        ans+=calculate(pos+1, i, left-i, k);
	    }
	    return ans;
	}

	public static long countOptions(int people, int groups) {
	    return calculate(0, 1, people, groups);
	    

	}
	private static String temp = "1";
	
	private void firMtd() {
		try {
			secMtd();
		} catch(Exception e) {
			temp+=5;
		}
	}
	
	private void secMtd() throws Exception {
		try {
			thdMd();
			temp+=3;
		} catch(Exception e) {
			throw new Exception();
		} finally {
			temp+=4;
		}
	}
	
	private void thdMd( ) throws Exception{
		throw new Exception();
	}
	
	private static Object m1() {
		try {
			int i = 10/0;
			return i;
		} catch(ArithmeticException e) {
			return "catch";
		} finally {
			return "finally";
		}
	}
	T value;
	public NewClass(T value) {
		this.value = value;
	}
	public T getVal() {
		return value;
	}
	
	
	
	public static void main(String args[]) {
		Map<Color,String> m = new HashMap<Color, String>();
		m.put(new Color("Red"), "Red");
		m.put(new Color("Blue"), "Blue");
		m.put(new Color("Green"), "Green");
		System.out.println(m.size());
		System.out.println(m.get(new Color("Red")));
		
		Runnable runnable = new Runnable(){ public void run(){}};
		
		
	}
}


