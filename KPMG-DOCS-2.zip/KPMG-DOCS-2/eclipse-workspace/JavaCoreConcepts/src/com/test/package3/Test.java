package com.test.package3;

//2 interface having same method ?

//Why Arraylist are slower than arrays ?
//Answer
//It is pretty obvious that array[10] is faster than array.get(10), 
//as the later internally does the same call, but adds the overhead for the function call plus additional checks
//The main difference between Array vs ArrayList in Java is the static nature of the Array and the dynamic nature of ArrayList
//1.Array is a fixed-length data structure while ArrayList is a variable-length
//You can not change the length of Array once created in Java but ArrayList re-size itself when gets 
//full depending upon the capacity and load factor
//Since ArrayList is internally backed by Array in Java, any resize operation 
//in ArrayList will slow down performance as it involves creating a new Array and copying content from the old array to the new array.
//
//2.Another difference between Array and ArrayList in Java is that you can not use Generics along 
//with Array, as Array instance knows about what kind of type it can hold and throws ArrayStoreException 
//if you try to store type which is not convertible into the type of Array. 
//ArrayList allows you to use Generics to ensure type safety
//
//3.you can not store primitives in ArrayList, it can only contain Objects. 
//While Array can contain both primitives and Objects in Java. Though Autoboxing of Java 5 may 
//give you an impression of storing primitives in ArrayList, it actually automatically converts primitives to Object

//Underlying data structure of Arraylist ?
//Answer
//ArrayList is internally backed by Array in Java, any resize operation in ArrayList 
//will slow down performance as it involves creating new Array and copying content from old array to new array

//Method overloading with float ?

//Difference between abstract and interface java 8 ?
//Answer
//With the introduction of concrete methods (default and static methods) to interfaces from Java 8, 
//the gap between interface and abstract class has been reduced significantly.
//We cannot instantiate an abstract class in Java because it is abstract, it is not complete, hence it cannot be used.
//1.Abstract classes are classes, so they are not restricted to other restrictions of the interface in Java, 
//like abstract class can have the state, but you cannot have the state on the interface in Java
//Although abstract class can have state using reference of the class which is extending it
//an abstract class can contain constructors in Java. 
//And a constructor of abstract class is called when an instance of an inherited class is created
//2.Another semantic difference between an interface with default methods and an abstract class is 
//that you can define constructors inside an abstract class, but you cannot define constructors inside an interface in Java
//When to use what?
//
//Consider using abstract classes if any of these statements apply to your situation:  
//
//In the java application, there are some related classes that need to share some lines of code 
//then you can put these lines of code within the abstract class and this abstract class should be extended by all these related classes.
//You can define the non-static or non-final field(s) in the abstract class so that via 
//a method you can access and modify the state of the Object to which they belong.
//You can expect that the classes that extend an abstract class have many common methods 
//or fields, or require access modifiers other than public (such as protected and private).

//Consider using interfaces if any of these statements apply to your situation:  
//
//It is a total abstraction, All methods declared within an interface must be implemented by the class(es) that implements this interface.
//A class can implement more than one interface. It is called multiple inheritances.
//You want to specify the behaviour of a particular data type, but not concerned about who implements its behaviour.

interface A2 {
	default void show() {
		System.out.println("Inter A");
	}
}

interface B2 {
	default void show() {
		System.out.println("Inter B");
	}
}

class C implements A2, B2 {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		A2.super.show();
	}

}

abstract class Bike {
	abstract void run();

	void run2() {
		System.out.println("Inside run2");
	}
}

class Honda4 extends Bike {
	void run() {
		System.out.println("running safely");
	}

	public static void main(String args[]) {
		Bike obj = new Honda4();
		obj.run();
		obj.run2();
	}
}

class MehtodOverloading {
	
//	void sum(int i) {
//		System.out.println("Int mtd "+i);
//	}
	
	void sum(double d) {
		System.out.println("Double mtd " + d);
	}

	void sum(float f) {
		System.out.println("Float mtd " + f);
	}

	void sum(short s) {
		System.out.println("Short mtd " + s);
	}
}

class A1 {
	public void show() {

	}
}

class B1 extends A1 {
	public void show() {
		// We cannot keep it private and A1 class show to public as Cannot reduce the
		// visibility of the inherited method from A1
	}
}


class A3 {
	
	// Static method in base class which will be hidden in subclass
	public static int m1() {
		return 0;
	}
}

class B3 extends A3 {
	
	//@Override - Cannot put override annotation
	// This method is hidden by m1() in Base
	
	/*
	 * Parent class methods that are static are not part of a child class (although they are accessible), 
	 * so there is no question of overriding it. Even if you add another static method in a subclass, 
	 * identical to the one in its parent class, 
	 * this subclass static method is unique and distinct from the static method in its parent class
	 * Even if you rewrite in child class it will be much like Shadowing  
	 */
	
	public static int m1() {
		return 1;
	}
	
	
	public static int roundProblem(int n,int k) {
		if (n==1)
            return 1;
        else
            return (roundProblem(n-1,k) + k - 1) % n + 1;
	}
}


public class Test {

	public static void main(String[] args) {
		
		A3 a3 = new A3();
		A3 b3 = new B3();
		B3 b3Obj = new B3();
		
		System.out.println(a3.m1()+" "+b3.m1()+" "+b3Obj.m1()+" "+B3.m1());
		
		A1 a = new B1();
		// a.show(); //The method show() from the type A1 is not visible , so have to
		// change to atleast package

		MehtodOverloading m = new MehtodOverloading();
		m.sum(1); // At compile time, the compiler searches for that method that matches the most
					// closest;
					// the most near one sub class overloaded method or nearest primitive in
					// ascending order is chosen
					// imply that the compiler chooses the "least widening" conversion if more than
					// one is available
		// https://stackoverflow.com/questions/24279680/what-happens-when-we-pass-int-arguments-to-the-overloading-method-having-float-a
		
//		Scanner sc = new Scanner(System.in);
//		int n = sc.nextInt();
//		int k = 2;
//		System.out.println(roundProblem(n,k));
		
	}

}
