package com.test.package3;

interface m1{
	abstract void m1();
}

class Base {
	void m1() {
		System.out.println("M1 in Base");
	}
}
class Child extends Base implements m1 {

	@Override
	public
	void m1() {
		System.out.println("M1 in Child");
		
		/*
		If there is an interface having method name same as of Base class,then we have to change access specifier
		to public. The child class will override the method from interface and not Base class
		*/
	}
}


public class InheritanceExample {

	public static void main(String[] args) {
		Base a = new Child(); // Reference of Base holding Child Object
		a.m1();
		
		Base b = new Base(); // Reference of Base holding Base object
		b.m1();
		
		Child c = new Child(); // Reference of Child holding Child object
		c.m1();
		
		//Child d = new Base(); // Compilation erro Type mismatch: cannot convert from Base to Child
	}

}
