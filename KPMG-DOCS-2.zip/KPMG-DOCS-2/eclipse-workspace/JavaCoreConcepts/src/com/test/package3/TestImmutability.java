package com.test.package3;

import java.util.ArrayList;
import java.util.HashMap;

public class TestImmutability {

	public static void main(String[] args) {
		HashMap<Person, Integer> m = new HashMap<Person, Integer>();
		Person p1 = new Person();
		Person p2 = new Person();
		
		p1.setName("navin");
		p1.setAge(26);
		
		p2.setName("Lisha");
		p2.setAge(26);
		
		m.put(p1, 1);
		m.put(p2, 2);
		
		ImmutableFullExample im = new ImmutableFullExample("Check", "Immutable", null, null, m);
		
		System.out.println("Immutable class "+im);
		
		ArrayList<Address> list = im.getAddressList();
		System.out.println("This is list "+list);
		
		HashMap<Person, Integer> localVariable = im.getPersonMap();
		
		
		
		System.out.println("Map in immutable class "+localVariable);
		
		localVariable.remove(p1);
		System.out.println("Map in immutable class after modification "+localVariable);
		System.out.println(im);
	}

}
