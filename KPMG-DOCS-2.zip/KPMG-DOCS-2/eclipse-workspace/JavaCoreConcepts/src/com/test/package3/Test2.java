package com.test.package3;

import java.io.BufferedReader;
import java.util.*;

class A4 {
	public A4(){
		System.out.println("A c");
	}
	public void m1() {
		System.out.println("A m");
	}
}
class B4 extends A4 {
	public B4(){
		System.out.println("B c");
	}
	public void m1() {
		System.out.println("B m");
	}
}



public class Test2 {
//	public static void xyz(int i) {
//		
//	}
//	
//	public static int xyz(int i) {
//		
//	}
	
	public static void xyz(char c) {
		
	}
	
	public static void main(String[] args){
		xyz('1');
		A4 b = new B4();
		b.m1();
		

		
	}
	
}
