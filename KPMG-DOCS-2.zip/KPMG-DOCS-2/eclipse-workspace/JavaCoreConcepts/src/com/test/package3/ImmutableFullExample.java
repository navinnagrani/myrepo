package com.test.package3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public final class ImmutableFullExample {
	
	/*
	 Points to note
	 1.The class must be declared as final so that child classes can�t be created.
	 2.Data members in the class must be declared private so that direct access is not allowed.
	 3.Data members in the class must be declared as final so that we can�t change the value of it after object creation
	 4.Initialize all the fields through a constructor doing the deep copy.
	 5.Perform cloning of objects in the getter methods to return a copy rather than returning the actual object reference.
	 6.If the instance fields include references to mutable objects, don�t allow those objects to be changed
	 7.Don�t provide methods that modify the mutable objects
	 8.Don't provide any setter methods
	 */
	
	private final String firstName;
    private final String lastName;
    
    private final Address address;  //Mutable User-Defined Object
    
    private final ArrayList<Address> addressList; //Mutable Collection Object
    
    private final HashMap<Person, Integer> personMap; 	// Mutable collection Object Hashmap with Mutable Key . Here the Person
    													// Object should be immutable
    
    /*
     1.Key objects are suggested to be IMMUTABLE. Immutability allows you to get same hash code every time, for a key object. 
     So it actually solves most of the problems in one go. Also, this class must honor the hashCode() and equals() methods contract.
     2.Remember that immutability is recommended and not mandatory. If you want to make a mutable object as key in hashmap, 
     then you have to make sure that state change for key object does not change the hash code of object. 
     This can be done by overriding the hashCode() method. 
     But, you must make sure you are honoring the contract with equals() also.
     
     If we make the keys mutable then the hashcode() of the key will no more be consistent over time which will 
     cause lookup failure for that object from the data structure.
     */
    
    public ImmutableFullExample(String firstName, String lastName,Address address,ArrayList<Address> addressList,HashMap<Person, Integer> personMap) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.addressList = addressList;
        this.personMap = personMap;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public Address getAddress() throws CloneNotSupportedException {
        //return address; // This will break immutablity since , it get be stored in local variable and can be changed.Instead use below
    	
    	/*
    	 Instead of returning the original Address instance, we will return deep cloned copy of that Adress instance. 
    	 Even if third party user makes any changes to this cloned address object, it will not affect the 
    	 original address object of User object.
    	 */
    	return (Address) address.clone();
    }
    
    public ArrayList<Address> getAddressList(){
        return (ArrayList<Address>) Collections.unmodifiableCollection(addressList);
    }
    
	public HashMap<Person, Integer> getPersonMap() {
		return (HashMap<Person, Integer>) Collections.unmodifiableMap(personMap);
	}
}
