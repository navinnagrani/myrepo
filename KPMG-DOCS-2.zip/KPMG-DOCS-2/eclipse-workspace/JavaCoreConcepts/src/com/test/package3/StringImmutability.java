package com.test.package3;

public class StringImmutability {

	public static void main(String[] args) {
		String name = "John";
		String anotherName = "John";
		
		System.out.println(name == anotherName);
	}

}
