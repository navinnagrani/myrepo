package com.test.package3;
import java.util.*;

class Student {
	int rollNumber;
	String name;
	int mathMark;
	int phyMark;
	int sciMark;
	public Student(int rollNumber, String name, int mathMark, int phyMark, int sciMark) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.mathMark = mathMark;
		this.phyMark = phyMark;
		this.sciMark = sciMark;
	}
	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", mathMark=" + mathMark + ", phyMark="
				+ phyMark + ", sciMark=" + sciMark + "]";
	}
	
}

public class MyTest {
	
	public static List<Student> rankHigh(List<Student> students) {
		Collections.sort(students,new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				int totalVal1 = o1.mathMark+o1.phyMark+o1.sciMark;
				int toatlVal2 = o2.mathMark+o2.phyMark+o2.sciMark;
				return toatlVal2-totalVal1;
			}
		});
		
		return students;
		
	}
	
	public static void main(String[] args)  {
		List<Student> studentList = new ArrayList<Student>();
		
		Student s1 = new Student(1, "Navin", 20, 30, 40);
		Student s2 = new Student(2, "Ram", 10, 20, 20);
		Student s3 = new Student(3, "Kamal", 60, 40, 40);
		Student s4 = new Student(4, "Hitesh", 70, 30, 40);
		
		studentList.add(s1);
		studentList.add(s2);
		studentList.add(s3);
		studentList.add(s4);
		
		List<Student> res = rankHigh(studentList);
		for(Student s:res) {
			System.out.println(s.toString());
		}
		
	}

}
