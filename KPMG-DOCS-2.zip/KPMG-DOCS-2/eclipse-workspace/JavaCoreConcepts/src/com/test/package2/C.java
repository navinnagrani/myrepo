package com.test.package2;

import com.test.package1.A;

public class C extends A {
	void test() {
		A a1 = new A();
		m1();
		super.m1();
	}
	
}
