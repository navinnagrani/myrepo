package com.genpact;

import java.util.HashMap;
import java.util.HashSet;

public class Employee {
    String name;
    int mobile;

    public Employee(String name,int mobile) {
        this.name = name;
        this.mobile = mobile;
    }
    
    @Override
    public int hashCode() {
        System.out.println("calling hascode method of Employee");
        String str = this.name;
        int sum = 0;
        for (int i = 0; i < str.length(); i++) {
            sum = sum + str.charAt(i);
        }
        System.out.println(sum);
        return sum;
    }

    @Override
    public boolean equals(Object obj) {
        System.out.println("calling equals method of Employee");
        Employee emp = (Employee) obj;
        if (this.mobile == emp.mobile  && this.name.equals(emp.name)) {
            System.out.println("returning true");
            return true;
        } else {
            System.out.println("returning false");
            return false;
        }
    }

    public static void main(String[] args) {
    	
        Employee emp1 = new Employee("abc", 124);
        Employee emp2 = new Employee("abc", 124);
        
        System.out.println("Object attribute values are compared "+(emp1.equals(emp2)));
        System.out.println("Object address are compared "+(emp1==emp2));
        
        
        HashSet<Employee> set = new HashSet<Employee>();
        set.add(emp1);
        set.add(emp2);
        
        
        
        System.out.println("Size of set "+set.size());
        
        HashMap<Employee, String> h = new HashMap<>();
        h.put(emp1, "dummy");
        h.put(emp2, "dummy");
        
        System.out.println("----------------");
        System.out.println("Size of hashmap: "+h.size());
    }
}
