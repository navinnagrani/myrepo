package com.genpact;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Test1 {
	
	static final String sample="simple";
	String output = sample+"sample";
	
	void a() {
		if("simplesample"==output) {
			System.out.println("sample==output");
		} else {
			System.out.println("sample!=output");
		}
	}
	public static void main(String args[]) {
		Test1 t2 = new Test1();
		t2.a();
	}
	

}
