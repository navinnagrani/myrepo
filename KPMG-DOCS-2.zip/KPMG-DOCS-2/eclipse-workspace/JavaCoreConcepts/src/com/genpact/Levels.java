package com.genpact;

public enum Levels {
	
}
