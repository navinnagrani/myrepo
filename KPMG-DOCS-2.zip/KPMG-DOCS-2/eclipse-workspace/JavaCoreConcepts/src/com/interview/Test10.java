package com.interview;
interface I1 {
	default void log() {
		System.out.println("I1 in " + I1.class);
	}
}

interface I2 {
	default void log() {
		System.out.println("I2 in " + I2.class);
	}

	
}
public class Test10 {

	public static void main(String[] args) {
		Test10 c = new Test10();
		//sc.log()
	}

}
