package com.interview;

import java.util.*;
import java.util.stream.Collectors;

public class Test3 {

	public static char returnMaxNumber(String name) {
		if (name == "" || name == null || name.equals(null))
			return 0;

		int[] freq = new int[26];
		int max = -1;
		char res = 0;
		char[] str = name.toCharArray();
		int len = str.length;

		for (int i = 0; i < len; i++) {
			if (str[i] != ' ') {
				freq[str[i] - 'a']++;

			}
		}

		for (int i = 0; i < 26; i++) {
			if (max < freq[i]) {
				max = freq[i];
				res = (char) (i + 'a');
			}
		}
		return res;

	}

	public static void maxOcc(String s) {
       ArrayList<Character> arr = (ArrayList<Character>) s.chars().mapToObj(e ->(char)e).collect(Collectors.toList());

        HashSet<Character> hs = new HashSet<>(arr);

        int max = 0;
        int f = 0;
        Character answer = ' ';

        for(Character ch : hs) {
	        f = Collections.frequency(arr,ch);
	        if(f>max) {
	            max = f;
	            answer = ch;
	        }
        }
        //System.out.println(ch + " occurs " + max + " times, the maximum");
        System.out.println(answer);

	}

	public static void main(String[] args) {

		// Print character with max number of occurrences in the given string

		// System.out.println(returnMaxNumber("Navin nagrani"));
		
		maxOcc("Navin nagrani");

		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(5);
		numbers.add(6);
		numbers.add(7);
		numbers.add(8);

		Collections.reverse(numbers);
		numbers.stream().limit(3).forEach(System.out::println);

	}

}
