package com.interview;
import java.util.*;

//Wissen HackerEarth

class A7 {
	public A7() {
		System.out.println("A Const");
	}
	
	public void xyz() {
		System.out.println("A xyz");
	}
}
class B7 extends A7{
	public B7() {
		System.out.println("B Const");
	}
	
	public void xyz() {
		System.out.println("B xyz");
	}
}

public class Test15 {
	/*
	 * boolean flag = true;
        TreeSet<Integer> treeSet = new TreeSet<Integer>();
        for(Integer k : A) {
            if(!treeSet.contains(k)) {
                treeSet.add(k);
            } else {
                flag = false;
            }
        }
        if(flag)
            return treeSet.last();
        else
            return treeSet.first();
	 */
	
	//https://assessment.hackerearth.com/challenges/test/wissen-technology-pvt-ltd-test-draft-1-21/problems/fb09704e2a2e476aa0fd2996ea89f7d8/
	
//	public static void xyz(int i) {
//		
//	}
//	
//	public static int xyz(int i) {
//		
//	}
//	
//	public static void xyz(char c) {
//		
//	}
	
	
	public static void main(String[] args) {
//		A7 a = new B7();
//		a.xyz();
		
		B7 b = new B7();
		b.xyz();
		
		//xyz('1');
	}

}
