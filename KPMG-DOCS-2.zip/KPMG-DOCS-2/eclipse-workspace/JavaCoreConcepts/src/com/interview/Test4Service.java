package com.interview;

import java.net.URI;

//@Service
public class Test4Service {
//	private RestTemplate restTem;
//	
//	public TestService(RestTemplate restTem) {
//		this.restTem = restTem;
//	}
//	
//	@HystrixCommand(fallbackMethod = "relaiable")
//	public String readList() {
//		URI uri = URI.create("http://localhost:8080/recomendation");
//		return this.restTem.getForObject(uri,String.class);
//	}
	
	public String relaiable() {
		return "There is some problem . Stay back application will be up shortly";
	}
	
}
