package com.interview;

public class Test12 {
	public static boolean isPalin(int n) {
		int r, sum = 0, temp;

		temp = n;
		while (n > 0) {
			r = n % 10;
			sum = (sum * 10) + r;
			n = n / 10;
		}
		if (temp == sum)
			return true;
		else
			return false;

	}

	public static int greaterpalindrome(int k) {
		while (!isPalin(k)) {
			k++;
		}
		return k;
	}

	public static void main(String args[]) {
		int a = 11;
		System.out.println(greaterpalindrome(a+1));
	}
}
