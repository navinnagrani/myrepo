package com.interview;

class A{
	
//	A() {
//		System.out.println("A const");
//	}
	
	public void m1() {
		
		System.out.println("A m1");
	}
	public void m2() {
		m1();
		System.out.println("A m2");
	}
}

class B extends A{
	
//	B() {
//		System.out.println("B const");
//	}
//	
//	public void m1() {
//		System.out.println("B m1");
//	}
}

public class Test1 {
	
	
	public static int m1() {
		return 0;
	}
	public static void m1(int i) {
		
	}
	public static void main(String[] args) {
//		A a = new A();
//		B b = new B();
		//B b1 = new A(); Exception
		A a1 = new B();
		a1.m2();

	}

}
