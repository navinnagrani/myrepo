package com.interview;

import java.util.HashMap;
import java.util.Map;

public class Test7 {

	static void treatDis(int draw, int treats, int noOFSeats) {
		int last = ((draw - 1) + (treats - 1)) % noOFSeats + 1;
		//Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		//int count = 1;
		while(treats !=0) {
			System.out.println("Child "+draw+" Treat "+treats);
			//map.put(draw, count);
			treats--;
			draw++;
			if(draw > noOFSeats) {
				draw = 1;
				//count++;
			}
			
			
		}
		
		System.out.println("Seat number which last receive a treat "+last);
		//map.forEach((k,v)->System.out.println("Child "+k+" got "+v+" treats"));
	}

	public static void main(String[] args) {
		treatDis(3, 10, 7);
	}

}
