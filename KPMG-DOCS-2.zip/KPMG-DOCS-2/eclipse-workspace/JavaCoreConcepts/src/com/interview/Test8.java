package com.interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class Base {
	Base() {
		System.out.println("Base const");
	}
	void m1() {
		System.out.println("A mtd");
	}
}

class Derived extends Base {
	Derived() {
		System.out.println("Derived Const");
	}
	void m1() {
		super.m1();
		//System.out.println("B mtd");
	}
}
public class Test8 {

	public static void main(String[] args) {
		
		Base p = new Derived();
		p.m1();
		
//		List<String> lis = new ArrayList<String>();
//		lis.add("Abishek");
//		lis.add("Anju");
//		lis.add("Kamal");
//		lis.add("Anand");
//		
//		System.out.println();
//		
//		Set<String> s = lis.stream().filter(n->n.startsWith("A")).collect(Collectors.toSet());
//		System.out.println(s);
//		
//		String arr[] = {"anand","anant","anagha","ananya","and","any"};
//		
//		System.out.println(longPre(arr));
		
		
	}
	
	static String longPre(String[] a) {
		
		int size = a.length;
		
		if(size == 0)
			return "";
		
		if(size == 1)
			return a[0];
		
		Arrays.sort(a);
		
		int end = Math.min(a[0].length(), a[size-1].length());
		
		int i=0;
		while(i<end && a[0].charAt(i) == a[size-1].charAt(i)) {
			i++;
		}
		
		String pre = a[0].substring(0,i);
		
		
		return pre;
		
	}
	

}
