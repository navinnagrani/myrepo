package com.interview;

class Parent{
	
	
	public void run() {
		System.out.println("Parent run");
		walk();
	}
	public void walk() {
		System.out.println("Parent walk");
	}
	
}

class Child extends Parent{
	
	public void run() {
		System.out.println("Child run");
		super.run();
	}
	public void walk() {
		super.walk();
	}
	
}
public class Test6 {
	
	public static void main(String args[]) throws InterruptedException {
		//Parent p = new Parent();
		//Child c = new Child();
		
		Parent c1 = new Child();
		c1.run();
		//c1.walk();
		
		Parent a = new Child();
		
		
		
		
		
		
		
	}

}
