package com.interview;
import java.util.*;

class Student {
	
	private int id;
	private String name;
	
	
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		if (obj.getClass() != this.getClass()) {
			return false;
		}

		final Student other = (Student) obj;
		if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
			return false;
		}

		if (this.id != other.id) {
			return false;
		}

		return true;
	}
}

public class Test18 {
	
	public static void main(String[] args) {
		Student s1 = new Student(1, "navin");
		Student s2 = new Student(1, "navin");
		Student s3 = new Student(1, "navin");
		Student s4 = new Student(1, "navin");
		Student s5 = new Student(1, "navin");
		Student s6 = new Student(1, "navin");
		Student s7 = new Student(1, "navin");
		
		boolean res = s1.equals(s2);
		System.out.println(res);
		
		HashSet<Student> studentList = new HashSet<Student>();
		studentList.add(s1);
		studentList.add(s2);
		studentList.add(s3);
		studentList.add(s4);
		studentList.add(s5);
		studentList.add(s6);
		studentList.add(s7);
		System.out.println(studentList.size());
		
		HashMap<Student, String> studentMap = new HashMap<Student, String>();
		studentMap.put(s1,"dummy");
		studentMap.put(s2,"dummy");
		studentMap.put(s3,"dummy");
		studentMap.put(s4,"dummy");
		studentMap.put(s5,"dummy");
		studentMap.put(s6,"dummy");
		studentMap.put(s7,"dummy");
		
		System.out.println(studentMap.size());
		
	}

}
