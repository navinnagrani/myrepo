package com.interview;

import java.util.Comparator;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


public class Test9 {

	public static void main(String[] args) {
		
		int a1[] = {1,3,5,7};
		int a2[] = {2,4,6,8,10};
		
		String s = "A new sentence";
		
		Map<Character, Long> m = s.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		m.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getValue,Comparator.reverseOrder()))
		.map(Map.Entry::getKey).collect(Collectors.toList());
		
		
	}
	
	void mergeSortedArr(int a1[],int a2[]) {
		int i=0,j=0,k=0;
		int a3[] = new int[a1.length+a2.length];
		while(i<a1.length && j<a2.length) {
			if(a1[i] < a2[j])
				a3[k++] = a1[i++];
			else
				a3[k++] = a2[j++];
		}
		while(i<a1.length)
			a3[k++] = a1[i++];
		while(j < a2.length)
			a3[k++] = a2[j++];
		
		//for(int i=0;i<a1.length)
	}
	
	
//	A basket consists of a mix of Black and white balls. To write a java program to
//	�	segregate two colored balls
//	�	Expectation: To consider this as an array of 0s and 1s.
//	�	{-1, 0, 1, 2, 1, 0, -1} - This array has a property where consecutive elements differ
//	�	by +1/-1
//	-	Problem: Find an element in the array
//	�	Find the sum of the contiguous subarray which has the largest sum
//	�	Find an element in an array with successive numbers differing by +1 or -1.
//	�	Merge two sorted arrays into one.
//	�	Coding -
//	�	What is JDK, JVM and JRE in Java
//	�	What is Access modifier
//	�	What are language basics
//	�	to design a very basic DB schema for product customer use case
//	�	General question on DB choking.
//	�	DB optimization and execution plans.
//	�	how Spring does Object Management
//	�	Complexity and different between sorting (N^2) and finding largest number (N)
//	�	algorithm to find largest number in array
//	�	Multi Thread Concepts
//	�	DB optimization and execution plans
//	�	Does POJO object store different values in differe
	
	

}
