package com.interview;

import java.util.Arrays;

public class Test5 {
	
	public static void main(String args[]) {
		int arr[] = {1,2,4,6,9,12,15,25};
		//Test5.findMissing(arr);
		System.out.println(Test5.findAnagram("map","ami"));
		System.out.println("1"+2);
		
		
		/*
		 * @Controller is used in legacy systems which use JSPs. it can return views. 
		 * @RestController is to mark the controller is 
		 * providing REST services with JSON response type. so it wraps @Controller and @ResponseBody annotations together
		 * @Controller returns View. @RestController returns ResponseBody
		 * 'view' is your front end like jsp or html. ResponseBody can be xml, json,yaml
		 * @Controller: This annotation is just a specialized version of @Component and it allows 
		 * the controller classes to be auto-detected based on classpath scanning.
		   @RestController: This annotation is a specialized version of @Controller 
		   which adds @Controller and @ResponseBody annotation automatically so we do not have 
		   to add @ResponseBody to our mapping methods
		 */
		
	}
	
	public static void findMissing(int arr[]) {
		int diff = arr[0] - 0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]-i != diff) {
				while(diff < arr[i]-i) {
					System.out.println((i+diff));
					diff++;
				}
			}
		}
	}
	
	public static boolean findAnagram(String s1,String s2) {
		char[] c1 = s1.toCharArray();
		char[] c2 = s2.toCharArray();
		
		if(c1.length != c2.length)
			return false;
		
		Arrays.sort(c1);
		Arrays.sort(c2);
		
		if(c1.equals(c2))
			return true;
		return false;
	}
}

