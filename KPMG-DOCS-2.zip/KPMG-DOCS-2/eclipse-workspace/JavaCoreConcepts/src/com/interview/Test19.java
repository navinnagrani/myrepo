package com.interview;

import java.util.HashMap;

class A10 {
	public static void print() {
		System.out.println("Color is red");
	}
}

class B10 extends A10 {
	public static void print() {
		System.out.println("Color is b");
	}
}
public class Test19 {

	public static void main(String[] args) {
		HashMap<String,Integer> map=new HashMap();
		String x="Levis";
		String y=new String ("Levis");

		//Search for two datasources with single entity jpa repo spring boot
		//Search for two controllers with single service multiple requests to two controllers how singleton in spring boot
		//Ans :https://stackoverflow.com/questions/41179635/how-spring-serves-singleton-bean-to-multiple-request-at-the-same-time

		map.put(x,13);
		map.put(y,14);



		System.out.println(map.get(x));;
		System.out.println(map.get(y));;
		System.out.println(map.get(new String("Levis")));;
		
		A10 a=new B10();
		a.print();
	}

}
