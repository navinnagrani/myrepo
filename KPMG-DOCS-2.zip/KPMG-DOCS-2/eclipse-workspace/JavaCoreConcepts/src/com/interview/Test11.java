package com.interview;
import java.util.*;
class Employee {
	public String name;

	public Employee(String name) {
		super();
		this.name = name;
	}
	
	
	
}
public class Test11 {

	public static void main(String[] args) {
		List<Employee> lis = new ArrayList<Employee>();
		lis.add(new Employee("abc"));
		lis.add(new Employee("abc"));
		lis.add(new Employee("abc"));
		lis.add(new Employee("abc"));
		lis.add(new Employee("abc"));
		lis.add(new Employee("xyz"));
		lis.add(new Employee("xyz"));
		lis.add(new Employee("xyz"));
		lis.add(new Employee("xyz"));
		lis.add(new Employee("xyz"));
		
		Map<String, Integer> hm = new HashMap<String, Integer>();
		for (Employee i : lis) {
            Integer j = hm.get(i);
            hm.put(i.name, (j == null) ? 1 : j + 1);
        }
		
		for (Map.Entry<String, Integer> val : hm.entrySet()) {
            System.out.println("Employee " + val.getKey() + " "+ "Count"+ ": " + val.getValue());
        }
	}

}
