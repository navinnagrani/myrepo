package com.interview;

import java.lang.reflect.Constructor;
import java.util.*;
import java.util.stream.Collectors;

public class Test4 {
	
	public static void main(String args[]) {
		HashMap<Integer,String> m = new HashMap<Integer, String>();
		m.put(1, "Navin");
		m.put(2, "Kamal");
		m.put(3, "Suyash");
		m.put(4, "Rajesh");
		m.put(5, "Navin");
		
		System.out.println(m.keySet().stream().collect(Collectors.toCollection(HashSet::new)));
		System.out.println(m.values().stream().collect(Collectors.toCollection(HashSet::new)));
		
		System.out.println(palin("navin"));
		System.out.println(palin("madam"));
		
		
		SingleTon singleTon = SingleTon.getInstance();
		SingleTon singleTon2 = null;
		
		
		String s1 = new String("string");
		String s2 = "string";
		String s3 = new String("string");
		
		
		try {
			Constructor[] constructor = SingleTon.class.getDeclaredConstructors();
			for(Constructor c : constructor) {
				c.setAccessible(true);
				singleTon2 = (SingleTon) c.newInstance();
				break;
			}
			System.exit(1);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Finally");
		}
		
		System.out.println(singleTon.hashCode());
		System.out.println(singleTon2.hashCode());
		
		//Enum can be used
		
	}
	
	static boolean isPalin(String s,int st,int e) {
		if(st==e)
			return true;
		
		if((s.charAt(st)) != (s.charAt(e))) 
			return false;
		
		if(st < e + 1)
			return isPalin(s,st+1,e-1);
		
		return true;
	}
	
	static boolean palin(String str) {
		int n = str.length();
		
		if(n == 0)
			return true;
		return isPalin(str,0,n-1);
	}
	
}

class SingleTon {
	
	private static final SingleTon instance = new SingleTon();
	
	private SingleTon() {}
	
	public static SingleTon getInstance() {
		return instance;
	}
}
