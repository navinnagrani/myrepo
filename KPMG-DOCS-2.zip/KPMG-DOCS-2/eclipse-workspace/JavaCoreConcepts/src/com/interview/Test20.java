package com.interview;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class EmployeeClass {
	String name;
	int salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public EmployeeClass(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmployeeClass [name=" + name + ", salary=" + salary + "]";
	}
	
	
	
}

class StudentClass {
	String name;
	HashMap<String, Double> mapOfMarks;
	
	
	public StudentClass(String name, HashMap<String, Double> mapOfMarks) {
		super();
		this.name = name;
		this.mapOfMarks = mapOfMarks;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public HashMap<String, Double> getMapOfMarks() {
		return mapOfMarks;
	}
	public void setMapOfMarks(HashMap<String, Double> mapOfMarks) {
		this.mapOfMarks = mapOfMarks;
	}
}

public class Test20 {
	
	public static HashMap<String, Double> getAvgMarks(List<StudentClass> students) {
		HashMap<String, Double> result = new HashMap<String, Double>();
		for(StudentClass st : students) {
			double avg = st.getMapOfMarks().values().stream().mapToDouble(Double::doubleValue).average().orElse(0);
			result.put(st.getName(), avg);
			
		}
		return result;
	}
	
	public static void getAvgSalByCompany(HashMap<String, HashMap<String, Integer>> emps) {
		for(Entry<String, HashMap<String, Integer>> emp : emps.entrySet()) {
			double avg = emp.getValue().values().stream().mapToDouble(Integer::doubleValue).average().orElse(0);
			System.out.println("Employee "+emp.getKey()+" Average Salary "+avg);
		}
	}
	
	public static void main(String[] args) {
		
		HashMap<String, Double> marks1 = new HashMap<String, Double>();
		marks1.put("English", 8.1);
		marks1.put("Maths", 4.5);
		marks1.put("Physics", 5.7);
		marks1.put("Science", 9.3);
		marks1.put("Economics", 7.9);
		marks1.put("History", 6.0);
		StudentClass s1 = new StudentClass("Navin", marks1);
		List<StudentClass> stuList = new ArrayList<StudentClass>();
		stuList.add(s1);
		System.out.println(getAvgMarks(stuList));
		
		
		HashMap<String, HashMap<String, Integer>> empMap = new HashMap<String, HashMap<String,Integer>>();
		HashMap<String, Integer> map1 = new HashMap<String, Integer>();
		map1.put("Accenture", 10000);
		map1.put("ATCS", 50000);
		map1.put("KPMG", 40000);
		map1.put("TCS", 8000);
		empMap.put("Navin", map1);
		HashMap<String, Integer> map2 = new HashMap<String, Integer>();
		map2.put("Accenture", 20000);
		map2.put("ATCS", 40000);
		map2.put("KPMG", 60000);
		map2.put("TCS", 80000);
		empMap.put("Ramesh", map2);
		getAvgSalByCompany(empMap);
		
		
		List<EmployeeClass> empList = new ArrayList<EmployeeClass>();
		empList.add(new EmployeeClass("Navin", 6000));
		empList.add(new EmployeeClass("Ramesh", 2000));
		empList.add(new EmployeeClass("Suresh", 8000));
		empList.add(new EmployeeClass("Hamla", 8700));
		empList.add(new EmployeeClass("Kamla", 4500));
		empList.add(new EmployeeClass("Jeevan", 6400));
		empList.add(new EmployeeClass("Kevin", 9000));
		empList.add(new EmployeeClass("Lalu", 3800));
		empList.add(new EmployeeClass("Balu", 5700));
		empList.add(new EmployeeClass("Chalu", 10000));
		
		List<EmployeeClass> sortedEmployees = empList.stream().sorted(Collections.reverseOrder(Comparator.comparingInt(EmployeeClass::getSalary)))
				.collect(Collectors.toList());
		
		
		List<EmployeeClass> top5 = sortedEmployees.stream().limit(5).collect(Collectors.toList());
		System.out.println(top5);
										
	}

}
