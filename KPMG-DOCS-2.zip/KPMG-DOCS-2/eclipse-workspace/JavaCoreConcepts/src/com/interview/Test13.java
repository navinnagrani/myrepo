package com.interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test13 {
	
	static void printNum(int a[],int k) {
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		for(int i=0;i<a.length;i++) {
			m.put(a[i], m.getOrDefault(a[i], 0)+1);
		}
		List<Map.Entry<Integer, Integer>> lis  = new ArrayList<Map.Entry<Integer,Integer>>(m.entrySet());
		
		Collections.sort(lis,new Comparator<Map.Entry<Integer, Integer>>() {
			public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
				if(o1.getValue() == o2.getValue())
					return o2.getKey() - o1.getKey();
				else
					return o2.getValue() - o1.getValue();
			}
		});
		
		for(int i=0;i<k;i++) {
			System.out.println(lis.get(i).getKey());
		}
	}
	
	public static void main(String[] args) {
		int nums[] = {1};
		int k = 1;
		printNum(nums, k);
		
		
		
	}

}
