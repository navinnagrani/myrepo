package com.interview;

import java.text.ParseException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.util.Scanner;

/*
 * select
  country,
  coalesce(sum(se.value), 0) as export,
  coalesce(sum(si.value), 0) as import
from companies c

left join trades se
on c.name = se.seller

left join trades si
on c.name = si.buyer

group by
  country
 */

public class Test14 {
	public static String[] solution(String S) throws ParseException {
		String res[] = new String[2];
		LocalDate inputDate = LocalDate.parse(S);
		System.out.println(inputDate);
		
		int currYear = inputDate.getYear();
		int currMonth = inputDate.getMonthValue();
		
		String financiyalYearFrom="";
		String financiyalYearTo="";
		
		if (currMonth < 4) {
		    financiyalYearFrom= (currYear)+"-04-01";
		    financiyalYearTo="31-03-"+(currYear+1);
		} else {
		    financiyalYearFrom=(currYear-1)+"-04-01";
		    LocalDate fiscalYearFrom = LocalDate.parse(financiyalYearFrom);
		    if(isWeekEnd(fiscalYearFrom)) {
				DayOfWeek day = DayOfWeek.of(fiscalYearFrom.get(ChronoField.DAY_OF_WEEK));
				fiscalYearFrom = day == DayOfWeek.SATURDAY ? fiscalYearFrom.plusDays(2)  : fiscalYearFrom.plusDays(1);
			}
		    financiyalYearFrom = fiscalYearFrom.toString();
		    
		    
		    financiyalYearTo=(currYear)+"-03-31";
		    LocalDate fiscalYearTo = LocalDate.parse(financiyalYearTo);
		    if(isWeekEnd(fiscalYearTo)) {
				DayOfWeek day = DayOfWeek.of(fiscalYearTo.get(ChronoField.DAY_OF_WEEK));
				fiscalYearTo = day == DayOfWeek.SATURDAY ? fiscalYearTo.minusDays(1)  : fiscalYearTo.minusDays(2);
			}
		    financiyalYearTo = fiscalYearTo.toString();
		}
		
		
		res[0] = financiyalYearFrom;
		res[1] = financiyalYearTo;
		
		return res;
	}
	
	public static boolean isWeekEnd(LocalDate d) {
		DayOfWeek day = DayOfWeek.of(d.get(ChronoField.DAY_OF_WEEK));
		return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;
	}
	public static void main(String[] args) throws ParseException {
		//Scanner sc = new Scanner(System.in);
		String date = "2018-10-06";	//sc.next();
		String arr[] = solution(date);
		for(String s:arr) {
			System.out.println(s);
		}
	}

}
