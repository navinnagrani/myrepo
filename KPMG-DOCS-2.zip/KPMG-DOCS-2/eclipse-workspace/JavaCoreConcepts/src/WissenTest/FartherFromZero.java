package WissenTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class FartherFromZero {
	public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter wr = new PrintWriter(System.out);
        int N = Integer.parseInt(br.readLine().trim());
        int[] A = new int[N];
        String[] inp = br.readLine().split(" ");
        for(int i=0;i<N;i++)
        {
            A[i] = Integer.parseInt(inp[i]);
        }
        int out_ = solve(N, A);
        System.out.println(out_);

         wr.close();
         br.close();
    }
    static int solve(int N,int[] A){
        // TreeSet<Integer> ts = new TreeSet<Integer>();
        // for(int i=0;i<N;i++) {
        //     ts.add(A[i]);
        // }
        // int maxV = ts.last();
        // int minV = ts.first();

        // if(Math.abs(minV) > maxV) {
        //     return minV;
        // }
        // return maxV;

        int be = 0;
        for(int i=0;i<N;i++) {
            if(Math.abs(A[i]) > Math.abs(be)){
                be = A[i];
            } else if(Math.abs(be) == Math.abs(A[i]) && be > A[i]) {
                be = A[i];
            }
        }
        return be;
    }
    
    
    //write a query that prints name of a child and his parents in individual coulmns respectively
    
//	select c.name Child,
//	MAX(CASE when p.gender = 'M' then p.name END) Father,
//	MAX(CASE when p.gender = 'F' then p.name END) Mother
//	from relations r
//	inner join people c on c.id = r.c_id
//	inner join people p on p.id = r.p_id
//	group by c.name
}
