import java.util.concurrent.Executor;
import java.util.concurrent.Future;

import pkg.*;
import pkg.test.MyClass;

class MyAdd<T> {
	void add(T t) {
		
	}
}

public class GenEx {

	public static void main(String[] args) {
		

	}

}
