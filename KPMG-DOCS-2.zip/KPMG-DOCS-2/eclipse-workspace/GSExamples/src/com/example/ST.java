package com.example;

public class ST {
	String s = null;
	String t = null;
	int i=0;
	int sl =0;
	int tl = 0;
	
	public ST(String in, String tk) {
		s =in;
		t = tk;
		sl = s.length();
		tl = t.length();
	}
	public String getN() {
		int k=0;
		char c,d;
		StringBuffer sb = new StringBuffer("");
		for(;i<sl;i++) {
			c = s.charAt(i);
			for(k=0;k<tl;k++) {
				d = t.charAt(k);
				if(c==d && sb.length()>0) {
					i++;return sb.toString();
				}
			}
			sb.append(c);
		}
		if(sb.length()>0)
			return sb.toString();
		else
			return null;
	}
	public static void main(String[] args) {
		ST st = new ST("This is my String"," \t\n");
		System.out.println(st.getN());
		System.out.println(st.getN());
		System.out.println(st.getN());
		System.out.println(st.getN());
		System.out.println(st.getN());

	}

}
