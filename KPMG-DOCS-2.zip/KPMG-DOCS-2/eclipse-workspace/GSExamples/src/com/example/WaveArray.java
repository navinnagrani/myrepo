package com.example;

import java.util.Arrays;

public class WaveArray {
	
	static void swap(int arr[] ,int a , int b) {
		int temp = arr[a];
		arr[a]= arr[b];
		arr[b] = temp;
	}
	
	static void waveSort(int a[]) {
		Arrays.sort(a);
		for(int i=0;i<a.length-1;i+=2) {
			swap(a, i, i+1);
		}
	}
	
	public static void main(String[] args) {
		int arr[] = {10, 90, 49, 2, 1, 5, 23};
		waveSort(arr);
		for(int i : arr) {
			System.out.println(i + " ");
		}
	}

}
