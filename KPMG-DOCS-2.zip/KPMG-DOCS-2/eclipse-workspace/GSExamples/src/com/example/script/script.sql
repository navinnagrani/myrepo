set schema user;

CREATE TABLE BOOK (
	BOOKNAME VARCHAR(45),
	AUTHOR VARCHAR(45)
);

select * from book;

select author from BOOK
group by author
having (count(*) > 2)



