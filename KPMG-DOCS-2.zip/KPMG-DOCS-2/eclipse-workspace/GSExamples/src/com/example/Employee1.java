package com.example;

import java.util.Collections;
import java.util.List;

final class Employee1 {
	private String name;
	private int salary;
	private Department depart;
	private List<Department> departList;
	public Employee1(String name) {
		super();
		this.name = name;
		this.depart = depart;
		this.departList = departList;
	}
	public String getName() {
		return name;
	}
	
	public Department getDepart() throws CloneNotSupportedException  {
		return (Department) depart.clone();
	}
	
	public List<Department> getDepartList() {
		return Collections.unmodifiableList(this.departList);
	}
	
	
	
}
