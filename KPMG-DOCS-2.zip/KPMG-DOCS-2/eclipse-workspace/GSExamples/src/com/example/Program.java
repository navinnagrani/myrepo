package com.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Program {
	
	
	
	public static boolean isValidSubsequence(List<Integer> array, List<Integer> sequence) {
	    int arrIdx=0;
	    int seqIdx=0;
	    while(arrIdx < array.size() && seqIdx < sequence.size()) {
	    	if(array.get(arrIdx).equals(sequence.get(seqIdx))) {
	    		seqIdx++;
	    	}
	    	arrIdx++;
	    }
	    return seqIdx == sequence.size();
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		List<Integer> arr1 = new ArrayList<Integer>();
		arr1.add(5);
		arr1.add(1);
		arr1.add(22);
		arr1.add(25);
		arr1.add(6);
		arr1.add(-1);
		arr1.add(8);
		arr1.add(10);
		
		List<Integer> arr2 = new ArrayList<Integer>();
		//arr2.add(5);
		arr2.add(1);
		//arr2.add(22);
		//arr2.add(25);
		arr2.add(6);
		arr2.add(-1);
		//arr2.add(8);
		//arr2.add(10);
		arr2.add(10);
		boolean check = isValidSubsequence(arr1,arr2);
		System.out.println(check);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int noOfTestCase = Integer.parseInt(br.readLine());
		for(int i=0;i<noOfTestCase;i++) {
			String input = br.readLine();
			System.out.println(input.split(" ").length);
		}
		br.close();
		

	}

}
