package com.example;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.*;

class Data implements Comparable<Data>
{
    int value, count, index;
 
    public Data(int value, int count, int index)
    {
        this.value = value;
        this.count = count;
        this.index = index;
    }
 
    public int compareTo(Data obj)
    {
        // If two elements have different frequencies, then
        // the one which has more frequency should come first
        if (this.count != obj.count) {
            return obj.count - this.count;
        }
 
        // If two elements have the same frequencies, then the
        // one which has less index should come first (Asending order)
        return obj.index-this.index;
    }
}


public class MyDemo {
	
	/*static void sortArray(Integer[] arr) {
		//List<Integer> lis = Arrays.asList(arr);
		int n = arr.length;
		HashMap<Integer, Integer> mapcount = new HashMap<Integer, Integer>();
		HashMap<Integer, Integer> indexs = new HashMap<Integer, Integer>();
		for(int i=0;i<n;i++) {
			if(mapcount.containsKey(arr[i])) {
				mapcount.put((arr[i]), mapcount.get(arr[i]+1));
			} else {
				mapcount.put(arr[i], 1);
				indexs.put(arr[i], i);
			}
		}
		Arrays.sort(arr,new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				int freq1 = mapcount.get(o1);
				int freq2 = mapcount.get(o2);
				if(freq1 != freq2) {
					return freq2- freq1;
				} else {
					return indexs.get(o1) - indexs.get(o2);
				}
				
				
			}
		});
		
		for(int j=0;j<n;j++) {
			System.out.println(arr[j]);
		}
		
	}*/
	
	/*static void sortArray(Integer[] inputArray) {
		Map<Integer, Integer> elementCountMap = new LinkedHashMap<>();
		for (int i = 0; i < inputArray.length; i++) {
			if (elementCountMap.containsKey(inputArray[i])) {
				// If element is present in elementCountMap, increment its value by 1

				elementCountMap.put(inputArray[i], elementCountMap.get(inputArray[i]) + 1);
			} else {
				// If element is not present, insert this element with 1 as its value

				elementCountMap.put(inputArray[i], 1);
			}
		}
		ArrayList<Integer> sortedElements = new ArrayList<>();
		elementCountMap.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
				.forEach(entry -> {
					for (int i = 1; i <= entry.getValue(); i++)
						sortedElements.add(entry.getKey());
				});
		System.out.println("Input Array :"+Arrays.toString(inputArray));
        
        System.out.println("Sorted Array Elements In Descending Order Of their Frequency :");
         
        System.out.println(sortedElements);
	} */
	
	public static void sortArray(Integer[] arr)
	{
	    if (arr == null || arr.length < 2) {
	        return;
	    }

	    // insert frequency of each array element into the map
	    // and index of its first occurrence in the array
	    Map<Integer, Data> hm = new HashMap<>();
	    for (int i = 0; i < arr.length; i++)
	    {
	        hm.putIfAbsent(arr[i], new Data(arr[i], 0, i));
	        hm.get(arr[i]).count++;
	    }

	    // sort the values based on a custom comparator
	    List<Data> values = hm.values().stream()
	            .sorted()
	            .collect(Collectors.toList());

	    int k = 0;
	    for (Data data: values)
	    {
	        for (int j = 0; j < data.count; j++) {
	            arr[k++] = data.value;
	        }
	    }
	}
	
	public static void main(String[] args) {
		
		Integer[] arr = {4,5,6,5,3,4};
		Integer[] arr2 = {7,5,9,3,9,9};
		sortArray(arr);
		sortArray(arr2);
		
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(arr2));
		
	}

}
