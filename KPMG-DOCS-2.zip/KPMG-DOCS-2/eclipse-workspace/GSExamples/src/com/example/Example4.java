package com.example;

public class Example4 {
	
	static void findLargest(int arr[]) {
		int largest = arr[0];
		
		for(int i=1;i<arr.length;i++) {
			if(arr[i] > largest) {
				largest = arr[i];
			}
		}
		System.out.println("Largest "+largest);
	}
	
	public static void main(String args[]) {
		
		int arr[] = {6,8,12,9,55,34,2,4};
		findLargest(arr);
	}
}
