package com.example;

import java.util.ArrayList;
import java.util.*;

public class CheckOcc {
	public void WordOccurSortExample()
	{
	    ArrayList<String> occuringWords = new ArrayList<String>();
	    occuringWords.add("Menios".intern());
	    occuringWords.add("Menios".intern());
	    occuringWords.add("Menios".intern());
	    occuringWords.add("Menios".intern());
	    occuringWords.add("Moo".intern());
	    occuringWords.add("Moo".intern());
	    occuringWords.add("Moo".intern());
	    occuringWords.add("Moo".intern());
	    occuringWords.add("Moo".intern());
	    occuringWords.add("Boo".intern());
	    occuringWords.add("Boo".intern());
	    occuringWords.add("Boo".intern());

	    HashMap<String, Integer> occurances = new HashMap<String, Integer>();

	    Iterator<String> it = occuringWords.iterator();
	    String word;
	    Integer count;
	    while(it.hasNext())
	    {
	        word = it.next();

	        if((count = occurances.get(word))==null)
	        occurances.put(word, 1);
	        else
	        occurances.put(word, new Integer(count+1)); 
	    }       

	    ValueComparator bvc =  new ValueComparator(occurances);
	    TreeMap<String,Integer> sorted_map = new TreeMap<String,Integer>(bvc);

	    System.out.println("unsorted map: "+occuringWords);
	    sorted_map.putAll(occurances);
	    System.out.println("results: "+sorted_map);
	}
}
class ValueComparator implements Comparator<String> {

    HashMap<String, Integer> base;
    public ValueComparator(HashMap<String, Integer> base) {
        this.base = base;
    }

    // Note: this comparator imposes orderings that are inconsistent with equals.    
    public int compare(String a, String b) {
        if (base.get(a) >= base.get(b)) {
            return -1;
        } else {
            return 1;
        } // returning 0 would merge keys
    }

}
