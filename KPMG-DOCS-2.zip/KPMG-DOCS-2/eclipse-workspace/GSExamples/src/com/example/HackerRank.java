package com.example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HackerRank {
	
	public int sockMerchant(int n , List<Integer> ar) {
		List<Integer> colors = new ArrayList<Integer>();
	    int pairs = 0;

	    for (int i = 0; i < n; i++) {
	        if (!colors.contains(ar.get(i))) {
	            colors.add(ar.get(i));
	        } else {
	            pairs++;
	            colors.remove(ar.get(i));
	        }
	    }
		return pairs;
	}
	public int countingValleys(int steps , String path) {
		int valley = 0;
		int level = 0;
		for(char c : path.toCharArray()) {
			if(c == 'U') ++level;
			if(c == 'D') --level;
			
			if(level == 0 && c=='U') ++valley;
		}
		
		return valley;
	}
	
	public int jumpingOnClouds(List<Integer> c) {
		int count = 0;
		for (int i = 0; i < c.size() - 1; i++) {
		    if (c.get(i) == 0) i++;
		    count++;
		}
		return count;
	}
	
	public long repeatedString(String s, int num) {
		String repeated = s.repeat(num);
		long count = 0;
		for(char c : repeated.toCharArray()) {
			if(c == 'a') count++;
		}
		long factor = (num / s.length());
		long rem = (num % s.length());
		count = factor * count;
		for (int i = 0; i < rem; i++)
			if (s.charAt(i) == 'a')
				count++;
		return count;
		
	}
	
	public int[] rotLeft(int arr[], int d) {
		for (int i = 0; i < d; i++) {
			int j, first;
			first = arr[0];
			for (j = 0; j < arr.length - 1; j++) {
				arr[j] = arr[j + 1];
			}
			arr[j] = first;
		}
		return arr;
	}
	
	public static void minimumBribes(List<Integer> q) {
		int ans = 0;
	    for (int i = q.size() - 1; i >= 0; i--) {
	        if (q.get(i) - (i + 1) > 2) {
	            System.out.println("Too chaotic");
	            return;
	        }
	        for (int j = Math.max(0, q.get(i) - 2); j < i; j++)
	            if (q.get(j) > q.get(i)) ans++;
	    }
	   System.out.println(ans);
	}
	public static void main(String[] args) {
		List<Integer> l = new ArrayList<Integer>();
		l.add(10);
		l.add(20);
		l.add(20);
		l.add(10);
		l.add(10);
		l.add(30);
		l.add(50);
		l.add(10);
		l.add(20);
		
		int n = 9;
		HackerRank h = new HackerRank();
		System.out.println(h.sockMerchant(n, l));
		
		int steps = 8;
		String path = "UDDDUDUU";
		System.out.println(h.countingValleys(steps, path));
		
		List<Integer> l1 = new ArrayList<Integer>();
		l1.add(0);
		l1.add(1);
		l1.add(0);
		l1.add(0);
		l1.add(0);
		l1.add(1);
		l1.add(0);
		System.out.println(h.jumpingOnClouds(l1));
		
		String s = "aba";
		int num = 10;
		long count = 0;
		for (char c : s.toCharArray())
			if (c == 'a')
				count++;

		long factor = (num / s.length());
		long rem = (num % s.length());
		count = factor * count;
		for (int i = 0; i < rem; i++)
			if (s.charAt(i) == 'a')
				count++;
		System.out.println(count);
		
		int[] a = {1, 2, 3, 4, 5};
		int rotations = 4;
		int arr[] = h.rotLeft(a, rotations);
		for(int i = 0; i< arr.length; i++){  
            System.out.print(arr[i] + " ");  
        }  

		List<Integer> queue = new ArrayList<Integer>();
		queue.add(1);
		queue.add(2);
		queue.add(3);
		queue.add(5);
		queue.add(4);
		queue.add(6);
		queue.add(7);
		queue.add(8);
		h.minimumBribes(queue);
	}

}
