package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class LinkedList {
	public int value;
	public LinkedList next;

	public LinkedList(int value) {
		this.value = value;
		next = null;
	}

	@Override
	public String toString() {
		return "LinkedList [value=" + value + ", next=" + next + "]";
	}
	
}
public class HardProblems {
	public static LinkedList shiftLinkedList(LinkedList head, int k) {
		int listLen = 1;
		
		LinkedList listTail = head;
		
		while(listTail.next!=null ) {
			listTail = listTail.next;
			listLen++;
		}
		int offset = Math.abs(k) % listLen;
		if(offset == 0) return head;
		int newTailPosi = k > 0 ? listLen - offset : offset;
		
		LinkedList newTail = head;
		
		for(int i=1;i<newTailPosi;i++) {
			newTail = newTail.next;
		}
		LinkedList newHead = newTail.next;
		newTail.next = null;
		listTail.next = head;
		return newHead;
	}
	
	public static List<List<Integer>> fourSum(int[] nums, int target) {
		
		Arrays.sort(nums);
		return kSum(nums,target , 0 , 4);
		

	}
	private static List<List<Integer>> kSum(int[] nums, int target, int start, int k) {
		List<List<Integer>> res = new ArrayList<>();
	    if (start == nums.length || nums[start] * k > target || target > nums[nums.length - 1] * k)
	        return res;
	    if (k == 2)
	        return twoSum(nums, target, start);
	    for (int i = start; i < nums.length; ++i)
	        if (i == start || nums[i - 1] != nums[i])
	            for (var set : kSum(nums, target - nums[i], i + 1, k - 1)) {
	                res.add(new ArrayList<>(Arrays.asList(nums[i])));
	                res.get(res.size() - 1).addAll(set);
	            }
	    return res;
	}
	public static List<List<Integer>> twoSum(int[] nums, int target, int start) {
	    List<List<Integer>> res = new ArrayList<>();
	    Set<Integer> s = new HashSet<>();
	    for (int i = start; i < nums.length; ++i) {
	        if (res.isEmpty() || res.get(res.size() - 1).get(1) != nums[i])
	            if (s.contains(target - nums[i]))
	                res.add(Arrays.asList(target - nums[i], nums[i]));
	        s.add(nums[i]);
	    }
	    return res;
	}
	
	public static int findUnsortedSubarray(int[] nums) {
		int[] snums = nums.clone();
		Arrays.sort(snums);
		int start = snums.length, end = 0;
		for (int i = 0; i < snums.length; i++) {
			if (snums[i] != nums[i]) {
				start = Math.min(start, i);
				end = Math.max(end, i);
			}
		}
		return (end - start >= 0 ? end - start + 1 : 0);
	}
	
	public static int longestConsecutive(int[] nums) {
		int longestStreak = 0;

        for (int num : nums) {
            int currentNum = num;
            int currentStreak = 1;

            while (arrayContains(nums, currentNum + 1)) {
                currentNum += 1;
                currentStreak += 1;
            }

            longestStreak = Math.max(longestStreak, currentStreak);
        }

        return longestStreak;
	}
	private static boolean arrayContains(int[] arr, int num) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == num) {
                return true;
            }
        }

        return false;
    }
	private static int minUtility(int[] nums) {
		int min = nums[0];
		for(int i=1;i<nums.length;i++) {
			if(nums[i] < min) {
				min = nums[i];
			}
		}
		return min;
	}
	
	private static int maxUtility(int[] nums) {
		int max = nums[0];
		for(int i=1;i<nums.length;i++) {
			if(nums[i] > max) {
				max = nums[i];
			}
		}
		return max;
	}
	
	public static int candy(int[] ratings) {
		
		int[] candies = new int[ratings.length];
        Arrays.fill(candies, 1);
        for (int i = 1; i < ratings.length; i++) {
            if (ratings[i] > ratings[i - 1]) {
                candies[i] = candies[i - 1] + 1;
            }
        }
        int sum = candies[ratings.length - 1];
        for (int i = ratings.length - 2; i >= 0; i--) {
            if (ratings[i] > ratings[i + 1]) {
                candies[i] = Math.max(candies[i], candies[i + 1] + 1);
            }
            sum += candies[i];
        }
        return sum;
	}

	public static void main(String[] args) {
		
		System.out.println("-----Shift Linked List------");
		LinkedList list = new LinkedList(0);
		list.next = new LinkedList(1);
		list.next.next = new LinkedList(2);
		list.next.next.next = new LinkedList(3);
		list.next.next.next.next = new LinkedList(4);
		list.next.next.next.next.next = new LinkedList(5);
		int valPass = 2;
		System.out.println("Result is :"+shiftLinkedList(list, valPass));
		
		System.out.println("-----Four Number Sum------");
		int arrFourSum[] = {1,0,-1,0,-2,2};
		System.out.println("Result is : "+fourSum(arrFourSum, 2));
		
		System.out.println("-------Subarray Sort------");
		int arrSubArrSort[] = {2,6,4,8,10,9,15};
		System.out.println("Result is : "+findUnsortedSubarray(arrSubArrSort));
		
		System.out.println("------Largest Range------");
		int arrLarRange[] = {100,4,200,1,3,2};
		System.out.println("Result is : "+longestConsecutive(arrLarRange));
		
		System.out.println("-------Min Rewards------");
		int arrMinReward[] = {1,0,2};
		System.out.println("Result is : "+candy(arrMinReward));
		

	}

}
