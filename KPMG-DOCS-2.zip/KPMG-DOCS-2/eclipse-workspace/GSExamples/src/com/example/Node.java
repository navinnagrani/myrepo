package com.example;

import java.util.*;

public class Node {
	public static void main(String args[]) {
		List<String> l = new ArrayList<String>();
		l.add("A");
		l.add("B");
		l.add("C");
		Iterator<String> it = l.iterator();
		while(it.hasNext()) {
			if(it.next().equals("A")) {
				l.remove(1);
			}
		}
	}
}


