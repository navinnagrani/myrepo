package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Teacher {
	
	String designation = "Teacher";
	
	void does() {
		System.out.println("Teaching");
	}
}




public class MathTeacher extends Teacher {
	String subject = "Maths";
	
	public static int hishestAverage(String[][] scores) {
        if(scores == null || scores.length == 0) {
            return -1;
        }
        int highestAve = 0;
        Map<String, List<Integer>> map = new HashMap<>();
        
        for(int i = 0; i < scores.length; i++) {
            List<Integer> scoreList = map.get(scores[i][0]);
            if(scoreList == null) {
                List<Integer> currentScore = new ArrayList<>();
                currentScore.add((int) Math.floor(Double.parseDouble(scores[i][1])));
                map.put(scores[i][0], currentScore);
            } else {
                scoreList.add(Integer.valueOf(scores[i][1]));
                map.put(scores[i][0], scoreList);
            }
        }
        
        //go through the map. find the largest ave
        for(Map.Entry<String, List<Integer>> entry : map.entrySet()) {
            int currentAveScore = avgCal(entry.getValue());
            
            highestAve = Math.max(highestAve, currentAveScore);
        }
        
        return highestAve;
    }
	
	static int avgCal(List<Integer> scores) {
		int len = scores.size();
		int sum=0;
		for(int score : scores) {
			sum += score;
		}
		Math.floor(sum/len);
		double ave = Math.floor(sum/len);
		System.out.println(ave);
		return (int) ave;
	}
	
	public static void main(String[] args) {
//		MathTeacher mt = new MathTeacher();
//		System.out.println("Designation "+mt.designation);
//		System.out.println("Subject "+mt.subject);
//		mt.does();
		
		String[][] passValues = { {"Mike","30.9"},{"Milo","33"},{"Kishan","45"},{"Dilwa","56"}};
		
		
//		List<Integer> pass = new ArrayList<Integer>();
//		pass.add(88);
//		pass.add(32);
//		pass.add(99);
//		pass.add(43);
		
		int aveg = hishestAverage(passValues);
		//int aveg = avgCal(pass);
		System.out.println("Final "+aveg);

	}

}
