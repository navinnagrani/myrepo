package com.example;

import java.util.*;

public class Encryption {

	public static String encryption(String s) {
		int letters = s.length();
	    int rows = (int)(Math.floor(Math.sqrt(letters)));
	    int cols = (int)(Math.ceil(Math.sqrt(letters)));
	    String result = "";
	    char[] c = s.toCharArray();
	    for (int i = 0; i < cols; i++){
	        int j = i;
	        while (j < s.length()){
	            result += c[j];
	            j += cols;
	        }
	        result += " ";
	    }

	    return result;

	}

	public static void main(String[] args) {
		System.out.println(encryption("haveaniceday"));
	}

}
