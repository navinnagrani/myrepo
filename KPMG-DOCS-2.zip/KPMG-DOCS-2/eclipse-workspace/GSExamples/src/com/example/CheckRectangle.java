package com.example;

import java.util.List;

public class CheckRectangle {

	public static class Point {
		final int x;
		final int y;

		Point(int aX, int aY) {
			x = aX;
			y = aY;
		}

		@Override
		public String toString() {
			return "(" + x + ", " + y + ")";
		}
	}

	private static class RectangularIndexer {
		private final int lowerLineOffs;
		private final int upperLineOffs;
		private final int leftLineOffs;
		private final int rightLineOffs;

		private final int xmin;
		private final int xmax;
		private final int ymin;
		private final int ymax;

		public RectangularIndexer(int axmin, int axmax, int aymin, int aymax) {
			xmin = axmin;
			xmax = axmax;
			ymin = aymin;
			ymax = aymax;
			lowerLineOffs = 0;
			upperLineOffs = lowerLineOffs + (xmax - xmin + 1);
			leftLineOffs = upperLineOffs + (xmax - xmin + 1);
			rightLineOffs = leftLineOffs + (ymax - ymin - 1);
		}

		public int index(Point aP) {
			if (aP.y == ymin) {
				return aP.x - xmin;
			} else if (aP.y == ymax) {
				return upperLineOffs + aP.x - xmin;
			} else {
				if (aP.x == xmin) {
					return leftLineOffs + aP.y - ymin - 1;
				} else if (aP.x == xmax) {
					return rightLineOffs + aP.y - ymin - 1;
				} else {
					return -1;
				}
			}
		}
	}

	static boolean isRectangle(List<Point> aPoints) {
		if (aPoints.size() == 1)
			return true;

		// Phase 1
		int xmax = Integer.MIN_VALUE;
		int xmin = Integer.MAX_VALUE;
		int ymax = Integer.MIN_VALUE;
		int ymin = Integer.MAX_VALUE;

		for (Point p : aPoints) {
			xmax = Math.max(xmax, p.x);
			xmin = Math.min(xmin, p.x);
			ymax = Math.max(ymax, p.y);
			ymin = Math.min(ymin, p.y);
		}

		// Phase 2
		RectangularIndexer indexer = new RectangularIndexer(xmin, xmax, ymin, ymax);
		boolean[] score = new boolean[2 * (xmax - xmin + ymax - ymin)];

		for (Point p : aPoints) {
			int idx = indexer.index(p);
			if (idx < 0)
				return false;
			score[idx] = true;
		}

		// Phase 3
		for (boolean s : score) {
			if (s == false)
				return false;
		}
		return true;
	}
}