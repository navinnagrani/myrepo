package com.example;

import java.util.*;

class EmployeeModel {

	private Integer id;
	private String name;

	public EmployeeModel(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return this.name + ":" + id;
	}
}

class MyNameComp implements Comparator<EmployeeModel> {

	public int compare(EmployeeModel o1, EmployeeModel o2) {
		return o1.getName().compareTo(o2.getName());
	}

}

public class TreeMapCustomObject {
	
	public static void main(String[] args) {
		TreeMap<EmployeeModel, String> treeMap = new TreeMap<EmployeeModel, String>(new MyNameComp());

		treeMap.put(new EmployeeModel(10, "Anil"), "one");
		treeMap.put(new EmployeeModel(10, "Mahesh"), "two");
		treeMap.put(new EmployeeModel(10, "John"), "three");
		treeMap.put(new EmployeeModel(10, "Nagesh"), "four");
		for (Map.Entry<EmployeeModel, String> map : treeMap.entrySet()) {
			System.out.println("Key : (" + map.getKey() + "), Value : " + map.getValue());
		}
	}
}
