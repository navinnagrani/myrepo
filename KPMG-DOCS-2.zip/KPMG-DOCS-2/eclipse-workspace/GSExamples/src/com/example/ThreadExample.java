package com.example;

class SystemThread {
	synchronized void m1() throws InterruptedException {
		System.out.println("M1 mtd");
		Thread.sleep(1000);
	}

	synchronized void m2() throws InterruptedException {
		System.out.println("M2 mtd");
		Thread.sleep(1000);
	}

}

public class ThreadExample {

	public static void main(String args[]) throws InterruptedException {
		final SystemThread t = new SystemThread();
		Thread t1 = new Thread() {
			public void run() {
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Thread t2 = new Thread() {
			public void run() {
				try {
					t.m2();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		t1.start();
		Thread.sleep(500);
		t2.start();
		Thread.sleep(500);
		System.out.println(t2.getState());
	}
}
