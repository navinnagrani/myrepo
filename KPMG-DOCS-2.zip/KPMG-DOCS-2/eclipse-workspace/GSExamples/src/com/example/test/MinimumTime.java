package com.example.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MinimumTime {

	public static void main(String[] args) {
		List<Integer> ability = new ArrayList<Integer>();
		int processes = 15;
		ability.add(3);
		ability.add(1);
		ability.add(7);
		ability.add(2);
		ability.add(4);
		System.out.println(minimumTime(ability,processes));

	}

	private static int minimumTime(List<Integer> ability, int processes) {
		int t = 0;
		while(processes > 0) {
			int maxAbi = Collections.max(ability);
			//ability.remove(new Integer(maxAbi));
			int reduction = maxAbi/2;
			//ability.add(reduction);
			processes = processes - reduction;
			t++;
		}
		return t;
	}

}
