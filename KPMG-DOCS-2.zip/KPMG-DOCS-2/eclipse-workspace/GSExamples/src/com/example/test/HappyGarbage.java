package com.example.test;


public class HappyGarbage {

	public static void main(String[] args) {
		HappyGarbage hp1 = new HappyGarbage();
		HappyGarbage hp2 = m1(hp1);
		HappyGarbage h4 = new HappyGarbage();
		hp2 = h4;
		//doComplexStuff();
		
	}
	static HappyGarbage m1(HappyGarbage mx) {
		mx = new HappyGarbage();
		return mx;
	}
	
}
