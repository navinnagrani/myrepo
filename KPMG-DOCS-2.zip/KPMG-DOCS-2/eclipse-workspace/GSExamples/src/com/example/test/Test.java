package com.example.test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;



public class Test {
	private String s;
	public Test(String s) {
		this.s = s;
	}
	public static void main(String[] args) {
		HashSet<Object> hs = new HashSet<Object>();
		Test w1 = new Test("aardvark");
		Test w2 = new Test("aardvark");
		String s1 = new String("aardvark");
		String s2 = new String("aardvark");
		hs.add(w1);
		hs.add(w2);
		hs.add(s1);
		hs.add(s2);
		System.out.println(hs.size());
	}

}
