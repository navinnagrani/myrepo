package com.example.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.Example1;

class Example1Test {

	@Test
	void test() {
		
	}

}
