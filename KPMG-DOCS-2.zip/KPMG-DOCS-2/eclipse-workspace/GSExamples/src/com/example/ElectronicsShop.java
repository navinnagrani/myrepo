package com.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ElectronicsShop {
	
	static int getMoneySpent(int[] keyboards, int[] drives, int b) {
		Arrays.sort(keyboards);//Descending order
        Arrays.sort(drives);
        int max = -1;
        for(int i = 0, j = 0; i < keyboards.length; i++){
            for(; j < drives.length; j++){
                if(keyboards[i]+drives[j] > b) break; //This prevents j from incrementing
                if(keyboards[i]+drives[j] > max)
                    max = keyboards[i]+drives[j];
            }
        }
        return max;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
