package com.example;

import java.util.Arrays;

public class StringManipulation {
	
	public int alternatingCharacters(String s) {
		int count = 0;
		for(int i = 0; i < s.length() - 1; i++){
            if(s.charAt(i) == s.charAt(i+1)){
                ++count;
            }
        }
		
		return count;
	}
	
	public static String isValid(String s) {
		final String GOOD = "YES";
	    final String BAD = "NO";

	    if(s.isEmpty()) return BAD;
	    if(s.length() <= 3) return GOOD;

	    int[] letters = new int[26];
	    for(int i = 0; i < s.length(); i++){
	        letters[s.charAt(i) - 'a']++;
	    }
	    Arrays.sort(letters);
	    int i=0;
	    while(letters[i]==0){
	        i++;
	    }
	    int min = letters[i];   //the smallest frequency of some letter
	    int max = letters[25]; // the largest frequency of some letter
	    String ret = BAD;
	    if(min == max) ret = GOOD;
	    else{
	        // remove one letter at higher frequency or the lower frequency 
	        if(((max - min == 1) && (max > letters[24])) ||
	            (min == 1) && (letters[i+1] == max))
	            ret = GOOD;
	    }
	    return ret;

	}
	
	public long substrCount(int n, String s) {
		long counter = n;
		
	    // to count consecutive characters that are the same
	    int consec = 1;
					
	    // the middle index of a 3-character symmetry,
	    // assigned only once detected
	    int midIndex = -1;
					
	    // compare with previous character so start with i=1
	    for (int i = 1; i < n; i++) {
	        if (s.charAt(i) == s.charAt(i-1)) {
	            // Condition 1: All of the characters are the same
	            // For n consecutive characters that are the same,
	            // we have this formula:
	            // Number of palindromic strings =
	            //     (n-1) + (n-2) + ... + (n-(n-1))
	            counter += consec;
	            consec++;
	                
	            // Condition 2: All characters except the middle one
	            // are the same
	            if (midIndex > 0) {
	                // check for symmetry on both sides
	                // of the midIndex
	                if ((midIndex-consec) > 0 && s.charAt(midIndex-consec) == s.charAt(i)) {
	                    counter++;
	                } else {
	                    // no more possibility of palindromic string
	                    // with this midIndex
	                    midIndex = -1; 
	                }
	            }
	        } else {
	            // reset consecutive chars counter to 1
	            consec = 1;
	                
	            // check for a 3-character symmetry
	            if (((i-2) >= 0) && s.charAt(i-2) == s.charAt(i)) {
	                counter++; // 3-char symmetry is detected
	                    
	                // to check if the next characters are the same
	                // and symmetrical along the midIndex
	                midIndex = i-1;
	            } else {
	                midIndex = -1;
	            }
	        }
	    }
	    return counter;

    }
	
	public int commonChild(String s1, String s2) {
		int[][] C = new int[s1.length()+1][s2.length()+1];

        for (int i = 0; i < s1.length(); i++) {
            for (int j = 0; j < s2.length(); j++) {
                if (s1.charAt(i) == s2.charAt(j)) {
                    C[i+1][j+1] = C[i][j] + 1;
                } else {
                    C[i+1][j+1] = Math.max(C[i+1][j], C[i][j+1]);
                }
            }
        }
        for (int i = 0; i < s1.length(); i++) {
        }

        return C[s1.length()][s2.length()];

	}
	
	public static void main(String[] args) {
		StringManipulation s = new StringManipulation();
		System.out.println(s.alternatingCharacters("AAAA"));
		
		System.out.println(s.isValid("abcc"));
		
		System.out.println(s.substrCount(5, "asasd"));
		
		System.out.println(s.commonChild("HARRY", "SALLY"));

	}

}
