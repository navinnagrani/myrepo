package com.example;

public class Employee {
	private int id;
	private String name;
	

}
