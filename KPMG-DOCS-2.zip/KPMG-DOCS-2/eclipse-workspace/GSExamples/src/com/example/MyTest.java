package com.example;


//Accessing the methods using the same object :
//
//What happens when a thread invokes a synchronized method?
//In that situation the thread automatically acquires the intrinsic lock for that method's object. 
//Since there is only one lock per object, if one thread has picked up the lock, no other 
//thread can pick up the lock until the first thread releases (or returns) the lock..
//And therefore this prevents multiple threads from calling synchronized methods on the 
//same instance simultaneoutly (note that this also prevents different synchronized methods 
//from getting called on the same instance simultaneously).
//The output of the above code snippet is
//Blocked
//
//Note: The state of a thread is Blocked when the thread  is blocked waiting for a monitor lock.

public class MyTest {
    public synchronized void testMethod1() {
        try {
              Thread.sleep(2000);
        }
        catch (InterruptedException ie) {
        }
    }
    public synchronized void testMethod2() {
        try {
                Thread.sleep(2000);
       }
        catch (InterruptedException ie) {}
    }
    public static void main (String[] args) throws InterruptedException {
        final MyTest t = new MyTest();
        Thread t1 = new Thread() { public void run() { t.testMethod1(); } };
        Thread t2 = new Thread() { public void run() { t.testMethod2(); } };
        t1.start();
        Thread.sleep(500);
        t2.start();
        Thread.sleep(500);
        System.out.println(t2.getState());
    }
}



//Accessing the methods using different objects :
//Now, since we have two instances of our class, each instance gets its own lock. 
//There's nothing to prevent the two threads each operating on its own instance concurrently.
//The output of the code is :
//TIMED_WAITING
//
//Note: The state of thread is  TIMED_WAITING when the thread that is waiting 
//for another thread to perform an action for up to a specified waiting time.

/*public class MyTest {
    public synchronized void testMethod1() {
        try {
             Thread.sleep(2000);
       }
        catch (InterruptedException ie) {}
    }
    public synchronized void testMethod2() {
        try {
               Thread.sleep(2000);
        }
        catch (InterruptedException ie) {}
    }
    public static void main(String[] args) throws InterruptedException {
        final MyTest test1 = new MyTest();
        final MyTest test2 = new MyTest();
        Thread t1 = new Thread() { public void run() { test1.testMethod1(); } };
        Thread t2 = new Thread() { public void run() { test2.testMethod2(); } };
        t1.start();
        Thread.sleep(500);
        t2.start();
        Thread.sleep(500);
        System.out.println(t2.getState());
    }
}*/
