package com.example;

class MyThread extends Thread {

	synchronized int sum(int a, int b) {
		return a + b;
	}

	public void run() {
		try {
			Thread.sleep(2000);
			System.out.println("Printing sum " + sum(20, 30));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

public class ThreadMultiThreading {

	public static void main(String[] args) {
		MyThread mt1 = new MyThread();
		MyThread mt2 = new MyThread();
		MyThread mt3 = new MyThread();
		MyThread mt4 = new MyThread();

		mt1.start();
		mt2.start();
		mt3.start();
		mt4.start();
	}

}
