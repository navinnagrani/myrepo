package com.example;

public class Department implements Cloneable {
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
