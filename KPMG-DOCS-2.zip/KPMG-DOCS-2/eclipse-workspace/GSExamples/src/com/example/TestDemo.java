package com.example;
import java.util.*;


class Parent {
	private void m1() {
		System.out.println("Parent");
	}
	void m2() {
		m1();
	}
}
class Child extends Parent {
	void m1() {
		System.out.println("Child");
	}
}

class ThreadChek {
	synchronized void m1() {
		System.out.println("M1 Method");
	}
	synchronized void m2() {
		System.out.println("M2 method");
	}
}
public class TestDemo {

	public static void main(String[] args) {
		ThreadChek th1 = new ThreadChek();
		ThreadChek th2 = new ThreadChek();
		
		th1.m1();
		th2.m1();
		
		
	}

}
