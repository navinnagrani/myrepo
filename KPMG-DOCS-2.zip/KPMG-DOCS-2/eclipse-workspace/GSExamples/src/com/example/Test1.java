package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Test1 {

	public static void main(String[] args) {
		HashMap<Employee, Integer> map =  new HashMap<Employee, Integer>();
		List<Employee> arr = new ArrayList<Employee>();
		List<Integer> dd = new ArrayList<Integer>();
		int k;
		
	}

}
