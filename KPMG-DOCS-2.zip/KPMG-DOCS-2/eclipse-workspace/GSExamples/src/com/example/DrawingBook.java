package com.example;

public class DrawingBook {
	
	public static int pageCount(int n,int p) {
//		int minPageFlip = 0;
//		int arr[] = new int[n];
//		for(int i=1;i<arr.length-1;i++) {
//			arr[i] = i;
//			if(arr[i] == p) {
//				minPageFlip++;
//			}
//		}
		int frontdist = p / 2;
        int backdist = n % 2 == 0 ? (n - p + 1) / 2 : (n - p) / 2;
        System.out.println("Correct one "+Math.min(frontdist, backdist));
		return Math.min(frontdist, backdist);
	}
	public static void main(String[] args) {
		System.out.println(pageCount(6, 5));
	}

}
