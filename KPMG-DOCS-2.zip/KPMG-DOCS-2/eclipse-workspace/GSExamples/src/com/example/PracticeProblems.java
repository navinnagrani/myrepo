package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PracticeProblems {

	public static List<Integer> compareTriplets(List<Integer> a, List<Integer> b) {
		List<Integer> score = new ArrayList<Integer>();
		int aliceScoreCount = 0;
		int bobScoreCount = 0;
		for(int i=0;i<a.size();i++) {
			if(a.get(i) > b.get(i)) {
				aliceScoreCount++;
			} else if(b.get(i) > a.get(i)) {
				bobScoreCount++;
			}
		}
		score.add(aliceScoreCount);
		score.add(bobScoreCount);
		return score;

	}
	
	public static long aVeryBigSum(List<Long> ar) {
		long sum = 0;
		for(int i =0;i<ar.size();i++) {
			sum = sum + ar.get(i);
		}
		return sum;

	}
	
	public static int diagonalDifference(List<List<Integer>> arr) {
		int leftdiagonal = 0, rightdiagonal = 0;
		for (int i = 0, j = arr.get(0).size() - 1; i < arr.get(0).size(); i++, j--) {
			leftdiagonal = leftdiagonal + arr.get(i).get(i);
			rightdiagonal = rightdiagonal + arr.get(i).get(j);
		}
		return Math.abs(leftdiagonal - rightdiagonal);

	}
	
	public static void miniMaxSum(List<Integer> arr) {
		Collections.sort(arr);
		long min = 0, max = 0;
		for (int i = 0, j = arr.size() - 1; i < arr.size() - 1; i++, j--) {
			max = max + arr.get(j);
			min = min + arr.get(i);
		}
		System.out.println(min + " " + max);

	}
	
	public static int birthdayCakeCandles(List<Integer> candles) {
		int count = 0;
		int fi = candles.get(0);
		for(int i=1;i<candles.size();i++) {
			if(candles.get(i) > fi) {
				fi = candles.get(i);
			}
		}
		for(int i = 0; i < candles.size(); i++)
	        if (candles.get(i)== fi)
	            count++;
		return count;

	}
	
	public static List<Integer> gradingStudents(List<Integer> grades) {
		List<Integer> ans = new ArrayList<Integer>();
		for(int marks:grades){
	        if(marks < 38 || marks % 5 <= 2){
	            ans.add(marks);
	        }else if(marks % 5 > 2){
	            int add = 5 -(marks % 5);
	            ans.add(marks + add);
	        }
	    }
		return ans;
	}
	static int roundUp(int n) {
	    return (n + 4) / 5 * 5;
	}
	
	public static String kangaroo(int x1, int v1, int x2, int v2) {
		String response = "NO";
		boolean canCatchUp = (v2 <= v1);
		if (canCatchUp) {
			boolean willIntersectOnLand = (x1 - x2) % (v2 - v1) == 0;
			if (willIntersectOnLand) {
				response = "YES";
			}
		}
		return response;

	}

	public static List<Integer> getRecord(List<Integer> s) {
		List<Integer> result = new ArrayList<Integer>();
		int countMax = 0, countMin = 0, max = s.get(0), min = s.get(0);
		for (int i = 1; i < s.size(); i++) {
			if (s.get(i) > max) {
				max = s.get(i);
				countMax++;
			}
			if (s.get(i) < min) {
				min = s.get(i);
				countMin++;
			}
		}
		result.add(0,countMax);
		result.add(1,countMin);
		return result;
	}
	
	public static int birthday(List<Integer> s, int d, int m) {
		int sum = 0, ways = 0;
		for (int i = 0; i < m; i++) {
			sum += s.get(i);
		}
		for (int i = 0; i < s.size() - m + 1; i++) {
			if (sum == d) {
				ways++;
			}
			if (i + m < s.size()) {
				sum = sum - s.get(i) + s.get(i + m);
			}
		}
		return ways;
	}
	
	public static int divisibleSumPairs(int n, int k, List<Integer> ar) {
		int count=0;
        //checking aginst the condition
        for(int i=0;i<(n-1);i++){
            for(int j=0;j<n;j++){
                if(i<j){
                    if((ar.get(i)+ar.get(j))%k==0)
                        count++;
                }
            }
        }
        return count;
	}
	
	public static int migratoryBirds(List<Integer> arr) {
		Map<Integer, Integer> birds = new HashMap<>();
		int key = 0;

		for (int i = 0; i < arr.size(); i++) {
			if (birds.containsKey(arr.get(i))) {
				birds.put(arr.get(i), birds.get(arr.get(i)) + 1);
			} else {
				birds.put(arr.get(i), 1);
			}
		}
		key = Collections.max(birds.entrySet(), Map.Entry.comparingByValue()).getKey();
		return key;

	}
	
	public static void main(String[] args) {
		
		PracticeProblems p = new PracticeProblems();
		List<Integer> a = new ArrayList<Integer>();
		a.add(5);
		a.add(6);
		a.add(7);
		List<Integer> b = new ArrayList<Integer>();
		b.add(3);
		b.add(6);
		b.add(10);
		System.out.println(compareTriplets(a, b));
		
		List<Long> l  = new ArrayList<Long>();
		l.add((long) 1000000001);
		l.add((long) 1000000002);
		l.add((long) 1000000003);
		l.add((long) 1000000004);
		l.add((long) 1000000005);
		
		System.out.println(aVeryBigSum(l));
		
		List<List<Integer>> arr = new ArrayList<List<Integer>>();
		List<Integer> in1 = new ArrayList<Integer>();
		List<Integer> in2 = new ArrayList<Integer>();
		List<Integer> in3 = new ArrayList<Integer>();
		in1.add(11);
		in1.add(2);
		in1.add(4);
		in2.add(4);
		in2.add(5);
		in2.add(6);
		in3.add(10);
		in3.add(8);
		in3.add(-12);
		arr.add(in1);
		arr.add(in2);
		arr.add(in3);
		System.out.println(diagonalDifference(arr));
		
		List<Integer> k = new ArrayList<Integer>();
		k.add(1);k.add(3);k.add(5);k.add(7);k.add(9);
		miniMaxSum(k);
		
		List<Integer> k1 = new ArrayList<Integer>();
		k1.add(3);k1.add(2);k1.add(1);k1.add(3);
		System.out.println(birthdayCakeCandles(k1));
		
		List<Integer> k2 = new ArrayList<Integer>();
		k2.add(73);k2.add(67);k2.add(38);k2.add(33);
		System.out.println(gradingStudents(k2));
		
		System.out.println(kangaroo(2, 1, 1, 2));
		
		List<Integer> s = new ArrayList<Integer>();
		s.add(1);		s.add(2);		s.add(1);		s.add(3);		s.add(2);
		System.out.println(birthday(s, 3, 2));
		
		List<Integer> ar = new ArrayList<Integer>();
		ar.add(1);ar.add(2);ar.add(3);ar.add(4);ar.add(5);ar.add(6);
		System.out.println(divisibleSumPairs(ar.size(), 5, ar));
		
		List<Integer> birds = new ArrayList<Integer>();
		birds.add(1);birds.add(4);birds.add(4);birds.add(4);birds.add(5);birds.add(3);
		System.out.println(migratoryBirds(birds));
		
	}

}
