package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Pattern;

class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;

	TreeNode(int x) {
		val = x;
	}

	@Override
	public String toString() {
		return "TreeNode [val=" + val + ", left=" + left + ", right=" + right + "]";
	}
	
}

class ListNode {
	int val;
	ListNode next;

	ListNode() {
	}

	ListNode(int val) {
		this.val = val;
	}

	ListNode(int val, ListNode next) {
		this.val = val;
		this.next = next;
	}
}

public class TwoSum {
	public static int[] twoSum1(int[] nums, int target) {
		Map<Integer, Integer> map = new HashMap<>();
	    for (int i = 0; i < nums.length; i++) {
	        map.put(nums[i], i);
	    }
	    for (int i = 0; i < nums.length; i++) {
	        int complement = target - nums[i];
	        if (map.containsKey(complement) && map.get(complement) != i) {
	            return new int[] { i, map.get(complement) };
	        }
	    }
	    throw new IllegalArgumentException("No two sum solution");
	}
	
	public static int fib(int n) {

		if (n == 0)
			return 0;
		if (n == 1)
			return 1;

		int result = 0;
		int fib_n_2 = 0;
		int fib_n_1 = 1;

		for (int i = 2; i <= n; i++) {
			result = ((fib_n_2) + (fib_n_1));
			fib_n_2 = fib_n_1;
			fib_n_1 = result;
		}
		return result;
		
		//Recurrsion
//		if (n <= 1) 
//            return n; 
//        return fib(n - 1) + fib(n - 2);
	}
	
	public static int productSum(int arr[]) {
		int product = 0;
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				product += arr[i] * arr[j];
			}
		}
		return product;
	}
	
	public static void print3Largest(int arr[]) {
		int first , second , third;
		
		if(arr.length < 3) {
			System.out.println("Less than 3 elements");
			return;
		}
		
		third = first = second = Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++) {
			if (arr[i] > first) {
				third = second;
				second = first;
				first = arr[i];
			}
			else if (arr[i] > second) {
				third = second;
				second = arr[i];
			}
			else if (arr[i] > third) {
				third = arr[i];
			}
		}
		System.out.println("Three largest elements are " + first + " " + second + " " + third);
	}
	
	public static void bubbleSort(int arr[]) {
		int temp;
		
		for(int i=0;i<arr.length-1;i++) {
			for(int j=0;j<arr.length-i-1;j++) {
				if(arr[j] > arr[j+1]) {
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		for (int i = 0; i < arr.length; ++i)
			System.out.print(arr[i] + " ");
		System.out.println(); 
	}
	
	public static List<List<Integer>> threeSum(int a[]) {
		if (a.length < 3)
			return new ArrayList<>(); // if nums less than 3 element
		Arrays.sort(a); // sort array
		Set<List<Integer>> set = new HashSet<>();
		for (int i = 0; i < a.length - 2; i++) {
			int j = i + 1;
			int k = a.length - 1;
			while (j < k) {
				int sum = a[i] + a[j] + a[k];
				if (sum == 0)
					set.add(Arrays.asList(a[i], a[j++], a[k--]));
				else if (sum > 0)
					k--;
				else if (sum < 0)
					j++;
			}

		}

		return new ArrayList<>(set);
	}
	
	public static List<List<Integer>> smallestDifference(int a[]) {
		if (a.length < 0)
			return new ArrayList<List<Integer>>();

		Arrays.sort(a);
		int min = Integer.MAX_VALUE;
		List<List<Integer>> result = new ArrayList<List<Integer>>();
		for (int i = 0; i < a.length-1; i++) {
			if (Math.abs(a[i] - a[i + 1]) < min) {
				min = Math.abs(a[i] - a[i + 1]);
				result.clear();
				List<Integer> temp = new ArrayList();
				temp.add(a[i]);
				temp.add(a[i + 1]);
				result.add(temp);
			} else if (Math.abs(a[i] - a[i + 1]) == min) {
				List<Integer> temp = new ArrayList();
				temp.add(a[i]);
				temp.add(a[i + 1]);
				result.add(temp);
			}
		}
		return result;

	}
	
	public static void moveArrayElement(int a[]) {
		if (a.length < 0)
			return;
	
		int var = 0;
		for(int i=0;i<a.length;i++) {
			if(a[i] != 0) {
				int temp = a[var];
				a[var] = a[i];
				a[i] = temp;
				var++;
			}
		}
		for(int arr : a) {
			System.out.println("Result is : "+arr);
		}
		
	}
	
	
	public static boolean isMonotonic(int[] a) {
		boolean inc = false , dec = false;
		for(int i=0;i<a.length-1;i++) {
				if(i <= i+1 && a[i] <= a[i+1]) {
					inc=  true;
				} else if(i <= i+1 && a[i] >= a[i+1]) {
					dec =  true;
				}
		}
		if(inc || dec) {
			return true;
		}
		return false;
		
//		Boolean inc = false, dec = false;
//		int size = A.length;
//		for (int i = 1; i < size; i++) {
//			if (!inc && !dec) {
//				if (A[i] > A[i - 1]) {
//					inc = true;
//				} else if (A[i] < A[i - 1]) {
//					dec = true;
//				}
//			} else if ((inc && A[i] < A[i - 1]) || (dec && A[i] > A[i - 1])) {
//				return false;
//			}
//		}
//		return true;
	}
	
	public static List<Integer> spiralOrder(int[][] matrix) {
		List<Integer> list = new ArrayList<Integer>();
		
		int rowLength = matrix.length;
		int colLength = matrix[0].length;
		
		int top = 0;
        int right = matrix[0].length-1;
        int left = 0;
        int bottom = matrix.length-1;
        
		while (left <= right || top <= bottom) {

			for (int col = left; col <= right && list.size() < rowLength * colLength; col++) {
				list.add(matrix[top][col]);
			}

			for (int row = top + 1; row < bottom && list.size() < rowLength * colLength; row++) {
				list.add(matrix[row][right]);
			}

			for (int col = right; col >= left && list.size() < rowLength * colLength; col--) {
				list.add(matrix[bottom][col]);
			}

			for (int row = bottom - 1; row > top && list.size() < rowLength * colLength; row--) {
				list.add(matrix[row][left]);
			}

			top++;
			bottom--;
			right--;
			left++;
		}
		
		
		return list;
	}
	
	public static int longestMountain(int[] A) {
		int N = A.length;
		int ans = 0, base = 0;
		while (base < N) {
			int end = base;
			// if base is a left-boundary
			if (end + 1 < N && A[end] < A[end + 1]) {
				// set end to the peak of this potential mountain
				while (end + 1 < N && A[end] < A[end + 1])
					end++;

				// if end is really a peak..
				if (end + 1 < N && A[end] > A[end + 1]) {
					// set end to the right-boundary of mountain
					while (end + 1 < N && A[end] > A[end + 1])
						end++;
					// record candidate answer
					ans = Math.max(ans, end - base + 1);
				}
			}

			base = Math.max(end, base + 1);
		}

		return ans;
	}
	
	public static int[] productExceptSelf(int[] nums) {
		
		int len = nums.length;
		
		int left[] = new int[len]; 
		int right[] = new int[len];
		
		int[] answer = new int[len];
		
		left[0] = 1;
		
		for(int i=1;i<len;i++) {
			left[i] = nums[i-1] * left[i-1];
		}
		
		right[len - 1] = 1;
		for(int i=len-2;i>=0;i--) {
			right[i] = nums[i + 1] * right[i + 1];
		}
		
		for(int i=0;i<len;i++) {
			answer[i] = left[i] * right[i];
		}
		
		return answer;
	}
	
	public static int findDuplicate(int[] nums) {
		Set<Integer> seen = new HashSet<Integer>();
        for (int num : nums) {
            if (seen.contains(num)) {
                return num;
            }
            seen.add(num);
        }
        return -1;
	}

	public static int changeCoins(int amount, int[] coins) {
		int[] a = new int[amount + 1];
		a[0] = 1;
		for (int coin : coins) {
			for (int i = coin; i <= amount; i++) {
				a[i] = a[i] + a[i - coin];
			}
		}
		return a[amount];
//		int dp[][] = new int[coins.length][amount+1];
//		for(int i=0;i<coins.length;i++) {
//			Arrays.fill(dp[i], -1);;
//		}
//		return coinChange(coins, amount, 0 , dp);
	}
	
	public static int coinChange(int[] coins,int amount,int i,int dp[][]) {
		if(amount == 0) return 1;
		if(amount < 0 || i== coins.length) return 0;
		if(dp[i][amount] != -1) return dp[i][amount];
		
		return dp[i][amount] = coinChange(coins, amount-coins[i], i ,dp) + coinChange(coins, amount, i + 1 ,dp);
	}
	
	public static int minCoinChange(int[] coins, int amount) {
		int max = amount + 1;
		int[] dp = new int[amount + 1];
		Arrays.fill(dp, max);
		dp[0] = 0;
		for (int i = 1; i <= amount; i++) {
			for (int j = 0; j < coins.length; j++) {
				if (coins[j] <= i) {
					dp[i] = Math.min(dp[i], dp[i - coins[j]] + 1);
				}
			}
		}
		return dp[amount] > amount ? -1 : dp[amount];
	}

	public static int minDistance(String word1, String word2) {
		int[][] dp= new int[word1.length()+1][word2.length()+1];
        for(int i=0;i<dp.length;i++){
            dp[i][0]=i;
        }
        for(int i=0;i<dp[0].length;i++){
            dp[0][i]=i;
        }
        for(int i=1;i<=word1.length();i++){
            for(int j=1;j<=word2.length();j++){
                if(word1.charAt(i-1)==word2.charAt(j-1)){
                    dp[i][j]=dp[i-1][j-1];
                }else{
                    dp[i][j]=1+Math.min(dp[i-1][j], Math.min(dp[i][j-1], dp[i-1][j-1]));
                }
            }
        }
        return dp[dp.length-1][dp[0].length-1];
	}
	
	public static int maxSubArray(int[] nums) {
//		int currIndexSum = nums[0];
//		int overallMaxSum = nums[0];
//		for(int i=1;i<nums.length;i++) {
//			currIndexSum = Math.max(nums[i],currIndexSum+nums[i]);
//		}
		
		int maxSub = nums[0], curSum = 0;

		for (int n : nums) {
			if (curSum < 0)
				curSum = 0;
			curSum += n;
			maxSub = Math.max(maxSub, curSum);
		}
		return maxSub;
	}
	
	public static boolean circularArrayLoop(int[] arr) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < arr.length; i++) {
			int h = arr[i];
			int si = i;
			if (!map.containsKey(si)) {// not previously visited
				HashMap<Integer, Integer> cmap = new HashMap<Integer, Integer>();
				boolean ans = true;
				int ci = si; // current index
				int previ = si;// prev index
				while (!map.containsKey(ci) && !cmap.containsKey(ci)) {
					if (h * arr[ci] <= 0)
						break;
					cmap.put(ci, 1);
					previ = ci;// mark previous index
					ci = ci + arr[ci];
					if (ci >= 0)
						ci = ci % arr.length;
					else {
						int steps = (ci * -1) - 1;
						ci = (arr.length - 1) - (steps % arr.length);
					}
				}
				if (cmap.containsKey(ci)) {
					if (previ != ci) // cycle found
						return (true);
				} else { // put all keys in the map
					for (Integer key : cmap.keySet()) {
						map.put(key, 1);
					}
				}
			}
		}
		return false;
	}
	
	public static TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
		// Value of p
		int pVal = p.val;

		// Value of q;
		int qVal = q.val;

		// Start from the root node of the tree
		TreeNode node = root;

		// Traverse the tree
		while (node != null) {

			// Value of ancestor/parent node.
			int parentVal = node.val;

			if (pVal > parentVal && qVal > parentVal) {
				// If both p and q are greater than parent
				node = node.right;
			} else if (pVal < parentVal && qVal < parentVal) {
				// If both p and q are lesser than parent
				node = node.left;
			} else {
				// We have found the split point, i.e. the LCA node.
				return node;
			}
		}
		return null;
	}
	
	public static ListNode removeNthFromEnd(ListNode head, int n) {
		ListNode dummy = new ListNode(0);
		dummy.next = head;
		int len = 0;
		ListNode first = head;
		while (first != null) {
			len++;
			first = first.next;
		}
		len = len - n;
		first = dummy;
		while (len > 0) {
			len--;
			first = first.next;
		}
		first.next = first.next.next;
		return dummy.next;
	}
	
	public static List<List<Integer>> permute(int[] nums) {
		LinkedList<List<Integer>> result = new LinkedList<List<Integer>>();
        int rSize;
        result.add(new ArrayList<Integer>());
        
        for (int num: nums) {
            rSize = result.size();
            
            while (rSize > 0) {
                List<Integer> permutation = result.pollFirst();
                for (int i = 0; i <= permutation.size(); i++) {
                    List<Integer> newPermutation = new ArrayList<Integer>(permutation);
                    newPermutation.add(i, num);
                    result.add(newPermutation);
                }
                rSize--;
            }
            System.out.println(result);
        }
        return result;
	}
	
	public static List<List<Integer>> subsets(int[] nums) {
		List<List<Integer>> output = new ArrayList();
		output.add(new ArrayList<Integer>());
		for (int num : nums) {
			List<List<Integer>> newSubsets = new ArrayList();
			for (List<Integer> curr : output) {
				newSubsets.add(new ArrayList<Integer>(curr) {
					{
						add(num);
					}
				});
			}
			for (List<Integer> curr : newSubsets) {
				output.add(curr);
			}
		}
		return output;
	}
	
	public static boolean searchMatrix(int[][] matrix, int target) {
		
		int rowLen = matrix.length;
		int colLen = matrix[0].length;
		boolean found = false;
		
		for(int i=0;i<rowLen;i++) {
			for(int j=0;j<colLen;j++) {
				if(matrix[i][j] ==  target) {
					found = true;
					return found;
				}
			}
		}
		
		return found;
	}
	
	public static boolean isBalanced(String expression) {
		// Must be even
		if ((expression.length() & 1) == 1)
			return false;
		else {
			char[] brackets = expression.toCharArray();
			Stack<Character> s = new Stack<>();
			for (char bracket : brackets)
				switch (bracket) {
				case '{':
					s.push('}');
					break;
				case '(':
					s.push(')');
					break;
				case '[':
					s.push(']');
					break;
				default:
					if (s.empty() || bracket != s.peek())
						return false;
					s.pop();
				}
			return s.empty();
		}
	}
		
	public static int sunsetViews(int arr[]) {
		int count = 1;
		int curr_max = arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i] > curr_max) {
				count++;
				curr_max = arr[i];
			}
			System.out.println("Building number which can see sunview "+curr_max);
		}
		
		return count;
	}
	
	static int maxLenLPS = 0;
    static int startingPoint =0;
	public static String longestPalindrome(String s) {
		if(s.length()<=1){
            return s;
        }

        for(int i=0;i<s.length();i++){
            checkForLongestPalindromicString(s, i, i); // odd length palindromic substring
            checkForLongestPalindromicString(s, i, i+1); // even length palindromic substring
        }

        return s.substring(startingPoint, maxLenLPS+startingPoint);
	}
	
	private static void checkForLongestPalindromicString(String s, int left, int right){
        while(left>=0&& right<s.length() && s.charAt(left) == s.charAt(right)){
            left--;
            right++;
        }

        if(maxLenLPS< right-left -1){
            maxLenLPS = right -left-1;
            startingPoint = left+1;
        }
    }
	
	public static List<List<String>> groupAnagrams(String[] strs) {
		
		if (strs.length == 0) 
			return new ArrayList<List<String>>();
		
		Map<String,List<String>> map = new HashMap<String, List<String>>();
		Map<String, List<String>> ans = new HashMap<String, List<String>>();
        for (String s : strs) {
            char[] ca = s.toCharArray();
            Arrays.sort(ca);
            String key = String.valueOf(ca);
            if (!ans.containsKey(key)) ans.put(key, new ArrayList<String>());
            ans.get(key).add(s);
        }
        return new ArrayList<List<String>>(ans.values());
		
	}
	
	static String chunkIPv4 = "([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])";
	static Pattern pattenIPv4 = Pattern.compile("^(" + chunkIPv4 + "\\.){3}" + chunkIPv4 + "$");

	static String chunkIPv6 = "([0-9a-fA-F]{1,4})";
	static Pattern pattenIPv6 = Pattern.compile("^(" + chunkIPv6 + "\\:){7}" + chunkIPv6 + "$");
	
	public static String validIPAddress(String IP) {
		if (pattenIPv4.matcher(IP).matches()) return "IPv4";
	    return (pattenIPv6.matcher(IP).matches()) ? "IPv6" : "Neither";
	}
	
	public static String longestDupSubstring(String s) {
		return null;
	}
	
	public static void main(String[] args) {
		
		int arr[] = {2,7,11,15};
		int target = 22;
		int[] result = twoSum1(arr, target);
		System.out.println("-----Two Sum ------");
		for(int i =0 ; i< result.length;i++) {
			System.out.println("Result  " +result[i]);
		}
		
		System.out.println("-----Nth Fibonacci-----");
		System.out.println("Result "+fib(9));
		
		int[] arrProductSum= {1,3,4};
		System.out.println("-----Product Sum-----");
		System.out.println("Result "+productSum(arrProductSum));
		
		int[] arrLargestNumbers = {10, 4, 3, 50, 23, 90};
		System.out.println("-----Find Three Largest Numbers-----");
		print3Largest(arrLargestNumbers);
		
		
		System.out.println("-----Bubble Sort------");
		int arrBubbleSort[] = {64, 34, 25, 12, 22, 11, 90}; 
        bubbleSort(arrBubbleSort);
        
        System.out.println("-----Three number sum------");
        int a[] = {2,4,0,-1,1,-1};
        System.out.println("Result is "+threeSum(a));
        
        System.out.println("-----Smallest Difference-----");
        int arrSmallestDiff[] = {4,2,1,3};
        System.out.println("Result is "+smallestDifference(arrSmallestDiff));
        
        System.out.println("-----Move element to end-----");
        int arrMoveEle[] = {0,1,0,3,12};
        moveArrayElement(arrMoveEle);
        
        System.out.println("-----Monotonic Array------");
        int arrMonoArray[] = {1,2,2,3};
        System.out.println(isMonotonic(arrMonoArray));
        
        System.out.println("-----Spiral Traverse------");
        int arrSpiralMat[][] = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};
        System.out.println("Result is : "+spiralOrder(arrSpiralMat));
        
        System.out.println("-----Longest Peak-----");
        int arrLongPeak[] = {2,1,4,7,3,2,5};
        System.out.println("Result is : "+longestMountain(arrLongPeak));
        
        System.out.println("-----Array of Products------");
        int arrProducts[] = {1,2,3,4};
        System.out.println("Result is : ");
        int arrPrd[] = productExceptSelf(arrProducts);
        for(int i : arrPrd) {
        	System.out.print(i+" \n");
        }
        
        System.out.println("-----First duplicate number------");
        int arrFirstDup[] = {1,3,4,2,2};
        System.out.println("Result is : "+findDuplicate(arrFirstDup));
        
        System.out.println("-----Number of ways to make change------");
        int amount = 5;
        int coins[] = {1,2,5};
        System.out.println("Result is : "+changeCoins(amount,coins));
        
        System.out.println("-----Min number of coins for change------");
        int amt = 11;
        int arrMinAm[] = {1,2,5};
        System.out.println("Result is : "+minCoinChange(arrMinAm,amt));
        
        System.out.println("-----Levenshtein Distance-------");
        String word1 = "horse";
        String word2 = "ros";
        System.out.println("Result is : "+minDistance(word1,word2));
        
        System.out.println("------Kadane's Algorithm------");
        int arrKadane[] = {-2,1,-3,4,-1,2,1,-5,4};
        System.out.println("Result is : "+maxSubArray(arrKadane));
        
        System.out.println("------Single Cycle Check-------");
        int arrCirArray[] = {2,-1,1,2,2};
        System.out.println("Result is : "+circularArrayLoop(arrCirArray));
        
        System.out.println("-----Youngest Common Ancestor--------");
        TreeNode root = new TreeNode(6);
        root.left = new TreeNode(2);
        root.right = new TreeNode(8);
        root.left.left = new TreeNode(0);
        root.left.right = new TreeNode(4);
        root.right.left = new TreeNode(7);
        root.right.right = new TreeNode(9);
        root.left.left.left = null;
        root.left.left.right = null;
        root.left.right.left = new TreeNode(3);
        root.left.right.right = new TreeNode(5);
        TreeNode pNode = new TreeNode(2);
        TreeNode qNode = new TreeNode(8);
        System.out.println("Result is +"+lowestCommonAncestor(root, pNode, qNode).toString());
        
        System.out.println("-----Remove Kth Node from end------");
        System.out.println("Result understood");
        
        System.out.println("-------Permutations--------");
        int arrPermut[] = {1,2,3};
        System.out.println("Result is : "+permute(arrPermut));
        
        System.out.println("------Powerset------");
        int arrPower[] = {1,2,3};
        System.out.println("Result is : "+subsets(arrPower));
        
        System.out.println("-------Search in sorted matrix--------");
        int arrSortMAt[][] = {{1,3,5,7},{10,11,16,20},{23,30,34,60}};
        int tar = 13;
        System.out.println("Result is : "+searchMatrix(arrSortMAt,tar));
        
        System.out.println("------Balanced Bracket-------");
        String balanceExp = "{[()]}";
        System.out.println("Result is : "+isBalanced(balanceExp));
        
        System.out.println("------Sunset Views------");
        int arrSunset[] = {7, 4, 8, 2, 9};
        System.out.println("Result is : "+sunsetViews(arrSunset));
        
        System.out.println("------Longest Palindromic Substring-------");
        String s = "babad";
        System.out.println("Result is : "+longestPalindrome(s));
        
        System.out.println("------Group Anagrams-------");
        String strs[] = {"eat","tea","tan","ate","nat","bat"};
        System.out.println("Result is : "+groupAnagrams(strs));
        
        System.out.println("------Valid IP Addresses-------");
        String IpV4 = "256.256.256.256";
        System.out.println("Result is : "+validIPAddress(IpV4));
        
        System.out.println("------Suffix Trie Construction-------");
        String suffixTrie = "banana";
        System.out.println("Result is : "+longestDupSubstring(suffixTrie));

	}

}
