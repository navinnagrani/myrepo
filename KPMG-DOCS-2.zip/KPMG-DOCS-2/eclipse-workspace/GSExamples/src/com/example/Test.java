package com.example;
import java.util.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
class Base {
	
	void print() {
		System.out.println("A");
	}
}

class Derived extends Base {
	void print()  {
		System.out.println("B");
	}
}
class D2 extends Derived {
	void print()  {
		System.out.println("C");
	}
}

class Person {
	private String fname;
	private String lname;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Person(String fname, String lname) {
		super();
		this.fname = fname;
		this.lname = lname;
	}
	
	public int hashCode() {
		return 13;
		
	}
	@Override
	public String toString() {
		return "Person [fname=" + fname + ", lname=" + lname + "]";
	}
	
	
}

public class Test {
	public static void main(String[] args) {
		Person p1 = new Person("fname1", "lname1");
		Person p2 = new Person("fname2", "lname2");
		
		Map<Person, String> m = new HashMap<Person, String>();
		m.put(p1, "This is p1");
		m.put(p2, "This p2");
		m.put(new Person("fname1","lname1"),"Overrirding");
		
		System.out.println(m.size());
		System.out.println(m.get(new Person("fname1","lname1")));
		
		
		
		
	
	}
}
