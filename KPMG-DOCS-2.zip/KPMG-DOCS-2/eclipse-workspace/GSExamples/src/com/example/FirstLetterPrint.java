package com.example;

public class FirstLetterPrint {
	
	static String printFirst(String text) {
		
		String result = "";
		boolean space=true;
		
		for(int i=0;i<text.length();i++) {
			if(text.charAt(i) == ' ') {
				space = true;
			} else if(text.charAt(i) != ' ' && space==true) {
				result += text.charAt(i);
				space = false;
			}
		}
		return result;
		
	}
	
	public static void main(String[] args) {
		String text = "geeks for navin";
		System.out.println(printFirst(text));

	}

}
