package com.example;

import java.util.TreeSet;

class A {
	static void m1() {
		System.out.println("A");
	}
} 
class B extends A {
	static void m1() {
		System.out.println("B");
	}
}
public class TestExample {

	public static void main(String[] args) {
		TestExample t = new TestExample();
		
		A a = new B();
		a.m1();
		
		
		
		
		
		
	}

}
