package com.example;

public class OutOfMemoryExample {

	public static void main(String[] args) throws InterruptedException {
		OutOfMemoryExample obj = new OutOfMemoryExample();
		obj.generateOOM();
	}

	private void generateOOM() throws InterruptedException {
		int itVal = 20;
		for(int i=0;i<20;i++) {
			System.out.println("Iteration " + i + " Free Mem: " + Runtime.getRuntime().freeMemory());
			int loop1 = 2;
			int[] memoryFillIntVar = new int[itVal];
			do {
				memoryFillIntVar[loop1] = 0;
				loop1--;
			} while (loop1 > 0);
			itVal = itVal * 5;
			System.out.println("\nRequired Memory for next loop: " + itVal);
			Thread.sleep(1000);
		}
	}

}
