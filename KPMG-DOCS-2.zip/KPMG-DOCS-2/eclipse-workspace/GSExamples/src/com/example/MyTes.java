package com.example;

public class MyTes {

	public static void main(String[] args) {
		int x = 5 % 2 * 3 / 2;
		System.out.println(x);

	}

}
