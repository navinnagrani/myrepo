package com.example;

import java.util.HashMap;
import java.util.Map;

public class CountWords {
	
	private String name;
	
	public CountWords(String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj!=null) {
			CountWords e = (CountWords)obj;
			return this.name.equals(e.name);
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		return 1;
	}
	
	
	public static void main(String[] args) {
		Map<CountWords, Integer> map = new HashMap<CountWords, Integer>();
		String[] emps = {"Anurag","Abhay","Mohan","Madhu","Amar"};
		int empid = 1;
		for(int i=0;i<emps.length;i++) {
			map.put(new CountWords(emps[i]), empid++);
		}
		System.out.println(map.get(new CountWords("Abhay")));
		String a = "abc";
		//a.le
		
	}

}
