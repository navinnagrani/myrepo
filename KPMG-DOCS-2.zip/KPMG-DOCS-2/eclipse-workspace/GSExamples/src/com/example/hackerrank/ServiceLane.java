package com.example.hackerrank;

import java.util.ArrayList;
import java.util.List;

public class ServiceLane {
	public static List<Integer> serviceLane(int n, List<List<Integer>> cases , List<Integer> width) {
		ArrayList <Integer> widest = new ArrayList <Integer>();
	    int arr [] = new int [2];
	    int min = Integer.MAX_VALUE;
	    for(int i = 0; i < cases.size() ; i++){
	        for(int j = 0; j < cases.get(i).size(); j++){
	            arr[j] = cases.get(i).get(j);
	        }
	        for(int k = arr[0]; k < arr[1]; k++){
	            if(width.get(k) < min){
	                min = width.get(k);
	            }
	        }
	        widest.add(min);
	        min = Integer.MAX_VALUE;
	    }    
	    return widest;

	}

	public static void main(String[] args) {
		List<Integer> width = new ArrayList<Integer>();
		width.add(2);
		width.add(3);
		width.add(2);
		width.add(1);
		int n = width.size();
		List<List<Integer>> cases = new ArrayList<List<Integer>>();
		List<Integer> cases1 = new ArrayList<Integer>();
		List<Integer> cases2 = new ArrayList<Integer>();
		cases1.add(1);
		cases1.add(2);
		
		cases2.add(2);
		cases2.add(4);
		
		cases.add(cases1);
		cases.add(cases2);
		
		System.out.println(serviceLane(n, cases, width));
		
		

	}

}
