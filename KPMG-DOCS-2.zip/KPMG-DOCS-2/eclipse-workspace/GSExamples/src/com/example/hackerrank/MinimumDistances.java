package com.example.hackerrank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MinimumDistances {
	public static int minimumDistances(List<Integer> a) {
		Map<Integer, Integer> hm = new HashMap<>();
	    int minDist= Integer.MAX_VALUE;
	    
	    int[] arr = new int[a.size()];
	    for(int i=0; i < a.size(); i++){
	        arr[i] = a.get(i);
	        if(hm.containsKey(arr[i])) {
	            int x=hm.get(arr[i]);
	            int dist = i - x;
	            if(dist < minDist) minDist = dist;
	        }
	        else hm.put(arr[i],i);            
	    }
	    if(minDist == Integer.MAX_VALUE) minDist=-1;    
        return minDist;
	}

	public static void main(String[] args) {
		List<Integer> a = new ArrayList<Integer>();
		a.add(3);
		a.add(2);
		a.add(1);
		a.add(2);
		a.add(3);
		System.out.println(minimumDistances(a));
	}

}
