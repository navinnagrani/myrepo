package com.example.hackerrank;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;
public class TestClass<T> {
	class Result {

	    /*
	     * Complete the 'maxHeight' function below.
	     *
	     * The function is expected to return an INTEGER.
	     * The function accepts following parameters:
	     *  1. INTEGER_ARRAY wallPositions
	     *  2. INTEGER_ARRAY wallHeights
	     */

	    public int maxHeight(List<Integer> wallPositions, List<Integer> wallHeights) {
	        int n = wallPositions.size();
	        int mud_max = 0;
	        for(int i=0;i<n-1;i++) {
	            if(wallPositions.get(i) < (wallPositions.get(i + 1) - 1)) {
	                int heightDiff = Math.abs(wallHeights.get(i + 1) - wallHeights.get(i));
	                int gapLen = wallPositions.get(i + 1) - wallPositions.get(i) - 1;
	                int localMax = 0;
	                if(gapLen > heightDiff) {
	                    int low = Math.max(wallHeights.get(i + 1), wallHeights.get(i)) + 1;
	                    int remainingGap = gapLen - heightDiff - 1;
	                    localMax = low + remainingGap / 2;
	                } else {
	                    localMax = Math.min(wallHeights.get(i + 1), wallHeights.get(i)) + gapLen;
	                }
	                mud_max = Math.max(mud_max, localMax); 
	            }
	        }
	        return mud_max;

	    }

	}
	public static void main(String args[]) {
		List<List<String>> emp = Arrays.asList(Arrays.asList("Sachin","Tarun"),Arrays.asList("Jack","Mic"),Arrays.asList("Same","gop","Ank"),Arrays.asList("Anil"));
		List<String> res = emp.stream().flatMap(name -> name.stream()).filter(s->s.startsWith("A")).collect(Collectors.toList());
		
		res.forEach(System.out::print);
	}

}







