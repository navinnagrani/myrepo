package com.example.hackerrank;
import java.util.*;
import java.util.stream.Collectors;

public class EqualizeArray {
	public static int equalizeArray(List<Integer> arr) {
		/*int count =0;
		if(arr.size() <= 0 || arr == null) {
			return 0;
		}
		
		for(Integer i : arr) {
			List<Integer>result = arr.stream()
				    .distinct()
				    .collect(Collectors.toList());
			if(result.get(i) != i) {
				count++;
			}
		}
		
		return count;*/
		int max = 1;
        Map<Integer, Integer> nums = new HashMap<>();
        for (Integer i : arr)
        if (!nums.containsKey(i))
            nums.put(i, 1);
        else {
            nums.put(i, nums.get(i) + 1);
            if (max < nums.get(i))
                max = nums.get(i);
        }
        return arr.size() - max;

	}

	public static void main(String[] args) {
		List<Integer> arr = new ArrayList<Integer>();
		arr.add(3);
		arr.add(3);
		arr.add(2);
		arr.add(1);
		arr.add(3);
		System.out.println(equalizeArray(arr));

	}

}
