package com.example.hackerrank;

import java.util.*;

public class TimeInWords {
	public static String timeInWords(int hour, int min) {
		String[] numNames = { "", " one", " two", " three", " four", " five",
				" six", " seven", " eight", " nine", " ten", " eleven",
				" twelve", " thirteen", " fourteen", " fifteen", " sixteen",
				" seventeen", " eighteen", " nineteen" };
		String[] tensNames = { "", " ten", " twenty", " thirty", " fourty",
				" fifty", " sixty", " seventy", " eighty", " ninety" };
		String sepString1 = " minutes past ";
		String sepString2 = " minutes to ";
		String minString = "";
		if (min == 0)
			return numNames[hour].trim() + " o' clock";
		else if (min == 15)
			return "quarter past " + numNames[hour].trim();
		else if (min < 30) {
			if (min == 1)
				sepString1 = " minute past ";
			if (min < 20)
				minString = numNames[min % 20];
			else {
				minString = numNames[min % 10];
				min /= 10;
				minString = tensNames[min % 10] + minString;
			}
			return minString.trim() + sepString1
					+ numNames[hour].trim();
		} else if (min == 30)
			return "half past " + numNames[hour].trim();
		else if (min == 45)
			return "quarter to "
					+ numNames[hour + 1 < 12 ? hour + 1 : 1].trim();
		else if (min > 30) {
			min = 60 - min;
			if (min == 1)
				sepString2 = " minute to ";
			if (min < 20)
				minString = numNames[min % 20];
			else {
				minString = numNames[min % 10];
				min /= 10;
				minString = tensNames[min % 10] + minString;
			}
			
		}
		return minString.trim() + sepString2
				+ numNames[hour + 1 <= 12 ? hour + 1 : 1].trim();
    }

	

	public static void main(String[] args) {

	}

}
