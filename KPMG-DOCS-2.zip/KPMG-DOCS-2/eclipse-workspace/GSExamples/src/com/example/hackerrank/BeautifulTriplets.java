package com.example.hackerrank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class BeautifulTriplets {
	public static int beautifulTriplets(int d, List<Integer> arr) {
		HashMap<Integer, Integer> h = new HashMap<>();
		for (int i = 0; i < arr.size(); i++) {
			if (h.containsKey(arr.get(i))) {
				h.replace(arr.get(i), h.get(arr.get(i)) + 1);
			} else {
				h.put(arr.get(i), 1);
			}
		}
		int c = 0;
		for (Integer x : h.keySet()) {
			if (h.containsKey(x + d) && h.containsKey(x + 2 * d)) {
				c += Math.max(h.get(x), Math.max(h.get(x + d), h.get(x + 2 * d)));
			}
		}
		return c;
	}

	public static void main(String[] args) {
		List<Integer> arr = new ArrayList<Integer>();
		arr.add(2);
		arr.add(2);
		arr.add(3);
		arr.add(4);
		arr.add(5);
		int d = 1;
		System.out.println(beautifulTriplets(d, arr));
	}

}
