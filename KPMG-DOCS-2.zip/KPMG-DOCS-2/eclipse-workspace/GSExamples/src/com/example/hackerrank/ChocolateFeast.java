package com.example.hackerrank;

public class ChocolateFeast {
	public static int chocolateFeast(int n, int c, int m) {
		int count = n / c;
		int wp = count;
		
		while(wp >= m) {
			int free = wp/m;
			count+=free;
			wp = free + wp % m;
		}
		return count;
	}

	public static void main(String[] args) {
		System.out.println(chocolateFeast(15, 3, 2));
	}

}
