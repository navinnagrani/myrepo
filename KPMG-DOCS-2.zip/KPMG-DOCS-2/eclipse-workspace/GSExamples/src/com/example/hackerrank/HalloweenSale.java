package com.example.hackerrank;

public class HalloweenSale {
	public static int howManyGames(int p, int d, int m, int s) {
		int priceCurr = p;
		int i = 0;
		while (s >= priceCurr) {
			s = s - priceCurr;
			if (priceCurr >= m + d) {
				priceCurr = priceCurr - d;
			} else {
				priceCurr = m;
			}

			i++;
		}
		return i;

	}

	public static void main(String[] args) {
		System.out.println(howManyGames(20, 3, 6, 70));

	}

}
