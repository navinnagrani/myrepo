package com.example.hackerrank;
import java.util.*;
public class MyTest {
	/*
	 * Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements.
	Note that you must do this in-place without making a copy of the array.
	 
	Example 1:
	Input: nums = [0,1,0,3,12]
	Output: [1,3,12,0,0]
	Example 2:
	Input: nums = [0]
	Output: [0]
	 
	Constraints:
	1 <= nums.length <= 104
	-231 <= nums[i] <= 231 - 1
*/
	
	static int[] findNum(int[] arr,int tar) {
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++) {
			int com = tar - arr[i];
			if(m.containsKey(com)) {
				return new int[] {m.get(com),i};
			} else {
				m.put(arr[i], i);
			}
			
		}
		return new int[] {};
	}
	
	static void moveZero(int arr[]) {
		int count = 0;
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i] != 0) {
				int temp = arr[i];
				arr[i] = arr[count];
				arr[count] = temp;
				count++;
				
			}
		}
//		while(count < arr.length) {
//			arr[count++] =0;
//		}
	}
	
	static void test() {
		
	}
	public static void main(String[] args) {
		
		List<Integer> lis = new ArrayList<Integer>();
//		lis.add();
//		lis.add();
//		lis.add();
//		lis.add();
//		lis.add();
		
		int[] arr = new int[20];
		arr[19] = 8;
		String stringArr = Arrays.toString(arr);
		System.out.println(stringArr);
		test();
		
		Map<String, Integer> m = new HashMap<String, Integer>();
		m.put("FB", 1);
		m.put("Ea", 2);
		m.put("ccc", 3);
		m.put("ddd", 4);
		
		System.out.println("FB".hashCode() + " " + "Ea".hashCode());

	}

}
