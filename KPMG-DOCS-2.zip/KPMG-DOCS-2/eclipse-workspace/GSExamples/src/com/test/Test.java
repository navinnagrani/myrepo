package com.test;
import java.util.*;
public class Test {
	
	public static void main(String[] args) {
		
		List<Integer> planets = null;
		int n = planets.size();
        int leftOdd[] = new int[n], leftEven[] = new int[n];
        int rightOdd[] = new int[n], rightEven[] = new int[n];
        int odd = 0, even = 0;
        for(int i=0;i<n;i++) {
            leftOdd[i] = odd;
            leftEven[i] = even;
            if(i%2==0) even+= planets.get(i);
            else odd+=planets.get(i);
        }
        odd = 0;
        even = 0;
        for(int i=n-1;i>=0;i--){
            rightOdd[i] = odd;
            rightEven[i] = even;
            if(i%2==0) even += planets.get(i);
            else odd += planets.get(i);
        }
        int count = 0;
        for(int i=0;i<n;i++) {
            if(leftOdd[i] +rightEven[i] == leftEven[i] + rightOdd[i]) {
                count++;
            }
        }
        //return count;
	}
	
	public static int getPlanetToDestroy(List<Integer> planets) {
        int count = 0;
        for(int i=0;i<planets.size();i++) {
            if(evenOddCheck(removeEleInList(planets,i))) {
                count++;
            }
        }
        return count;
    }
    static List<Integer> removeEleInList(List<Integer> arr, int in) {
        List<Integer> res = new ArrayList<>();
        for(int i=0,j=0;i<arr.size()&&j<res.size();i++,j++) {
            if(i == in)  {
                res.add(arr.get(i+1));
                i++;
            } else {
                res.add(arr.get(i));
            }
        }
        return res;
    }
    
    static boolean evenOddCheck(List<Integer> arr) {
        int evenSum = 0,oddSum =0;
        for(int i=0;i<arr.size();i++) {
            evenSum += arr.get(i);
        }
        for(int i=1;i<arr.size();i++) {
            oddSum+=arr.get(i);
        }
        return evenSum == oddSum || evenSum ==0 && oddSum==0;
    }

}
