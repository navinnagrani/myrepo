package com.test;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;


interface mul1 {
	default void result() {
		int x = 7 , y = 21;
		int res = x*y;
		System.out.println("in 1 "+ res);
	}
}
interface mul2 {
	default void result() {
		int x = 5 , y = 13;
		int res = x*y;
		System.out.println("in 2 "+ res);
	}
}
public class Solution {
	static final String str = "";
	public static void main(String[] args) {
		
		String str = "ABC";
		System.out.println(Solution.str);
		
	}
	static {
		String st = "Hi";
		st = "XYZ";
	}

}
