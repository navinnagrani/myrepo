package pkg.test;

public class MyClass {

}
