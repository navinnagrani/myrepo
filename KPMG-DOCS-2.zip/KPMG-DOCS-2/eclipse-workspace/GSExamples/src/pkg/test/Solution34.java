package pkg.test;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

public class Solution34 {



    // Complete the maxTickets function below.
    static int maxTickets(List<Integer> tickets) {
        Collections.sort(tickets);
    
        int ret=Integer.MIN_VALUE;
        int cnt = 1;
        int len = tickets.size();
    
        for(int i=1;i<len;i++){
            System.out.println("get(i) :"+tickets.get(i)+"  get(i-1):"+tickets.get(i-1));
            if(tickets.get(i)-tickets.get(i-1)>1){
                ret = Math.max(ret,cnt);
                cnt = 1;  //reset cnt to 1
            }else{
                cnt++;
            }
    }

    return Math.max(ret,cnt);

    }
//    long[][] dp = new long[groups+1][people+1];
//    for(int i=1;i<groups;i++) {
//        for(int j=i;j<people;j++) {
//            if(i==j) {
//                dp[i][j] = 1;
//            } else {
//                dp[i][j] = dp[i-1][j-1] +dp[i][j-i];
//            }
//        }
//    }
//    return dp[groups][people];
    
    /*
     * select cities.city_name,floor(avg(revenue.revenue))
from cities,revenue
where cities.city_code = revenue.city_code
group by cities.city_name*/

}
