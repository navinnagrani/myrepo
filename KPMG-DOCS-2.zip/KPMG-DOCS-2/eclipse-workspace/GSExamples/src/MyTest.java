import java.util.ArrayList;
import java.util.List;

class Employee {
	
}
class Accountant extends Employee {
	
}
public class MyTest {
	static MyTest t;
	static int count = 0;
	public static void main(String[] args) throws InterruptedException {
		MyTest t1 = new MyTest();
		t1 = null;
		System.gc();
		Thread.sleep(1000);
		t = null;
		System.gc();
		Thread.sleep(1000);
		System.out.println("Final mthd count "+count+"times");
		
	}
	@Override
	protected void finalize() {
		count++;
		t = this;
	}

	
}
