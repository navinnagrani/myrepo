import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Test {
	private String fName;
	private String lName;
	
	public Test(String fName, String lName) {
		this.fName = fName;
		this.lName = lName;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}
	
	public int hashCode() {
		return 13;
	}
	

	@Override
	public String toString() {
		return "Test [fName=" + fName + ", lName=" + lName + "]";
	}

	public static void main(String[] args) {
		Test t1 = new Test("fName1", "lName1");
		Test t2 = new Test("fName2", "lName2");
		
		Map<Test, String> m = new HashMap<Test, String>();
		m.put(t1,"This is first");
		m.put(t2, "This is second");
		m.put(new Test("fName1","lNAme1"), "This is overriding");
		
		
		System.out.println(m.size());
		System.out.println(m.get(new Test("fName1","lname1")));
	}

}
