
import java.util.*;
public class NewTest {

	public static void main(String[] args) {
		
	}

}
