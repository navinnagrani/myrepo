--<ScriptOptions statementTerminator=";"/>

CREATE TABLE BOOK (
		BOOKNAME VARCHAR(45),
		AUTHOR VARCHAR(45)
	);

