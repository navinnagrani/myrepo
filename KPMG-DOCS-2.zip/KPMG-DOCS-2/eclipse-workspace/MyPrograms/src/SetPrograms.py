'''
Created on Apr 16, 2021

@author: navinnagrani
'''
print("program to create a set")
s = set([0,1,2,3,4,4])
print(s)

print("program to iterate over sets")
s = set([0,1,2,3,4,4])
for i in s:
    print(i)
    
print("program to add member(s) in a set")
s = set([0,1,2,3,4,4])
s.add(5)
print(s)
s.update([6,7])
print(s)

print("program to remove item(s) from set")
num_set = set([0, 1, 3, 4, 5])
num_set.pop()
print(num_set)

print("program to remove an item from a set if it is present in the set")
s = set([0, 1, 2, 3, 4, 5])
s.discard(5)
print(s)

print("program to create an intersection of sets")
setx = set(["green", "blue"])
sety = set(["blue", "yellow"])

s = setx.intersection(sety)
print(s)

print("program to create a union of sets")
setx = set(["green", "blue"])
sety = set(["blue", "yellow"])
s = setx | sety # or setx.union(sety)
print(s)


print("program to create set difference")
setx = set(["green", "blue"])
sety = set(["blue", "yellow"])
s = setx.difference(sety) #or setx - sety
print(s)

print("program to create a symmetric difference")
setx = set(["apple", "mango"])
sety = set(["mango", "orange"])
s = setx.symmetric_difference(sety) #or setx ^ sety
print(s)

print("program to check if a set is a subset of another set")
setx = set(["apple", "mango"])
sety = set(["mango", "orange"])
setz = set(["mango"])

print(setx.issubset(sety))
print(setz.issubset(setx))


print("program to create a shallow copy of sets")
setp = set(["Red", "Green"])
setq = set(["Green", "Red"])
setnew = setp.copy()
print(setnew)

print("program to clear a set")
s = set([1,2,3,4,5])
print(s)
s.clear()
print(s)

print("program to use of frozensets")
x = frozenset([1, 2, 3, 4, 5])
y = frozenset([3, 4, 5, 6, 7])
print(x.isdisjoint(y))
print(x.difference(y))

print(" program to find maximum and the minimum value in a set")
s = ([1,2,4,6,88,23])
print(max(s),min(s))

print("program to find the length of a set")
s = ([1,2,4,6,88,23])
print(len(s))

print("program to check if a given value is present in a set or not")
s = ([1,2,4,6,88,23])
print(6 in s)

print("program to check if two given sets have no elements in common")
x = {1,2,3,4}
y = {4,5,6,7}
z = {8}
print(x.isdisjoint(z))
print(y.isdisjoint(z))
print(x.isdisjoint(y))

print("program to check if a given set is superset of itself and superset of another given set")
nums = {10,20,30,40,50}
num1 = {1, 2, 3, 4, 5, 7}
num2 = {2, 4}
num3 = {2, 4}

print(nums.issuperset(nums))
print(num1>num2)
print(num2>num3)
print(num3>num2)

print("program to find the elements in a given set that are not in another set")
sn1 = {1,2,3,4,5}
sn2 = {4,5,6,7,8}
print(sn1.difference(sn2))
print(sn2.difference(sn1))

print("program to check a given set has no elements in common with other given set")
sn1 = {1,2,3}
sn2 = {4,5,6}
sn3 = {3}
print(sn1.isdisjoint(sn2))
print(sn1.isdisjoint(sn3))

print("program to remove the intersection of a 2nd set from the 1st set")
sn1 = {1,2,3,4,5}
sn2 = {4,5,6,7,8}
sn1.difference_update(sn2)
print(sn1)