'''
Created on Apr 12, 2021

@author: navinnagrani
'''

import operator
from collections import Counter
import itertools
from heapq import nlargest
from operator import itemgetter
from collections import defaultdict
import json
from pprint import pprint
from itertools import product



print("script to sort (ascending and descending) a dictionary by value")
d = {1: 2, 3: 4, 4: 3, 2: 1, 0: 0}
sod = sorted(d.items(),key=operator.itemgetter(1))
print(dict(sod))

print(" script to add a key to a dictionary")
ogd = {0: 10, 1: 20}
ogd.update({2:30})
print(ogd)

print("script to concatenate following dictionaries to create a new one")
dic1={1:10, 2:20}
dic2={3:30, 4:40}
dic3={5:50,6:60}
d4 = {}
for d in (dic1, dic2, dic3): d4.update(d)
print(d4)

print("script to check whether a given key already exists in a dictionary")
d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
if 5 in d:
    print("present")
else:
    print("Not Present")
    
print("program to iterate over dictionaries using for loops")
d = {'x': 10, 'y': 20, 'z': 30}
for dick,dicv in d.items():
    print(dick,dicv)

print("script to generate and print a dictionary that contains a number (between 1 and n) in the form (x, x*x)")
d = {}
n = 5
for i in range(1,n+1):
    d[i] = i*i
print(d)

print("script to print a dictionary where the keys are numbers between 1 and 15 (both included) and the values are square of keys")
d = {}
for i in range(1,16):
    d[i] = i ** 2
print(d)

print("script to merge two Python dictionaries")
d1 = {'a': 100, 'b': 200}
d2 = {'x': 300, 'y': 200}
d1.update(d2)
print(d1)

print("program to iterate over dictionaries using for loops")
d = {'Red': 1, 'Green': 2, 'Blue': 3}
for dk,dv in d.items():
    print(dk,dv)

print("program to sum all the items in a dictionary")
d = {'data1':100,'data2':-54,'data3':247}
print(sum(d.values()))

print("program to multiply all the items in a dictionary")
d = {'data1':100,'data2':54,'data3':247}
res = 1
for key in d.values():
    res = res * key
print(res)

print("program to remove a key from a dictionary")
myDict = {'a':1,'b':2,'c':3,'d':4}
if 'a' in myDict:
    del myDict['a']
print(myDict)

#new_dict = {key:val for key, val in test_dict.items() if key != 'Mani'}

print(" program to map two lists into a dictionary")
keys = ['red', 'green', 'blue']
values = ['#FF0000','#008000', '#0000FF']
d = dict(zip(keys,values))
print(d)

print("program to sort a dictionary by key")
color_dict = {'red':'#FF0000',
          'green':'#008000',
          'black':'#000000',
          'white':'#FFFFFF'}
for key in sorted(color_dict):
    print(key,":",color_dict[key])
    
print("program to get the maximum and minimum value in a dictionary")
my_dict = {'x':500, 'y':5874, 'z': 560}

key_max = max(my_dict.keys(), key=(lambda k: my_dict[k]))
key_min = min(my_dict.keys(), key=(lambda k: my_dict[k]))

print('Maximum Value: ',my_dict[key_max])
print('Minimum Value: ',my_dict[key_min])

print("program to remove duplicates from Dictionary")
d = {'id1': 
   {'name': ['Sara'], 
    'class': ['V'], 
    'subject_integration': ['english, math, science']
   },
 'id2': 
  {'name': ['David'], 
    'class': ['V'], 
    'subject_integration': ['english, math, science']
   },
 'id3': 
    {'name': ['Sara'], 
    'class': ['V'], 
    'subject_integration': ['english, math, science']
   },
 'id4': 
   {'name': ['Surya'], 
    'class': ['V'], 
    'subject_integration': ['english, math, science']
   },
}

res = {}

for key,value in d.items():
    if value not in res.values():
        res[key] = value
    
print(res)

print("program to check a dictionary is empty or not")
d = {1:"Navin",2:"Harsha"}
if not bool(d):
    print("Dictionary is empty")
else:
    print("Elements Present")

print("program to combine two dictionary adding values for common keys")
d1 = {'a': 100, 'b': 200, 'c':300}
d2 = {'a': 300, 'b': 200, 'd':400}
d = Counter(d1) +  Counter(d2)
print(d)

print("program to print all unique values in a dictionary")
L = [{"V":"S001"}, {"V": "S002"}, {"VI": "S001"}, {"VI": "S005"}, {"VII":"S005"}, {"V":"S009"},{"VIII":"S007"}]
uni = set(val for dic in L for val in dic.values())
print(uni)

print("program to create and display all combinations of letters, selecting each letter from a different key in a dictionary")
d ={'1':['a','b'], '2':['c','d']}
for combo in itertools.product(*[d[k] for k in sorted(d.keys())]):
    print(''.join(combo))
    
print("program to find the highest 3 values of corresponding keys in a dictionary")
my_dict = {'a':500, 'b':5874, 'c': 560,'d':400, 'e':5874, 'f': 20}  
three_largest = nlargest(3, my_dict, key=my_dict.get)
print(three_largest)

print(" program to combine values in python list of dictionaries")
ogl = [{'item': 'item1', 'amount': 400}, {'item': 'item2', 'amount': 300}, {'item': 'item1', 'amount': 750}]
result = Counter()
for d in ogl:
    result[d['item']] += d['amount']
print(result) 

print("program to create a dictionary from a string")
str = 'w3resource'
d = {}
for l in str:
    d[l] = d.get(l, 0) + 1
print(d)

print("program to print a dictionary in table format")
my_dict = {'C1':[1,2,3],'C2':[5,6,7],'C3':[9,10,11]}
for row in zip(*([key] + (value) for key, value in sorted(my_dict.items()))):
    print(*row)
    
print("program to count the values associated with key in a dictionary")
student = [{'id': 1, 'success': True, 'name': 'Lary'},
 {'id': 2, 'success': False, 'name': 'Rabi'},
 {'id': 3, 'success': True, 'name': 'Alex'}]
print(sum(d['id'] for d in student))
print(sum(d['success'] for d in student))

print("program to convert a list into a nested dictionary of keys")
num_list = [1, 2, 3, 4]
new_dict = current = {}
for name in num_list:
    current[name] = {}
    current = current[name]
print(new_dict)

print("program to sort a list alphabetically in a dictionary")
num = {'n1': [2, 3, 1], 'n2': [5, 1, 2], 'n3': [3, 2, 4]}
res = {x: sorted(y) for x,y in num.items()}
print(res)

print("program to remove spaces from dictionary keys")
student_list = {'S  001': ['Math', 'Science'], 'S    002': ['Math', 'English']}
d = {x.translate({32:None}):y for x,y in student_list.items()}
print(d)

print("program to get the top three items in a shop")
d =  {'item1': 45.50, 'item2':35, 'item3': 41.30, 'item4':55, 'item5': 24}
for name, value in nlargest(3, d.items(), key=itemgetter(1)):
    print(name, value)

print("program to get the key, value and item in a dictionary")
dict_num = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
print("key  value  count")
for count, (key, value) in enumerate(dict_num.items(), 1):
    print(key,'   ',value,'    ', count)

print("program to print a dictionary line by line")
students = {'Aex':{'class':'V',
        'rolld_id':2},
        'Puja':{'class':'V',
        'roll_id':3}}
for a in students:
    print(a)
    for b in students[a]:
        print (b,':',students[a][b])
    
print("program to check multiple keys exists in a dictionary")
student = {
  'name': 'Alex',
  'class': 'V',
  'roll_id': '2'
}
print(student.keys() >= {'class', 'name'})
print(student.keys() >= {'name', 'Alex'})
print(student.keys() >= {'roll_id', 'name'})

print("program to count number of items in a dictionary value that is a list")
dict =  {'Alex': ['subj1', 'subj2', 'subj3'], 'David': ['subj1', 'subj2']}
ctr = sum(map(len, dict.values()))
print(ctr)

print("program to sort Counter by value")
x = Counter({'Math':81, 'Physics':83, 'Chemistry':87})
print(x.most_common())

print("program to create a dictionary from two lists without losing duplicate values")
class_list = ['Class-V', 'Class-VI', 'Class-VII', 'Class-VIII']
id_list = [1, 2, 2, 3]
temp = defaultdict(set)
for c, i in zip(class_list, id_list):
    temp[c].add(i)
print(temp)

print("program to replace dictionary values with their average")
student_details= [
  {'id' : 1, 'subject' : 'math', 'V' : 70, 'VI' : 82},
  {'id' : 2, 'subject' : 'math', 'V' : 73, 'VI' : 74},
  {'id' : 3, 'subject' : 'math', 'V' : 75, 'VI' : 86}
]
for d in student_details:
    n1 = d.pop('V')
    n2 = d.pop('VI')
    d['V+VI'] = (n1 + n2)/2
print(student_details)

print("program to match key values in two dictionaries")
d1 = {'key1': 1, 'key2': 3, 'key3': 2}
d2 = {'key1': 1, 'key2': 2}
for (key, value) in set(d1.items()) & set(d2.items()):
    print('%s: %s is present in both x and y' % (key, value))

print("program to store a given dictionary in a json file")
d = {"students":[{"firstName": "Nikki", "lastName": "Roysden"},
               {"firstName": "Mervin", "lastName": "Friedland"},
               {"firstName": "Aron ", "lastName": "Wilkins"}],
"teachers":[{"firstName": "Amberly", "lastName": "Calico"},
         {"firstName": "Regine", "lastName": "Agtarap"}]}
print(type(d))
with open("dictionary", "w") as f:
   json.dump(d, f, indent = 4, sort_keys = True)
 
print("\nJson file to dictionary:")
with open('dictionary') as f:
 data = json.load(f)
print(data)

print("program to drop empty Items from a given Dictionary")
dict1 = {'c1': 'Red', 'c2': 'Green', 'c3':None}
dict1 = {key:value for (key, value) in dict1.items() if value is not None}
print(dict1)

print("program to filter a dictionary based on values")
d = {'Cierra Vega': 175, 'Alden Cantrell': 180, 'Kierra Gentry': 165, 'Pierre Cox': 190}
result = {key:value for (key, value) in d.items() if value >= 170}
print(result)

print("program to convert more than one list to nested dictionary")
l1 = ["S001", "S002", "S003", "S004"] 
l2 = ["Adina Park", "Leyton Marsh", "Duncan Boyle", "Saim Richards"] 
l3 = [85, 98, 89, 92]
res = result = [{x: {y: z}} for (x, y, z) in zip(l1, l2, l3)]
print(res)

print("program to filter the height and width of students, which are stored in a dictionary")
students = {'Cierra Vega': (6.2, 70), 'Alden Cantrell': (5.9, 65), 'Kierra Gentry': (6.0, 68), 'Pierre Cox': (5.8, 66)}
res = {k:s for (k,s) in students.items() if s[0] >=6.0 and s[1] >= 70}
print(res)

print("program to check all values are same in a dictionary")
d = {'Cierra Vega': 12, 'Alden Cantrell': 12, 'Kierra Gentry': 12, 'Pierre Cox': 12}
res = bool({k:s for k,s in d.items() if s == 12})
print(res)
print("OR")
result = all(x == n for x in d.values())
print(result)

print("program to create a dictionary grouping a sequence of key-value pairs into a dictionary of lists")
colors = [('yellow', 1), ('blue', 2), ('yellow', 3), ('blue', 4), ('red', 1)]
result = {}
for k, v in colors:
    result.setdefault(k, []).append(v)
    
print(result)

# print("program to split a given dictionary of lists into list of dictionaries")
# marks = {'Science': [88, 89, 62, 95], 'Language': [77, 78, 84, 80]}
# keys = marks.keys()
# vals = zip(*[marks[k] for k in keys])
# result = [dict(zip(keys, v)) for v in vals]
# print(result)

print("program to remove a specified dictionary from a given list")
ogd = [{'id': '#FF0000', 'color': 'Red'}, {'id': '#800000', 'color': 'Maroon'}, {'id': '#FFFF00', 'color': 'Yellow'}, {'id': '#808000', 'color': 'Olive'}]
re = "#FF0000"
ogd[:] = [d for d in ogd if d.get('id') != re]
print(ogd)

# print("program to convert string values of a given dictionary, into integer/float datatypes")
# ogd = [{'x': '10', 'y': '20', 'z': '30'}, {'p': '40', 'q': '50', 'r': '60'}]
# result = result = [dict([a, int(x)] for a, x in b.items()) for b in ogd]
# print(result)

print("Python program to clear the list values in the said dictionary")
ogd = {'C1': [10, 20, 30], 'C2': [20, 30, 40], 'C3': [12, 34]}
for key in ogd:
    ogd[key].clear()
print(ogd)

print("program to update the list values in the said dictionary")
ogd = {'Math': [88, 89, 90], 'Physics': [92, 94, 89], 'Chemistry': [90, 87, 93]}
ogd['Math'] = [x+1 for x in ogd['Math']]
print(ogd)

print("program to extract a list of values from a given list of dictionaries")
ogd = [{'Math': 90, 'Science': 92}, {'Math': 89, 'Science': 94}, {'Math': 92, 'Science': 88}]
res = [d['Science'] for d in ogd if 'Science' in d]
print(res)

print("program to find the length of a given dictionary values")
ogd = {1 : 'red', 2 : 'green', 3 : 'black', 4 : 'white', 5 : 'black'}
result = {}
for val in ogd.values(): 
    result[val] = len(val)
print(result)

# print("program to get the depth of a dictionary")
# def dict_depth(d):
#     if isinstance(d, dict):
#         return 1 + (max(map(dict_depth, d.values())) if d else 0)
#     return 0
# dic = {'a':1, 'b': {'c': {'d': {}}}}
# print(dict_depth(dic))
 
print("program to access dictionary key's element by index")
num = {'physics': 80, 'math': 90, 'chemistry': 86}
print(list(num)[0])
print(list(num)[1])
print(list(num)[2])

print("program to convert a given dictionary into a list of lists")
ogd = {1: 'red', 2: 'green', 3: 'black', 4: 'white', 5: 'black'}
res = list(map(list,ogd.items()))
print(res)

print(" program to filter even numbers from a given dictionary values")
ogd = {'V': [1, 4, 6, 10], 'VI': [1, 4, 12], 'VII': [1, 3, 8]}
res = {key: [idx for idx in val if not idx % 2]  
          for key, val in ogd.items()}
print(res)
    
# print("program to get all combinations of key-value pairs in a given dictionary")
# ogd = {'V': [1, 4, 6, 10], 'VI': [1, 4, 12], 'VII': [1, 3, 8]}
# result = list(map(dict, itertools.combinations(ogd.items(), 2)))
# print(result)

print("program to find the specified number of maximum values in a given dictionary")
ogd = {'a':5, 'b':14, 'c': 32, 'd':35, 'e':24, 'f': 100, 'g':57, 'h':8, 'i': 100}
result = sorted(ogd, key=ogd.get, reverse=True)[:1]
print(result)

print("program to find shortest list of values with the keys in a given dictionary")
ogd = {'V': [10, 12], 'VI': [10], 'VII': [10, 20, 30, 40], 'VIII': [20], 'IX': [10, 30, 50, 70], 'X': [80]}
min_value=1
result = [k for k, v in ogd.items() if len(v) == (min_value)]
print(result)

print("program to count the frequency in a given dictionary")
ogd = {'V': 10, 'VI': 10, 'VII': 40, 'VIII': 20, 'IX': 70, 'X': 80, 'XI': 40, 'XII': 20}
res = Counter(ogd.values())
print(res)

print("program to extract values from a given dictionaries and create a list of lists from those values")
def test(dictt,keys):
    return [list(d[k] for k in keys) for d in dictt] 

students = [
        {'student_id': 1, 'name': 'Jean Castro', 'class': 'V'}, 
        {'student_id': 2, 'name': 'Lula Powell', 'class': 'V'},
        {'student_id': 3, 'name': 'Brian Howell', 'class': 'VI'}, 
        {'student_id': 4, 'name': 'Lynne Foster', 'class': 'VI'}, 
        {'student_id': 5, 'name': 'Zachary Simon', 'class': 'VII'}
        ]

print("\nOriginal Dictionary:")
print(students)
print("\nExtract values from the said dictionarie and create a list of lists using those values:")
print("\n",test(students,('student_id', 'name', 'class')))
print("\n",test(students,('student_id', 'name')))
print("\n",test(students,('name', 'class')))

print("program to convert a given list of lists to a dictionary")
ogl = [[1, 'Jean Castro', 'V'], [2, 'Lula Powell', 'V'], [3, 'Brian Howell', 'VI'], [4, 'Lynne Foster', 'VI'], [5, 'Zachary Simon', 'VII']]
res =result = {item[0]: item[1:] for item in ogl}
print(res)

# print("program to create a key-value list pairings in a given dictionary")
# ogd = {1: ['Jean Castro'], 2: ['Lula Powell'], 3: ['Brian Howell'], 4: ['Lynne Foster'], 5: ['Zachary Simon']}
# result = [dict(zip(ogd, sub)) for sub in product(*ogd.values())]
# print(result)

print("program to get the total length of all values of a given dictionary with string values")
ogd = {'#FF0000': 'Red', '#800000': 'Maroon', '#FFFF00': 'Yellow', '#808000': 'Olive'}
result = sum((len(values) for values in ogd.values()))
print(result)

print("program to check if a specific Key and a value exist in a dictionary")
ogd = [{'student_id': 1, 'name': 'Jean Castro', 'class': 'V'}, {'student_id': 2, 'name': 'Lula Powell', 'class': 'V'}, {'student_id': 3, 'name': 'Brian Howell', 'class': 'VI'}, {'student_id': 4, 'name': 'Lynne Foster', 'class': 'VI'}, {'student_id': 5, 'name': 'Zachary Simon', 'class': 'VII'}]
ke = 'student_id'
vl = 1
ch = False
if any(sub[ke] == vl for sub in ogd):
       ch= True
else:
   ch = False
print(ch)