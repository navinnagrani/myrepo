'''
Created on Apr 19, 2021

@author: navinnagrani
'''
import datetime
import ast
from datetime import date
from pickle import TRUE


print("Date time")
now = datetime.datetime.now()
print(now.strftime("%Y-%m-%d %H:%M:%S"))

from math import pi, sqrt
r = 1.1
rad = pi*r**2
print(rad)


fname = "Navin"#input("Firstname ")
lname = "Nagrani" #input("Lastname ")
print(lname , fname)

# ch = ast.literal_eval(input("Input some comma seprated numbers : "))
# print(ch)
# li = list(ch)
# print(li)

# filename = input("Enter filename")
# fext = filename.split(".")
# print(repr(fext[-1]))

color_list = ["Red","Green","White" ,"Black"]
print(color_list[0],color_list[-1])

exam_st_date = (11,12,2014)
print("%i / %i / %i "%exam_st_date)

a = 5
n1 = int( "%s" % a )
n2 = int( "%s%s" % (a,a) )
n3 = int( "%s%s%s" % (a,a,a) )
print (n1+n2+n3)

import calendar
# x = int(input("Enter year "))
# y = int(input("Enter month "))
# print(calendar.month(x,y))

d1 = date(2014, 7, 2)
d2 = date(2014, 7, 11)
print(d2-d1)

n = 22
ch = 0
if n<=17:
    ch = 17-n
else:
    ch = (n - 17) * 2
print(ch)

x = 10
y = 10
z = 20
s = x + y + z
  
if x == y == z:
      s = s * 3
print(s)
    
def checkIs(str):
    if len(str)>=2 and str[:2]=='Is':
        return str
    return "Is" + str

print(checkIs("Array"))
print(checkIs("IsEmpty"))

st = "abc"
n = 2
res = ""
for i in range(n):
    res = res+ st
print(res)

n = 13
if n%2==0:
    print("even")
else:
    print("Odd")
    
l = [1, 4, 6, 7, 4]
ctr = 0
for i in l:
    if i == 4:
        ctr+=1
print(ctr)

st = "abcedf"
n = 2
flen = 2
if flen > len(st):
    flen = len(st)
substr = st[:flen]
  
result = ""
for i in range(n):
    result = result + substr
print(result)

hh = 'a'
l = ['a','e','i','o','u']
print(hh in l)

l = [2, 3, 6, 5]
for n in l:
    output = ''
    times = n
    while( times > 0 ):
        output += '*'
        times = times - 1
    print(output)

l = [1, 5, 12, 2]
res = ''
for el in l:
       res += str(el)
print(res)

numbers = [    
    386, 462, 47, 418, 907, 344, 236, 375, 823, 566, 597, 978, 328, 615, 953, 345, 
    399, 162, 758, 219, 918, 237, 412, 566, 826, 248, 866, 950, 626, 949, 687, 217, 
    815, 67, 104, 58, 512, 24, 892, 894, 767, 553, 81, 379, 843, 831, 445, 742, 717, 
    958,743, 527
    ]
for x in numbers:
    if x==237:
        print(x)
        break
    elif x%2==0:
        print(x)
        
color_list_1 = set(["White", "Black", "Red"])
color_list_2 = set(["Red", "Green"])

print(color_list_1.difference(color_list_2))

b = 5
h = 6
print(b*h/2)

x = 2
y = 1
z = 2
if x == y or y == z or x ==z:
    s = 0
else:
    s = x+y+z
print(s)

x = 10
y = 6

s = x+y
if s in range(15,20):
    s = 20
else:
    s = x+y
print(s)

# def add_numbers(a, b):
#     if not (isinstance(a, int) and isinstance(b, int)):
#          raise TypeError("Inputs must be integers")
#     return a + b
# 
# print(add_numbers('gag','uuu'))

import os.path
open('abc.txt', 'w')
print(os.path.isfile('abc.txt'))

import struct
print(struct.calcsize("P") * 8)

import platform
import os
print(os.name)
print(platform.system())
print(platform.release())

import site; 
print(site.getsitepackages())

# import requests
# response = requests.get("https://api.open-notify.org/this-api-doesnt-exist")
# print(response.status_code)

import os
print("Current File Name : ",os.path.realpath(__file__))

import multiprocessing
print(multiprocessing.cpu_count())


# import cProfile
# def s():
#     print(1+2)
# cProfile.run('s()')

import getpass
print(getpass.getuser())

import socket
print([l for l in ([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] 
if not ip.startswith("127.")][:1], [[(s.connect(('8.8.8.8', 53)), 
s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, 
socket.SOCK_DGRAM)]][0][1]]) if l][0][0])


n = 5
print((n * (n+1))/2)

print("Input your height: ")
h_ft =6 #int(input("Feet: "))
h_inch = 2#int(input("Inches: "))

h_inch += h_ft * 12
h_cm = round(h_inch * 2.54, 1)

print("Your height is : %d cm." % h_cm)

a = 3
b = 4
print("Hypotenuse : ",sqrt(a**2 + b**2))

def absolute_file_path(path_fname):
        import os
        return os.path.abspath('path_fname')        
print("Absolute file path: ",absolute_file_path("test.txt"))

list_of_colors = ['Red', 'White', 'Black']
l = ''.join(list_of_colors)
print(l)


s = sum([10,20,30])
print("\ns of the container: ", s)
print()

num = [2,3,4]
print(all(x > 1 for x in num))

s = "The quick brown fox jumps over the lazy dog."
print(s.count('q'))

print()
print(ord('a'))
print(ord('A'))
print(ord('1'))
print(ord('@'))
print()

import os
file_size = os.path.getsize("BasicPrograms.py")
print("\nThe size of abc.txt is :",file_size,"Bytes")
print()

a = 20
b = 30
a,b = b,a
print(a,b)

#str = 'a123'
stjj = '123'
try:
    i = float(stjj)
except (ValueError, TypeError):
    print('\nNot numeric')
print()


from datetime import datetime

now = datetime.now()

current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

import time
print()
print(time.ctime())
print()


import socket
host_name = socket.gethostname()
print()
print("Host name:", host_name)
print()

num_list = [45, 55, 60, 37, 100, 105, 220]
res = list(filter(lambda e : (e % 15==0),num_list))
print(res)

num_list = ["Red", "Black", "Green", "White", "Orange"]
del num_list[0]
print(num_list)

# while True:
#     try:
#         a = int(input("Enter number : "))
#         break
#     except ValueError:
#         print("This is not num .. Try again !!")
#         print()

nums = [34, 1, 0, -23]
res = list(filter(lambda e:e>0,nums))
print(res)

from functools import reduce
nums = [10, 20, 30,40]
nump = reduce(lambda x,y : x*y, nums)
print(nump)

strn = "1234567890"
print("%.6s"%strn)

import collections
num = [2,2,4,6,6,8,6,10,4]
print(sum(collections.Counter(num).values()))

str1 = 'A8238i823acdeOUEI'
print(any(c.islower() for c in str1))

str1='122.22'
str1 = str1.ljust(8, '0')
print(str1)

# print("Enter x and y ")
# x , y = input().split()
# print(x,y)

x = 30
print('Value of x is "{}"'.format(x))

d = {'Red': 'Green'}
(c1, c2), = d.items()
print(c1)
print(c2)

import socket
addr = '198.0.1.32'
try:
    socket.inet_aton(addr)
    print("Valid IP")
except socket.error:
    print("Invalid IP")
    
x = 12
print(format(x, '08b'))
print(format(x, '010b'))


t = [1,2,3,4]
print(type(t))

m =20
n = 2
if m%n==0:
    ch = True
else:
    ch = False
print(ch)

l = [0, 10, 15, 40, -5, 42, 17, 28, 75]
print(max(l),min(l))