'''
Created on Apr 26, 2021

@author: navinnagrani
'''
def testDist(data):
    if len(data) == len(set(data)):
        return True
    else:
        return False

print(testDist([1,2,3,4]))

# import collections
# import pprint
# file_input = input('File Name: ')
# with open(file_input, 'r') as info:
#   count = collections.Counter(info.read().upper())
#   value = pprint.pformat(count)
# print(value)

import pkg_resources
installed_packages = pkg_resources.working_set
installed_packages_list = sorted(["%s==%s" % (i.key, i.version)
     for i in installed_packages])
for m in installed_packages_list:
    print(m)
    

def noteCount(n):
    Q = [500,200,100,50,20,10]
    x = 0
    for i in range(6):
        q = Q[i]
        x = x + int(n/q)
        n = int(n % q)
    if n > 0:
        x = -1
    return x
print(noteCount(880))

def absent_digits(n):
  all_nums = set([0,1,2,3,4,5,6,7,8,9])
  n = set([int(i) for i in n])
  n = n.symmetric_difference(all_nums)
  n = sorted(n)
  return n
print(absent_digits([9,8,3,2,2,0,9,7,6,3]))

# print("Input the heights of eight buildings:")
# l = [int(input()) for i in range(8)]
# print("Heights of the top three buildings:")
# l = sorted(l)
# print(l[:4:-1], sep='\n')

# print("Input two integers(a b): ")
# a,b = map(int,input().split(" "))
# print("Number of digit of a and b.:")
# print(len(str(a+b)))

arr = [10, 324, 45, 90, 9808]
print(max(arr))
