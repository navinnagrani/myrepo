'''
Created on Apr 15, 2021

@author: navinnagrani
'''
from copy import deepcopy
from pickle import TRUE



print("program to create a tuple")
t = (1,2,3)
print(type(t))
print(t)

print("program to create a tuple with different data types")
t = (12,'Navin',20.0,True)
print(t)

print("program to create a tuple with numbers and print one item")
t = (1,2,45,55,33)
print(t)
t1 = 5,
print(t1)

print("program to unpack a tuple in several variables")
t = 31,32,44
n1,n2,n3 = t
print(n1,n2,n3)

print(" program to add an item in a tuple")
t = 12,34,55
t = t + (9,)
print(t)
t = t[:5] + (15, 20, 25) + t[:5] 
print(t)  

print("program to convert a tuple to a string")
t = ('Navin','Harsha')
hh = ''.join(t)
print(hh)

print("program to get the 4th element and 4th element from last of a tuple")
tuplex = ("w", 3, "r", "e", "s", "o", "u", "r", "c", "e")
print(tuplex[3])
print(tuplex[-4])

print("program to create the colon of a tuple")
t = ("HELLO", 5, [], True)
tcol = deepcopy(t)
tcol[2].append(50)
print(tcol)

print("program to find the repeated items of a tuple")
tuplex = 2, 4, 5, 6, 2, 3, 4, 4, 7
cou = tuplex.count(4)
print(cou)

print(" program to check whether an element exists within a tuple")
t = ("w", 3, "r", "e", "s", "o", "u", "r", "c", "e")
print('r' in t)
print(5 in t)

print("program to convert a list to a tuple")
listx = [5, 10, 7, 4, 15, 3]
t = tuple(listx)
print(t)

print("program to remove an item from a tuple")
t = ('o',23,76,True)
t = t[:1] + t[3:]
print(t)

print("program to slice a tuple")
t = 90,98,'w','3','r','source',True,78,43
t = t[1::2]
print(t)

print("program to find the index of an item of a tuple")
t = tuple('Index Tuple')
print(t.index('p'))

print("program to find the length of a tuple")
t = tuple('Index Tuple')
print(len(t))

print(" program to convert a tuple to a dictionary")
tuplex = ((2, "w"),(3, "r"))
print(dict((y,x) for x,y in tuplex))

print("program to unzip a list of tuples into individual lists")
l = [(1,2), (3,4), (8,9)]
print(list(zip(*l)))

print("program to reverse a tuple")
x = ("w3resource")
y = reversed(x)
t = tuple(y)
print(t)

print("program to convert a list of tuples into a dictionary")
l = [("x", 1), ("x", 2), ("x", 3), ("y", 1), ("y", 2), ("z", 1)]
d = {}
for x,y in l:
    d.setdefault(x, []).append(y)
print(d)

print("program to print a tuple with string formatting")
t = (100, 200, 300)
print("thisis tuple {0}".format(t))

print("program to replace last value of tuples in a list")
l = [(10, 20, 40), (40, 50, 60), (70, 80, 90)]
print([t[:-1] + (100,) for t in l])

print("program to remove an empty tuple(s) from a list of tuples")
L = [(), (), ('',), ('a', 'b'), ('a', 'b', 'c'), ('d')]
L = [t for t in L if t]
print(L)

print("program to sort a tuple by its float element")
l = [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
print(sorted(l, key=lambda e:float(e[1]), reverse=True))

print("program to count the elements in a list until an element is a tupl")
num = [10,20,30,(10,20),40]
co = 0
for i in num:
    if isinstance(i, tuple):
        break
    co+=1
print(co)

print("program convert a given string list to a tuple")
str1 = "python 3.0"
res = tuple(x for x in str1 if not x.isspace())
print(res)
t = tuple(str1)
print(t)

print("program calculate the product, multiplying all the numbers of a given tuple")
t = (4, 3, 2, 2, -1, 18)
mul = 1
for i in t:
    mul = mul * i
print(mul)

print("program to calculate the average value of the numbers in a given tuple of tuples")
nums = ((10, 10, 10, 12), (30, 45, 56, 45), (81, 80, 39, 32), (1, 2, 3, 4))
result = [sum(x) / len(x) for x in zip(*nums)]
print(result)

print("program to convert a tuple of string values to a tuple of integer values")
tuple_str = (('333', '33'), ('1416', '55'))
result = tuple((int(x[0]), int(x[1])) for x in tuple_str)
print(result)

print("program to convert a given tuple of positive integers into an integer")
t = (1,2,3)
res = int(''.join(map(str,t)))
print(res)

print("program to check if a specified element presents in a tuple of tuples")
t = (('Red', 'White', 'Blue'), ('Green', 'Pink', 'Purple'), ('Orange', 'Yellow', 'Lime'))
c = 'Blue'
result = any(c in tu for tu in t)
print(result)

print("program to compute element-wise sum of given tuples")
x = (1,2,3,4)
y = (3,5,2,1)
z = (2,2,3,1)
res = tuple(map(sum, zip(x, y, z)))
print(res)

print("program to compute the sum of all the elements of each tuple stored inside a list of tuples")
t = [(1, 2), (2, 3), (3, 4)]
res = map(sum,t)
print(list(res))