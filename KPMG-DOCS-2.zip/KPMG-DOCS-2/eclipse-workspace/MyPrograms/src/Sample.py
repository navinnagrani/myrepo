'''
Created on Sep 14, 2021

@author: navinnagrani
'''
print("Navin")
