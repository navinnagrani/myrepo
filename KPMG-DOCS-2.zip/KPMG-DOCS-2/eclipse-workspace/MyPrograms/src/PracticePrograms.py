'''
Created on Mar 26, 2021

@author: navinnagrani
'''
import random
import itertools
from ast import Num
import collections
from itertools import combinations
from itertools import groupby
from operator import itemgetter
from collections import Counter
from random import shuffle
from random import choice
from heapq import merge
import ast
import itertools as it



print("Sum of elements in list")
def sum_list(list1):
    sumNum = 0
    for x in list1:
        sumNum = sumNum + x
    return sumNum

print("Sum of numbers is : ",sum_list([1,2,3,6,7]))

print("Multiplies elements in list")
def mulList(list2):
    mul = 1
    for y in list2:
        mul = mul * y
    return mul
print("Multiply of all numbers in list is : ",mulList([3,1,2,3]))

print("Largest element from list")
def larEleList(list3):
    lar = list3[0]
    for x in list3:
        if x > lar:
            lar = x
    return lar
print(larEleList([1,2,-8,0]))

print("Smallest element from list")
def smallEleList(list3):
    lar = list3[0]
    for x in list3:
        if x < lar:
            lar = x
    return lar
print(smallEleList([1,2,-8,0]))

print("Count number of strings")
def match_words(words):
    ctr = 0
    for word in words:
        if len(word) > 1 and word[0] == word[-1]:
            ctr += 1
    return ctr
print(match_words(['abc', 'xyz', 'aba', '1221']))

print("Remove duplicates from list")
a = [10,20,30,20,10,50,60,40,80,50,40]

dup_items = set()
uniq_items = []
for x in a:
    if x not in dup_items:
        uniq_items.append(x)
        dup_items.add(x)

print(dup_items)

print("Check if list is empty or not")
list6 = [1,3,5]
if not list6:
    print("Empty")
else:
    print("Not empty")
    
print("program to clone or copy a list")
l1 = [1,4,5]
l2 = list(l1)
print(l2)

print("program to find the list of words that are longer than n from a given list of words")
def long_words(n, str):
    word_len = []
    txt = str.split(" ")
    for x in txt:
        if len(x) > n:
            word_len.append(x)
    return word_len    
print(long_words(3, "The quick brown fox jumps over the lazy dog"))

print("Python function that takes two lists and returns True if they have at least one common member")
def commonMem(l1,l2):
    result = False
    for x in l1:
        for y in l2:
            if x==y:
                result=True
                return result
print(commonMem([1,2,3,4,5], [5,6,7,8,9]))
print(commonMem([1,2,3,4,5], [6,7,8,9]))

print("print a specified list after removing the 0th, 4th and 5th elements")
l3 = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']
l3 = [x for (i,x) in enumerate(l3) if i not in (0,4,5)]
print(l3)

print("program to generate a 3*4*6 3D array whose each element is *")
array = [[ ['*' for col in range(6)] for col in range(4)] for row in range(3)]
print(array)

print("program to print the numbers of a specified list after removing even numbers from it")
l4 = [1,2,3,4,5,6,8,10,67,54,99]
l4 = [x for x in l4 if x%2!=0]
print(l4)  

print("program to shuffle and print a specified list")
mylist = ["apple", "banana", "cherry"]
random.shuffle(mylist)
print(mylist)

print("program to generate and print a list of first and last 5 elements where the values are square of numbers between 1 and 30 (both included) ")
def printValues():  
    l = list()
    for i in range(1,31):
        l.append(i**2)
    print(l[:5])
    print(l[-5:])

printValues()

print("program to generate all permutations of a list")
print(list(itertools.permutations([1,2,3])))

print("program to get the difference between the two lists")
list1 = [1,2,5,6,7]
list2 = [1,1,3,5,2]
diff_list1_list2 = list(set(list1) - set(list2))
diff_list2_list1 = list(set(list2) - set(list1))
total_diff = diff_list1_list2 + diff_list2_list1
print(total_diff)

print("program access the index of a list")
nums = [50,3,5,67]
for numIndex , numVal in enumerate(nums):
    print(numIndex,numVal)

print("program to convert a list of characters into a string")
list7 = ['n','a','v','i','n','i','s','g','r','e','a','t']
str1 = ''.join(list7)
print(str1)

print("program to find the index of an item in a specified list")
#takeIn = input("Enter number  to access index: ")
list9 = [20,30,50,90,22]
print(list9.index(22))

print("program to flatten a shallow list")
original_list = [[2,4,3],[1,5,6], [9], [7,9,0]]
new_merged_list = list(itertools.chain(*original_list))
print(new_merged_list)

print("program to append a list to the second list")
l1 = [1,4,6,8,9]
l2 = [90,80,78,99]
l3 = l1+(l2)
print(l3)

print("program to select an item randomly from a list")
color_list = ['Red', 'Blue', 'Green', 'White', 'Black']
print(random.choice(color_list))

print("program to find the second smallest number in a list")
l3 = [10,67,45,23,2,6]
l4 = sorted(l3)
print(l4[1])

print("program to find the second largest number in a list")
l4 = [1,89,56,34,22,66,78]
l5 = sorted(l4, reverse=True)
print(l5)
print(l5[1])

print("program to get unique values from a list")
l5 = [33,56,78,33,45,56,88]
l6 = set(l5)
my_new_list = list(l6)
print(l6)

print("program to get the frequency of the elements in a list")
my_list = [10,10,10,10,20,20,20,20,40,40,50,50,30]
print("Original List : ",my_list)
ctr = collections.Counter(my_list)
print("Frequency of the elements in the List : ",ctr)

print("program to count the number of elements in a list within a specified range")
def count_range_in_list(li, min, max):
    ctr = 0
    for x in li:
        if min <= x <= max:
            ctr += 1
    return ctr

list1 = [10,20,30,40,40,40,70,80,99]
print(count_range_in_list(list1, 40, 100))

list2 = ['a','b','c','d','e','f']
print(count_range_in_list(list2, 'a', 'e'))

print("program to check whether a list contains a sublist")
def is_Sublist(l, s):
    sub_set = False
    if s == []:
        sub_set = True
    elif s == l:
        sub_set = True
    elif len(s) > len(l):
        sub_set = False

    else:
        for i in range(len(l)):
            if l[i] == s[0]:
                n = 1
                while (n < len(s)) and (l[i+n] == s[n]):
                    n += 1
                
                if n == len(s):
                    sub_set = True

    return sub_set

a = [2,4,3,5,7]
b = [4,3]
c = [3,7]
print(is_Sublist(a, b))
print(is_Sublist(a, c))

print("program to generate all sublists of a list")
def sub_lists(my_list):
    subs = []
    for i in range(0, len(my_list)+1):
      temp = [list(x) for x in combinations(my_list, i)]
      if len(temp)>0:
        subs.extend(temp)
    return subs


l1 = [10, 20, 30, 40]
l2 = ['X', 'Y', 'Z']
print("Original list:")
print(l1)
print("S")
print(sub_lists(l1))
print("Sublists of the said list:")
print(sub_lists(l1))
print("\nOriginal list:")
print(l2)
print("Sublists of the said list:")
print(sub_lists(l2))

print("Prime numbers using Sieve of Eratosthenes method")
def prime_eratosthenes(n):
    prime_list = []
    for i in range(2, n+1):
        if i not in prime_list:
            print (i)
            for j in range(i*i, n+1, i):
                prime_list.append(j)

print(prime_eratosthenes(100));

print("program to create a list by concatenating a given list which range goes from 1 to n")
my_list = ['p', 'q']
n = 4
new_list = ['{}{}'.format(x, y) for y in range(1, n+1) for x in my_list]
print(new_list)

print("program to get variable unique identification number or string")
x = 100
print(format(id(x), 'x'))
s = 'w3resource'
print(format(id(s), 'x')) 

print("program to find common items from two lists")
color1 = "Red", "Green", "Orange", "White"
color2 = "Black", "Green", "White", "Pink"
print(set(color1) & set(color2))

print("program to convert a list of multiple integers into a single integer.")
L = [11, 33, 50]
print("Original List: ",L)
x = int("".join(map(str, L)))
print("Single Integer: ",x)

print("program to split a list based on first character of word")
word_list = ['be','have','do','say','get','make','go','know','take','see','come','think',
     'look','want','give','use','find','tell','ask','work','seem','feel','leave','call']

for letter, words in groupby(sorted(word_list), key=itemgetter(0)):
    print(letter)
    for word in words:
        print(word)
        
print("Create multiple lists")
obj = {}
for i in range(1, 21):
    obj[str(i)] = []
print(obj)

print("program to find missing and additional values in two lists")
list1 = ['a','b','c','d','e','f']
list2 = ['d','e','f','g','h']
print('Missing values in second list: ', ','.join(set(list1).difference(list2)))
print('Additional values in second list: ', ','.join(set(list2).difference(list1)))

print("program to split a list into different variables")
color = [("Black", "#000000", "rgb(0, 0, 0)"), ("Red", "#FF0000", "rgb(255, 0, 0)"),
         ("Yellow", "#FFFF00", "rgb(255, 255, 0)")]
var1, var2, var3 = color
print(var1)
print(var2)
print(var3)

print("program to generate groups of five consecutive numbers in a list")
l = [[5*i + j for j in range(1,6)] for i in range(5)]
print(l)

print("program to convert a pair of values into a sorted unique array")
L = [(1, 2), (3, 4), (1, 2), (5, 6), (7, 8), (1, 2), (3, 4), (3, 4),
 (7, 8), (9, 10)]
print("Original List: ", L)
print("Sorted Unique Data:",sorted(set().union(*L)))

print("program to select the odd items of a list")
x = [1, 2, 3, 4, 5, 6, 7, 8, 9]
print(x[::2])

# L[start:stop:step]

print("program to insert an element before each element of a list")
color = ['Red', 'Green', 'Black']
print("Original List: ",color)
color = [v for elt in color for v in ('c', elt)]
print("Original List: ",color)

print("program to print a nested lists (each list on a new line) using the print() function")
l5 = [['Red'],['Green'],['Blue']]
for i in l5:
    print(i)

print('\n'.join([str(lst) for lst in l5]))

print("program to convert list to list of dictionaries")
l6 = ["Black", "Red", "Maroon", "Yellow"]
l7 = ["#000000", "#FF0000", "#800000", "#FFFF00"]
print([{'color_name': f, 'color_code': c} for f, c in zip(l6, l7)])

print("program to sort a list of nested dictionaries")
my_list = [{'key': {'subkey': 1}}, {'key': {'subkey': 10}}, {'key': {'subkey': 5}}]
print("Original List: ")
print(my_list)
my_list.sort(key=lambda e: e['key']['subkey'], reverse=True)
print("Sorted List: ")
print(my_list)

print("program to split a list every Nth element")
l8=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
step = 4
print([l8[i::step] for i in range(step)])

print("program to compute the difference between two lists")
c1 = ["red", "orange", "green", "blue", "white"]
c2 = ["black", "yellow", "green", "blue"]
print(set(c1).difference(set(c2)))
print(set(c2).difference(set(c1)))

print("OR")
counter1 = Counter(c1)
counter2 = Counter(c2)
print("Color1-Color2: ",list(counter1 - counter2))
print("Color2-Color1: ",list(counter2 - counter1))

print("program to create a list with infinite elements")
c = itertools.count()
print(next(c))
print(next(c))
print(next(c))
print(next(c))
print(next(c))

print("program to concatenate elements of a list")
color = ['red', 'green', 'orange']
print(''.join(color))

print("program to remove key values pairs from a list of dictionaries")
original_list = [{'key1':'value1', 'key2':'value2'}, {'key1':'value3', 'key2':'value4'}]
print("Original List: ")
print(original_list)
new_list = [{k:v for k,v in d.items() if k != 'key1'} for d in original_list]
print(new_list)

print("program to convert a string to a list")
strk = "My name is Navin"
l9 = list(strk)
print(l9)
color ="['Red', 'Green', 'White']"
print(ast.literal_eval(color))

print("program to check whether all items of a list is equal to a given string")
color1 = ["green", "orange", "black", "white"]
color2 = ["green", "green", "green", "green"]

print(all(c == 'blue' for c in color1))
print(all(c == 'green' for c in color2))

print("program to replace the last element in a list with another list")
num1 = [1, 3, 5, 7, 9, 10]
num2 = [2, 4, 6, 8]
num1[-1:] = num2
print(num1)

print("program to check whether the n-th element exists in a given list")
x = [1, 2, 3, 4, 5, 6]
n = 5
check = len(x) >= n
print(check)

print("program to find a tuple, the smallest second index value from a list of tuples")
x = [(4, 1), (1, 2), (6, 0)]
print(min(x, key=lambda n:(n[1],-n[0])))

print("program to create a list of empty dictionaries")
ch = [{} for i in range(1,6)]
print(ch)

print("program to print a list of space-separated elements")
num = [1, 2, 3, 4, 5]
print(*num)

print("program to insert a given string at the beginning of all items in a list")
mk=[1,2,3,4]
print(['emp{0}'.format(i) for i in  mk])

print("program to iterate over two lists simultaneously")
num = [1, 2, 3]
color = ['red', 'white', 'black']
for (a,b) in zip(num, color):
     print(a, b)

print("program to move all zero digits to end of a given list of numbers")
def test(lst):
    result = sorted(lst, key=lambda x: not x) 
    return result
nums = [3,4,0,0,0,6,2,0,6,7,6,0,0,0,9,10,7,4,4,5,3,0,0,2,9,7,1]
print("\nOriginal list:")
print(nums)
print("\nMove all zero digits to end of the said list of numbers:")
print(test(nums)) 

print("program to find the list in a list of lists whose sum of elements is the highest.")
num = [[1,2,3], [4,5,6], [10,11,12], [7,8,9]]
print(max(num, key=sum))

print("program to find all the values in a list are greater than a specified number")
list1 = [220, 330, 500]
list2 = [12, 17, 21]
print(all(x >= 200 for x in list1))
print(all(x >= 25 for x in list2))

print("program to extend a list without append")
l1 = [10, 20, 30]
l2 = [40, 50, 60]
l1.extend(l2)
print(l1)

print("OR")
x = [10, 20, 30]
y = [40, 50, 60]
x[:0] =y
print(x)


print("program to remove duplicates from a list of lists")

num = [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]]
print("Original List", num)
num.sort()
new_num = list(num for num,_ in itertools.groupby(num))
print("New List", new_num)

print("program to get the depth of a dictionary")
def test3(lst, char):
    result = [i for i in lst if i.startswith(char)]
    return result
text = ["abcd", "abc", "bcd", "bkie", "cder", "cdsw", "sdfsd", "dagfa", "acjd"]
print("\nOriginal list:")
print(text)
char = "a"
print("\nItems start with",char,"from the said list:")
print(test3(text, char))
char = "d"
print("\nItems start with",char,"from the said list:")
print(test3(text, char))
char = "w"
print("\nItems start with",char,"from the said list:")
print(test3(text, char))

print("program to check whether all dictionaries in a list are empty or not")
def checkDic(lis):
    for i in lis:
        if not i:
            return True

myLis = [{},{},{}]
print(checkDic(myLis))

print("OR")
my_list = [{},{},{}]
my_list1 = [{1,2},{},{}]
print(all(not d for d in my_list))
print(all(not d for d in my_list1))

print("program to flatten a given nested list structure")
def flatten_list(_2d_list):
    flat_list = []
    # Iterate through the outer list
    for element in _2d_list:
        if type(element) is list:
            # If the element is of type list, iterate through the sublist
            for item in element:
                flat_list.append(item)
        else:
            flat_list.append(element)
    return flat_list
vk = [0, 10, [20, 30], 40, 50, [60, 70, 80], [90, 100, 110, 120]]
print('Original List', vk)
print('Transformed Flat List', flatten_list(vk))

print("program to remove consecutive duplicates of a given list")
kk = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]
print("Ori List")
print(kk)
jj = list(set(kk))
print(jj)

print("program to pack consecutive duplicates of a given list elements into sublists")
def pack_consecutive_duplicates(l_nums):
    return [list(group) for key, group in groupby(l_nums)]
n_list = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4 ]
print("Original list:") 
print(n_list)
print("\nAfter packing consecutive duplicates of the said list elements into sublists:")
print(pack_consecutive_duplicates(n_list)) 

print("program to create a list reflecting the run-length encoding from a given list of integers or a given list of characters")
def encode_list(s_list):
    return [[len(list(group)), key] for key, group in groupby(s_list)]
n_list = [1,1,2,3,4,4.3,5, 1]
print("Original list:") 
print(n_list)
print("\nList reflecting the run-length encoding from the said list:")
print(encode_list(n_list))
n_list = 'automatically'
print("\nOriginal String:") 
print(n_list)
print("\nList reflecting the run-length encoding from the said string:")
print(encode_list(n_list))


print("program to split a given list into two parts where the length of the first part of the list is given")
def split_two_parts(n_list, L):
    return n_list[:L], n_list[L:]
n_list = [1,1,2,3,4,4,5, 1]
print("Original list:") 
print(n_list)
first_list_length = 4  #int(input("Enter first length : "))
print("\nLength of the first part of the list:",first_list_length)
print("\nSplited the said list into two parts:")
print(split_two_parts(n_list, first_list_length))

print("program to remove the K'th element from a given list, print the new list")
lo = [1, 1, 2, 3, 4, 4, 5, 1]
mo = 5 #int(input("Enter position of element to remove : "))
ko = lo[:mo-1] + lo[mo:]
print(ko)

print("program to insert an element at a specified position into a given list")
n_list = [1, 1, 2, 3, 4, 4, 5, 1]
pos = 3
x = 12
hu = n_list[:pos-1]+[x]+n_list[pos-1:]
print(hu)

print("program to extract a given number of randomly selected elements from a given list")
n_list = [1,1,2,3,4,4,5,1]
print(random.sample(n_list,3))

print("program to round every number of a given list of numbers and print the total sum multiplied by the length of the list")
po = [22.4, 4.0, -16.22, -9.1, 11.0, -12.22, 14.2, -5.2, 17.5]
newl = []
ww = 0
for i in po:
    newl.append(round(i))
print(newl)
print(sum(newl)* len(newl))

print("program to round the numbers of a given list, print the minimum and maximum numbers and multiply the numbers by 5. Print the unique numbers in ascending order separated by space")
nums = [22.4, 4.0, 16.22, 9.10, 11.00, 12.22, 14.20, 5.20, 17.50]
print("Original list:", nums)
numbers=list(map(round,nums))
print("Minimum value: ",min(numbers))
print("Maximum value: ",max(numbers))
numbers=list(set(numbers))
numbers=(sorted(map(lambda n:n*5,numbers)))
print("Result:")
for numb in numbers:
    print(numb,end=' ')

print("Python program to create a multidimensional list (lists of lists) with zeros")
nums = []
for i in range(3):
    nums.append([])
    for j in range(2):
        nums[i].append(0)
print("Multidimensional list:")
print(nums)

print("program to create a 3X3 grid with numbers")
nums = []
for i in range(3):
    nums.append([])
    for j in range(1,4):
        nums[i].append(j)
print(nums)

# print(" program to read a matrix from console and print the sum for each column. Accept matrix rows, columns and elements for each column separated with a space(for every row) as input from the user")
# rows = 2
# columns = 2
# matrix = [[0]*columns for row in range(rows)]
# print(matrix)
# print('Input number of elements in a row (1, 2, 3): ')
# for row in range(rows):
#     lines = list(map(int, input().split()))
#     for column in range(columns):
#         matrix[row][column] = lines[column]
# 
# sum = [0]*columns
# print("sum for each column:")
# for column in range(columns):
#     for row in range(rows):
#         sum[column] += matrix[row][column]
#     print((sum[column]), ' ', end = '')
    
# print("\nPython program to read a square matrix from console and print the sum of matrix primary diagonal")
# size = int(input("Input the size of the matrix: "))
# matrix=[[0] * size for row in range(0,size)]
# for x in range(0,size):
#     line = list(map(int, input().split()))
#     for y in range(0, size):
#         matrix[x][y] = line[y]
# mat_sum_dia = sum(matrix[size-i-1][size-i-1] for i in range(size))
# print(mat_sum_dia)

print("program to Zip two given lists of lists")
mj = [[1, 3], [5, 7], [9, 11]]
fg = [[2, 4], [6, 8], [10, 12, 14]]
result = list(map(list.__add__, mj, fg)) 
print("\nZipped list:\n" +  str(result))

print("program to count number of lists in a given list of lists")
list1 = [[1, 3], [5, 7], [9, 11], [13, 15, 17]]
print(len(list1))

print("program to find the list with maximum and minimum length")
def max_length_list(input_list):
    max_length = max(len(x) for x in input_list )
    max_list = max(input_list, key = len)
    return(max_length, max_list)
def min_length_list(input_list):
    min_length = min(len(x) for x in input_list )
    min_list = min(input_list, key = len)
    return(min_length, min_list)

list1 = [[0], [1, 3], [5, 7], [9, 11], [13, 15, 17]]
print("Original list:")
print(list1)
print("\nList with maximum length of lists:")
print(max_length_list(list1))
print("\nList with minimum length of lists:")
print(min_length_list(list1))

print("program to check if a nested list is a subset of another nested list")
def checkSubset(input_list1, input_list2): 
    return all(map(input_list1.__contains__, input_list2)) 
      

list1 = [[1, 3], [5, 7], [9, 11], [13, 15, 17]] 
list2 = [[1, 3],[13,15,17]]   
print("Original list:")
print(list1)
print(list2)
print("\nIf the one of the said list is a subset of another.:")
print(checkSubset(list1, list2))

print("program to count the number of sublists contain a particular element")
def count_element_in_list(input_list, x): 
    ctr = 0
    for i in range(len(input_list)): 
        if x in input_list[i]: 
            ctr+= 1
          
    return ctr
      

list1 = [[1, 3], [5, 7], [1, 11], [1, 15, 7]] 
print("Original list:")
print(list1)
print("\nCount 1 in the said list:")
print(count_element_in_list(list1, 1))

print(" program to count number of unique sublists within a given list")
def unique_sublists(input_list):
    result ={}
    for l in input_list: 
        result.setdefault(tuple(l), list()).append(1) 
    for a, b in result.items(): 
        result[a] = sum(b)
    return result

list1 = [[1, 3], [5, 7], [1, 3], [13, 15, 17], [5, 7], [9, 11]] 
print("Original list:")
print(list1)  
print("Number of unique lists of the said list:")
print(unique_sublists(list1)) 

print("program to sort each sublist of strings in a given list of lists")
def sort_sublists(input_list):
    result = list(map(sorted, input_list)) 
    return result
color1 = [["orange", "green"], ["black", "white"], ["white", "black", "orange"]]
print("\nOriginal list:")
print(color1)  
print("\nAfter sorting each sublist of the said list of lists:")
print(sort_sublists(color1))

print("program to sort a given list of lists by length and value")
def sort_sublists1(input_list):
    input_list.sort()  # sort by sublist contents
    input_list.sort(key=len)
    return input_list

list1 = [[2], [0], [1, 3], [0, 7], [9, 11], [13, 15, 17]]
print("Original list:")
print(list1)
print("\nSort the list of lists by length and value:")
print(sort_sublists1(list1))

print(" program to remove sublists from a given list of lists, which contains an element outside a given range")
#Source bit.ly/33MAeHe
def remove_list_range(input_list, left_range, rigth_range):
   result = [i for i in input_list if (min(i)>=left_range and max(i)<=rigth_range)]
   return result
list1 = [[2], [0], [1, 2, 3], [0, 1, 2, 3, 6, 7], [9, 11], [13, 14, 15, 17]]
left_range = 13
rigth_range = 17
print("Original list:")
print(list1)
print("\nAfter removing sublists from a given list of lists, which contains an element outside the given range:")
print(remove_list_range(list1, left_range, rigth_range))

print("program to scramble the letters of string in a given list")


def shuffle_word(text_list):
    text_list = list(text_list)
    shuffle(text_list)
    return ''.join(text_list)

text_list = ['Python', 'list', 'exercises', 'practice', 'solution'] 
print("Original list:")
print(text_list)
print("\nAfter scrambling the letters of the strings of the said list:")
result =  [shuffle_word(word) for word in text_list]
print(result) 


print("program to find the maximum and minimum values in a given heterogeneous list")
def max_min_val(list_val):
     max_val = max(i for i in list_val if isinstance(i, int)) 
     min_val = min(i for i in list_val if isinstance(i, int))
     return(max_val, min_val)

list_val = ['Python', 3, 2, 4, 5, 'version'] 
print("Original list:")
print(list_val)
print("\nMaximum and Minimum values in the said list:")
print(max_min_val(list_val))

print("Python program to extract common index elements from more than one given list")
def extract_index_ele(l1, l2, l3):
    result = []
    for m, n, o in zip(l1, l2, l3):
        if (m == n == o):
            result.append(m)
    return result

nums1 = [1, 1, 3, 4, 5, 6, 7]
nums2 = [0, 1, 2, 3, 4, 5, 7]
nums3 = [0, 1, 2, 3, 4, 5, 7]

print("Original lists:")
print(nums1)
print(nums2)
print(nums3)
print("\nCommon index elements of the said lists:") 
print(extract_index_ele(nums1, nums2, nums3))


print("program to sort a given matrix in ascending order according to the sum of its rows")
jh = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
result = sorted(jh, key=sum)
print(result)
      
print("program to extract specified size of strings from a give list of string values")
hy = ['Python', 'list', 'exercises', 'practice', 'solution']
no = 8
myres = []
for ele in hy:
    if len(ele) == no:
        myres.append(ele)
print(myres)
print("OR")
myres = [e for e in hy if len(e) == no]
print("2nd sol ",myres)

print("program to extract specified number of elements from a given list, which follows each other continuously")
og_lis = [1, 1, 3, 4, 4, 5, 6, 7]
ll = 2
lk =[i for i, j in groupby(og_lis) if len(list(j)) ==ll] 
print(lk)

print("program to find the difference between consecutive numbers in a given list")
lg = [1, 1, 3, 4, 4, 5, 6, 7]
diff = [b-a for a, b in zip(lg[:-1], lg[1:])]
print(diff)

print("program to compute average of two given lists")
l1 = [1, 1, 3, 4, 4, 5, 6, 7]
l2 = [0, 1, 2, 3, 4, 4, 5, 7, 8]
result = sum(l1 + l2) / len(l1 + l2) 
print(result)
    
print("program to count integer in a given mixed list")
kg = [1, 'abcd', 3, 1.2, 4, 'xyz', 5, 'pqr', 7, -5, -12.22]
rs = len(list(i for i in kg if isinstance(i, int)))
print(rs)

print("program to remove a specified column from a given nested list")
ij = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
for row in ij:
    del row[0]
print(ij)

print("program to extract a specified column from a given nested list")
gf = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
fd = [i.pop(1) for i in gf]
print(fd)
   
print(" program to rotate a given list by specified number of items to the right or left direction")
vc = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("\nRotate the said list in left direction by 4:")
result = vc[3:] + vc[:4]
print(result)

print("program to find the item with maximum occurrences in a given list")
de = [2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
max_val = 0
result = de[0] 
for i in de:
    occu = de.count(i)
    if occu > max_val:
        max_val = occu
        result = i
        
print(result)

print("program to access multiple elements of specified index from a given list")
jh = [2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
il = [0, 3, 5, 7, 10]
result = [jh[i] for i in il]
print(result)

print("program to check whether a specified list is sorted or not")
hg = [1,2,4,6,8,10,12,14,16,17]
result = all(hg[i] <= hg[i+1] for i in range(len(hg)-1))
print(result)

print("program to remove duplicate dictionary from a given list")
fw = [{'Green': '#008000'}, {'Black': '#000000'}, {'Blue': '#0000FF'}, {'Green': '#008000'}]
result = [dict(e) for e in {tuple(d.items()) for d in fw}]
print(result)

print("program to extract the nth element from a given list of tuples")
nd = [('Greyson Fulton', 98, 99), ('Brady Kent', 97, 96), ('Wyatt Knott', 91, 94), ('Beau Turnbull', 94, 98)]
n = 2
result = [x[n] for x in nd]
print(result)

print("program to check if the elements of a given list are unique or not")
ogl = [2, 4, 6, 8, 10, 12, 14]
flag = len(set(ogl)) == len(ogl)
if flag:
    print("Unique")
else:
    print("Not Unique")

print("program to sort a list of lists by a given index of the inner list")
ogl =[('Greyson Fulton', 98, 99), ('Brady Kent', 97, 96), ('Wyatt Knott', 91, 94), ('Beau Turnbull', 94, 98)]
result = sorted(ogl, key=itemgetter(0))
print(result)

print("program to remove all elements from a given list present in another list")
list1 = [1,2,3,4,5,6,7,8,9,10]
list2 = [2,4,6,8]
result = [x for x in list1 if x not in list2]
print(result)

print("program to find the difference between elements (n+1th - nth) of a given list of numeric values")
ogl = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
result = [j-i for i, j in zip(ogl[:-1], ogl[1:])]
print(result)

print("program to check if a substring presents in a given list of string values")
ogl = ['red', 'black', 'white', 'green', 'orange']
subcheck = "ack"
ch = False
if any(subcheck in s for s in ogl):
       ch =  True
else:
   ch =  False
print(ch)

print("program to create a list taking alternate elements from a given list")
ogl = ["red", "black", "white", "green", "orange"]
result = [it for it in ogl[::2]]
print(result)

print("program to find the nested lists elements which are present in another list")
nums1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
nums2 = [[12, 18, 23, 25, 45], [7, 11, 19, 24, 28], [1, 5, 8, 18, 15, 16]]
result = [[n for n in lst if n in nums1] for lst in nums2]
print(result)

print("program to find common element(s) in a given nested lists")
ogl = [[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]]
result = list(set.intersection(*map(set, ogl)))
print(result)

print("program to reverse strings in a given list of string values")
ogl =['Red', 'Green', 'Blue', 'White', 'Black']
res = [i[::-1] for i in ogl]
print(res)

print("program to find the maximum and minimum product from the pairs of tuple within a given list.")
ogl = [(2, 7), (2, 6), (1, 8), (4, 9)]
result_max = max([abs(x * y) for x, y in ogl] )
result_min = min([abs(x * y) for x, y in ogl] )
print(result_max,result_min)

print(" program to calculate the product of the unique numbers of a given list")
ogl = [10, 20, 30, 40, 20, 50, 60, 40]
l2 = list(set(ogl))
p = 1
for i in l2:
        p *= i    
print(p)

print("program to interleave multiple lists of the same length")
list1 = [1,2,3,4,5,6,7]
list2 = [10,20,30,40,50,60,70]
list3 = [100,200,300,400,500,600,700]
result = [el for pair in zip(list1, list2, list3) for el in pair]
print(result)

print("program to remove words from a given list of strings containing a character or string")
ogl = ['Red color', 'Orange#', 'Green', 'Orange @', 'White']
rel = ['#', 'color', '@']
new_list = []
for line in ogl:
    new_words = ' '.join([word for word in line.split() if not any([phrase in word for phrase in rel])])
    new_list.append(new_words)
print(new_list)

print("program to calculate the sum of the numbers in a list between the indices of a specified range")
ogl = [2, 1, 5, 6, 8, 3, 4, 9, 10, 11, 8, 12]
jum = 0
m = 8
n = 10
for i in range(m,n+1,1):
    jum+=ogl[i]
    
print(jum)

print("program to reverse each list in a given list of lists")
ogl = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]
for l in ogl:
    l.sort(reverse = True)
print(ogl)

print("program to count the same pair in three given lists")
nums1 = [1,2,3,4,5,6,7,8]
nums2 = [2,2,3,1,2,6,7,9]
nums3 = [2,1,3,1,2,6,7,9]
result = sum(m == n == o for m, n, o in zip(nums1, nums2, nums3))
print(result)

print("program to count the frequency of consecutive duplicate elements in a given list of numbers")
def count_dups(nums):
    element = []
    freque = []
    if not nums:
        return element
    running_count = 1
    for i in range(len(nums)-1):
        if nums[i] == nums[i+1]:
            running_count += 1
        else:
            freque.append(running_count)
            element.append(nums[i])
            running_count = 1
    freque.append(running_count)
    element.append(nums[i+1])
    return element,freque


nums = [1,2,2,2,4,4,4,5,5,5,5]
print("Original lists:")
print(nums)

print("\nConsecutive duplicate elements and their frequency:")
print(count_dups(nums))

print("program to find all index positions of the maximum and minimum values in a given list of numbers")
ogl = [12, 33, 23, 10, 67, 89, 45, 667, 23, 12, 11, 10, 54]
i1 = max(ogl)
i2 = min(ogl)
max_result = [i for i, j in enumerate(ogl) if j == i1]
min_result = [i for i, j in enumerate(ogl) if j == i2]
print(max_result,min_result)

print("program to check common elements between two given list are in same order or not")
l1 = ['red', 'green', 'black', 'orange']
l2 = ['red', 'pink', 'green', 'white', 'black']
l3 = ['white', 'orange', 'pink', 'black']

common_elements = set(l1) & set(l2)
lis1 = [e for e in l1 if e in common_elements]
lis2 = [e for e in l2 if e in common_elements]
if lis1 == lis2:
    print("Common")
else:
    print("Uncommon")

print("program to find the difference between two list including duplicate elements")
l1 = [1, 1, 2, 3, 3, 4, 4, 5, 6, 7]
l2 = [1, 1, 2, 4, 5, 6]
result = list(l1)
for el in l2:
    result.remove(el)
print(result)

print("program to iterate over all pairs of consecutive items in a given list")
ogl = [1,1,2,3,3,4,4,5]
temp = []
for i in range(len(ogl) - 1):
    current_element, next_element = ogl[i], ogl[i + 1]
    x = (current_element, next_element)
    temp.append(x)
print(temp)

print("program to remove duplicate words from a given list of strings")
ogl = ['Python', 'Exercises', 'Practice', 'Solution', 'Exercises']
res = list(set(ogl))
print(res)

print("program to find a first even and odd number in a given list of numbers")
ogl = [1, 3, 5, 7, 4, 1, 6, 8]
first_even = next((el for el in ogl if el%2==0),-1)
first_odd = next((el for el in ogl if el%2!=0),-1)
print(first_even,first_odd)

print("program to sort a given mixed list of integers and strings. Numbers must be sorted before strings")
ogl = [19, 'red', 12, 'green', 'blue', 10, 'white', 'green', 1]
intl = sorted([e for e in ogl if type(e) is int])
strl = sorted([e for e in ogl if type(e) is str])
print(intl+strl)

print("program to sort a given list of strings(numbers) numerically")
ogl = ['4', '12', '45', '7', '0', '100', '200', '-12', '-500']
res = [int(x) for x in ogl]
res.sort()
print(res)

print("program to remove the specific item from a given list of lists")
ogl = [['Red', 'Maroon', 'Yellow', 'Olive'], ['#FF0000', '#800000', '#FFFF00', '#808000'], ['rgb(255,0,0)', 'rgb(128,0,0)', 'rgb(255,255,0)', 'rgb(128,128,0)']]
for x in ogl:
    del x[1]
print(ogl)

print("program to remove empty lists from a given list of lists")
ogl = [[], [], [], 'Red', 'Green', [1,2], 'Blue', [], []]
list2 = [x for x in ogl if x]
print(list2)

print("program to sum a specific column of a list in a given list of lists")
ogl = [[1, 2, 3, 2], [4, 5, 6, 2], [7, 8, 9, 5]]
n=1
result = sum(row[n] for row in ogl)
print(result)

print("program to get the frequency of the elements in a given list of lists")
ogl = [[1, 2, 3, 2], [4, 5, 6, 2], [7, 8, 9, 5]]
nums = [item for sublist in ogl for item in sublist]

dic_data = {}
for num in nums:
    if num in dic_data.keys():
        dic_data[num] += 1
    else:
        key = num
        value = 1
        dic_data[key] = value
print(dic_data)   

print("program to extract every first or specified element from a given two-dimensional list")
ogl = [[1, 2, 3, 2], [4, 5, 6, 2], [7, 1, 9, 5]]
res = [x[1] for x in ogl]
print(res)  

print("program to generate a number in a specified range except some specific numbers")
numr = [2, 9, 10]
result = choice([i for i in range(1,10) if i not in numr])
print(result)

print("program to compute the sum of digits of each number of a given list")
ogl = [10,2,56]
res = sum(int(el) for n in nums for el in str(n) if el.isdigit())
print(res)

print("program to interleave two given list into another list randomly")
ogl = [1, 2, 7, 8, 3, 7]
lkj = [4, 3, 8, 9, 4, 3, 8, 9]
result =  [x.pop(0) for x in random.sample([ogl]*len(ogl) + [lkj]*len(lkj), len(ogl)+len(lkj))]
print(result)

print("program to remove specific words from a given list")
ogl = ['red', 'green', 'blue', 'white', 'black', 'orange']
rml = ['white', 'orange']
res = [x for x in ogl if x not in rml]
print(res)

print("program to reverse a given list of lists")
ogl = [['orange', 'red'], ['green', 'blue'], ['white', 'black', 'pink']]
res = ogl[::-1]
print(res)

print("program to find the maximum and minimum values in a given list within specified index range")
ogl = [4,3,0,5,3,0,2,3,4,2,4,3,5]
lr = 3
hr = 8
temp = []
for idx, el in enumerate(ogl):
    if idx >= lr and idx < hr:
        temp.append(el)
result_max = max(temp) 
result_min = min(temp)
print(result_max,result_min)

print("program to combine two given sorted lists using heapq module")
nums1 = [1, 3, 5, 7, 9, 11]
nums2 = [0, 2, 4, 6, 8, 10]
print(list(merge(nums1,nums2)))

print("program to check if a given element occurs at least n times in a list")
ogl = [0, 1, 3, 5, 0, 3, 4, 5, 0, 8, 0, 3, 6, 0, 3, 1, 1, 0]
x = 3
n = 4
t = 0
ch = False
try:
    for _ in range(n):
        t = ogl.index(x, t) + 1
        ch=True
except ValueError:
        ch=False
print(ch)

print("program to join two given list of lists of same length, element wise")
ogl1 = [[10, 20], [30, 40], [50, 60], [30, 20, 80]]
ogl2 = [[61], [12, 14, 15], [12, 13, 19, 20], [12]]
result = [x + y for x, y in zip(ogl1, ogl2)]
print(result)

print(" program to add two given lists of different lengths, start from left")
l1 = [2, 4, 7, 0, 5, 8]
l2 = [3, 3, -1, 7]
f_len = len(l1)-(len(l2) - 1)
for i in range(0, len(l2), 1):
    if f_len - i >= len(l1):
        break
    else:
        l1[i] = l1[i] + l2[i]

print(l1)

print("program to add two given lists of different lengths, start from right")
l1 = [2, 4, 7, 0, 5, 8]
l2 = [3, 3, -1, 7]
f_len = len(l1)-(len(l2) - 1)
for i in range(len(l1), 0, -1):
    if i-f_len < 0:
        break
    else:
        l1[i-1] = l1[i-1] + l2[i-f_len]
print(l1)

print("program to interleave multiple given lists of different lengths")
def interleave_diff_len_lists(list1, list2, list3, list4):
    result = []
    l1 = len(list1)
    l2 = len(list2)
    l3 = len(list3)
    l4 = len(list4)
    
    for i in range(max(l1, l2, l3, l4)):
        if i < l1:
            result.append(list1[i])
        if i < l2:
            result.append(list2[i])
        if i < l3:
            result.append(list3[i])
        if i < l4:
            result.append(list4[i])
    return result

nums1 = [2, 4, 7, 0, 5, 8]
nums2 = [2, 5, 8]
nums3 = [0, 1]
nums4 = [3, 3, -1, 7]

print("\nOriginal lists:")
print(nums1)
print(nums2)
print(nums3)
print(nums4)

print("\nInterleave said lists of different lengths:")
print(interleave_diff_len_lists(nums1, nums2, nums3, nums4))

print(" program to find the maximum and minimum values in a given list of tuples")
class_students = [('V', 60), ('VI', 70), ('VII', 75), ('VIII', 72), ('IX', 78), ('X', 70)]
return_max = max(class_students,key=itemgetter(1))[1] 
return_min = min(class_students,key=itemgetter(1))[1]
print(return_max,return_min)

print("program to append the same value /a list multiple times to a list/list-of-lists")
nums = []
nums+=5 *[7]
print(nums)

print("program to remove first specified number of elements from a given list satisfying a condition")
def condition_match(x):
    return ((x % 2) == 0)
def remove_items_con(data, N):
    ctr = 1
    result = []
    for x in data:
        if ctr > N or not condition_match(x):
            result.append(x)
        else:
            ctr = ctr + 1
    return result
nums = [3,10,4,7,5,7,8,3,3,4,5,9,3,4,9,8,5]
N = 4
print("Original list:")
print(nums)
print("\nRemove first 4 even numbers from the said list:")
print(remove_items_con(nums, N))

print(" program to find the last occurrence of a specified item in a given list")
ogl = ['s', 'd', 'f', 's', 'd', 'f', 's', 'f', 'k', 'o', 'p', 'i', 'w', 'e', 'k', 'c']
res = ''.join(ogl).rindex('f')
print(res)

print("program to get the index of the first element which is greater than a specified element")
ogl = [12, 45, 23, 67, 78, 90, 100, 76, 38, 62, 73, 29, 83]
el = 73
res = next(a[0] for a in enumerate(ogl) if a[1] > el)
print(res)

print("program to get the items from a given list with specific condition")
ogl = [12, 45, 23, 67, 78, 90, 45, 32, 100, 76, 38, 62, 73, 29, 83]
res = sum(1 for i in ogl if (i> 45 and i % 2 == 0))
print(res)

print("program to split a given list into specified sized chunks")
ogl = [12, 45, 23, 67, 78, 90, 45, 32, 100, 76, 38, 62, 73, 29, 83]
n = 3
res=list((ogl[i:i+n] for i in range(0, len(ogl), n)))
print(res)

print("program to remove None value from a given list")
ogl = [12, 0, None, 23, None, -55, 234, 89, None, 0, 6, -12]
res = [i for i in ogl if i]
print(res)

print("program to convert a given list of strings into list of lists")
ogl = ['Red', 'Maroon', 'Yellow', 'Olive']
res = []
for i in ogl:
    res.append(list(str(i)))
print(res)

print("program to display vertically each element of a given list, list of lists")
ogl = ['a', 'b', 'c', 'd', 'e', 'f']
for i in ogl:
    print(i)

print("program to convert a given list of strings and characters to a single list of characters")
ogl = ['red', 'white', 'a', 'b', 'black', 'f']
result = [i for element in ogl for i in element]
print(result)

print(" program to insert an element in a given list after every nth position")
lst = [1,2,3,4,5,6,7,8,9,0]
ele = 'a'
n = 2

result = []
for st_idx in range(0, len(lst), n):
    result.extend(lst[st_idx:st_idx+n])
    result.append(ele)
    result.pop()
print(result)

print("program to concatenate element-wise three given lists")
l1 = ['0', '1', '2', '3', '4']
l2 = ['red', 'green', 'black', 'blue', 'white']
l3 = ['100', '200', '300', '400', '500']
res = [m+n+o for m, n, o in zip(l1, l2, l3)]
print(res)

print("program to remove the last N number of elements from a given list")
nums = [2,3,9,8,2,0,39,84,2,2,34,2,34,5,3,5]
result = nums[:len(nums)-3]
print(result)

print("program to merge some list items in given list using index value")
ogl = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
m1 = 2
m2 = 4
res = ogl
res[m1:m2] = [''.join(res[m1:m2])]
print(res)

print("program to add a number to each element in a given list of numbers")
ogl = [3, 8, 9, 4, 5, 0, 5, 0, 3]
res = [i+3 for i in ogl]
print(res)

print("program to find the minimum, maximum value for each tuple position in a given list of tuples")
ogl = [(2, 3), (2, 4), (0, 6), (7, 1)]
r1 = max(ogl)
r2 = min(ogl)
print(r1,r2)

print("program to create a new list dividing two given lists of numbers")
l1 = [7, 2, 3, 4, 9, 2, 3]
l2 = [9,8,2,3,3,1,2]
res = [i/j for i,j in zip(l1,l2)]
print(res)

print("program to find common elements in a given list of lists")
ogl = [[7, 2, 3, 4, 7], [9, 2, 3, 2, 5], [8, 2, 3, 4, 4]]
res = set(ogl[0]).intersection(*ogl)
print(res)

print("program to insert a specified element in a given list after every nth element")

nums = [1, 3, 5, 7, 9, 11,0, 2, 4, 6, 8, 10,8,9,0,4,3,0]
x = 20
n = 4
i = n
while i < len(nums):
    nums.insert(i, x)
    i+= n+1
print(nums)

print("program to create the largest possible number using the elements of a given list of positive integers")
lst = [3, 40, 41, 43, 74, 9]
result = ''.join(sorted((str(val) for val in lst), reverse=True,
                      key=lambda i: i*( len(str(max(lst))) * 2 // len(i))))
print(result)

print("program to iterate a given list cyclically on specific index position")
ogl = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
result = []
length = len(ogl)
si = 3
for i in range(length):
    element_index = si % length
    result.append(ogl[element_index])
    si += 1
print(result)

print("program to calculate the maximum and minimum sum of a sublist in a given list of lists")
ogl = [[1, 2, 3, 5], [2, 3, 5, 4], [0, 5, 4, 1], [3, 7, 2, 1], [1, 2, 1, 2]]
ma = max(ogl , key=sum)
mi =min(ogl , key=sum)
print(ma,mi)

print("program to get the unique values in a given list of lists")
ogl = [[1, 2, 3, 5], [2, 3, 5, 4], [0, 5, 4, 1], [3, 7, 2, 1], [1, 2, 1, 2]]
result = set(x for l in ogl for x in l)
print(result)

print("program to form Bigrams of words in a given list of strings")
ogl = ['Sum all the items in a list', 'Find the second smallest number in a list']
result = [a for ls in ogl for a in zip(ls.split(" ")[:-1], ls.split(" ")[1:])]
print(result)

print("program to convert a given decimal number to binary list")
ogn = 8
result = [int(x) for x in list('{0:0b}'.format(ogn))]
print(result)

print("program to swap two sublists in a given list")
nums = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
nums[6:10], nums[1:3] = nums[1:3], nums[6:10]
print(nums)

print("program to convert a given list of tuples to a list of strings")
ogl = [('red', 'green'), ('black', 'white'), ('orange', 'pink')]
result = [("%s "*len(el)%el).strip() for el in ogl]
print(result)

print("program to sort a given list of tuples on specified element")
ogl = [('item2', 10, 10.12), ('item3', 15, 25.1), ('item1', 11, 24.5), ('item4', 12, 22.5)]
so = 1
result = sorted((ogl), key=lambda x: x[so])
print(result)

print("program to shift last element to first position and first element to last position in a given list")
lst = [1, 2, 3, 4, 5, 6, 7]
x = lst.pop(0)
y = lst.pop()
lst.insert(0, y)
lst.insert(len(lst), x)
print(lst)

print("program to find the specified number of largest products from two given list, multiplying an element from each list")
nums1 = [1, 2, 3, 4, 5, 6]
nums2 = [3, 6, 8, 9, 10, 6]
result = sorted([x*y for x in nums1 for y in nums2], reverse=True)[:3]
print(result)

print("program to find the maximum and minimum value of the three given lists")
nums1 = [2,3,5,8,7,2,3]
nums2 = [4,3,9,0,4,3,9]
nums3 = [2,1,5,6,5,5,4]
print(max(nums1+nums2+nums3))
print(min(nums1+nums2+nums3))

print("program to remove all strings from a given list of tuples")
ogl = [(100, 'Math'), (80, 'Math'), (90, 'Math'), (88, 'Science', 89), (90, 'Science', 92)]
result =   [tuple(v for v in i if not isinstance(v, str)) for i in ogl]
print(result)

print("program to find the dimension of a given matrix")
ogl = [[1, 2], [2, 4]]
row = len(ogl)
column = len(ogl[0])
print(row,column)

print("program to sum two or more lists, the lengths of the lists may be different")
ogl = [[1, 2, 4], [2, 4, 4], [1, 2]]
result =  [sum(x) for x in zip(*map(lambda x:x+[0]*max(map(len, ogl)) if len(x)<max(map(len, ogl)) else x, ogl))]
print(result)

print("program to traverse a given list in reverse order, also print the elements with original index")
ogl = ['red', 'green', 'white', 'black']
for i, el in reversed(list(enumerate(ogl))):
    print(i, el)
    
print("program to move a specified element in a given list")
ogl=['red', 'green', 'white', 'black', 'orange']
ogl.append(ogl.pop(ogl.index("white")))
print(ogl)

print("program to compute the average of nth elements in a given list of lists with different lengths")
nums = [[0, 1, 2],
       [2, 3, 4],
       [3, 4, 5, 6],
       [7, 8, 9, 10, 11],
       [12, 13, 14]]

print("Original list:")
print(nums)
def get_avg(x):
    x = [i for i in x if i is not None]
    return sum(x, 0.0) / len(x)
result = map(get_avg, it.zip_longest(*nums))
print("\nAverage of n-th elements in the said list of lists with different lengths:")
print(list(result))

print("program to compare two given lists and find the indices of the values present in both lists")
nums1 = [1, 2, 3, 4, 5 ,6]
nums2 = [7, 8, 5, 2, 10, 12]
nums2 = set(nums2)
rec = [i for i, el in enumerate(nums1) if el in nums2]
print(rec)

print("program to convert a given unicode list to a list contains strings")
ogl = [u'S001', u'S002', u'S003', u'S004']
result = [str(x) for x in ogl]
print(result)

print("program to pair up the consecutive elements of a given list")
ogl = [1, 2, 3, 4, 5, 6]
result = [[ogl[i], ogl[i + 1]] for i in range(len(ogl) - 1)]
print(result)

print("program to check if a given string contains an element, which is present in a list")
str1 = "https://www.w3resource.com/python-exercises/list/"
lst = ['.com', '.edu', '.tv'] 
res = [el for el in lst if(el in str1)]
print(bool(res))

print("program to find the indexes of all None items in a given list")
ogl = [1, None, 5, 4, None, 0, None, None]
ind = [i for i in range(len(ogl)) if ogl[i] == None]
print(ind)

print("program to join adjacent members of a given list")
ogl = ['1', '2', '3', '4', '5', '6', '7', '8']
res = [x+y for x,y in zip(ogl[::2],ogl[1::2])]
print(res)

print("program to check if first digit/character of each element in a given list is same or not")
ogl = [1234, 122, 1984, 19372, 100]
res = all(str(x)[0] == str(ogl[0])[0] for x in ogl)
print(res)

print("program to find the indices of elements of a given list, greater than a specified value")
ogl = [1234, 1522, 1984, 19372, 1000, 2342, 7626]
res = [i for i in range(len(ogl)) if ogl[i] > 3000]
print(res)

print("program to remove additional spaces in a given list")
ogl = ['abc ', ' ', ' ', 'sdfds ', ' ', ' ', 'sdfds ', 'huy']
result =[]
for i in ogl:
    j = i.replace(' ','')
    result.append(j)
print(result)

print("program to find the common tuples between two given lists")
list1 =  [('red', 'green'), ('black', 'white'), ('orange', 'pink')] 
list2 =  [('red', 'green'), ('orange', 'pink')]
res = set(list1).intersection(list2)
print(res)

print("program to sum the first number with the second and divide it by 2, then sum the second with the third and divide by 2, and so on")
ogl = [1, 2, 3, 4, 5, 6, 7]
res = [(x + y) / 2.0 for (x, y) in zip(ogl[:-1], ogl[1:])]
print(res)

print("")