'''
Created on Feb 3, 2021

@author: navinnagrani
'''
print("Hello Wolrd")
assert (1==1)

def addTwo(a,b):
    print(a+b)
addTwo(1, 2)

s = "Lars"
x = 1
y=4
z=x+y
print(z , s)

x = 'len'
print(x[len(x*2)- 5])


input_str = "bmaunmdbraai"
message1 = input_str[0:-1:2]
message2 = input_str[1:len(input_str):2]
print(message1.strip('#') + "," + message2.strip('#'))