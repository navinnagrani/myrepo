import React, { Component } from 'react';

export default class Home extends Component {

    // constructor(props) {
    //     super(props);
    // }
    render() {
        return (
            <div>
                <ul id="dropdown1" class="dropdown-content">
                    <li><a href="#!">one</a></li>
                    <li><a href="#!">two</a></li>
                    <li class="divider"></li>
                    <li><a href="#!">three</a></li>
                </ul>
                <nav>
                    <div class="nav-wrapper">
                        <ul id="nav-mobile" class="right hide-on-med-and-down">
                            <li><a href="sass.html">Dashboard</a></li>
                            <li><a href="badges.html">Library</a></li>
                            <li><a href="collapsible.html">Connections</a></li><li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Profile<i class="material-icons right">arrow_drop_down</i></a></li>
                            
                        </ul>
                    </div>
                </nav>
            </div>
        )
    }
}