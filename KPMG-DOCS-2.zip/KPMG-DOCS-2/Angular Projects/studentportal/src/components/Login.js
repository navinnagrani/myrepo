import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {Redirect} from 'react-router-dom';
import Home from './Home';


export default class Login extends Component {
    constructor(props) {
        super(props);
        console.log(props);
        this.state = {
          condition: false
        };
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(condition) {
      this.setState( {condition} )
    }

    onSubmit = () => {
        if(true){
            this.props.history.push('/home/');
        }
     }
    render() {
        const { condition } = this.state;
            return ( 
                
                <div className="row">
                    <div className="col s12 m6">
                        <div className="card blue-grey darken-1">
                            <div className="card-content white-text">
                                <div className="input-field col s6">
                                    <input ref="firstName" type="text" className="validate" />
                                    <label htmlFor="firstName">UserName</label>
                                </div>
                                <div className="input-field col s6">
                                    <input ref="lastName" type="password" className="validate" />
                                    <label htmlFor="lastName">Password</label>
                                </div>
                                <div className="row">
                                    <button className="waves-effect waves-light btn" type="submit" name="action" 
                                    onClick={this.onSubmit} >Login</button>
                                    <div className="col">
                                        <button className="waves-effect waves-light btn" type="submit" name="action">New User</button>
                                    </div>
                                    {/* onClick={() => this.handleClick(true)}
                                    {condition===true ? <Home/> : null} */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
    }
}