import React from "react"
import { Route } from "react-router-dom"
import {Login,Home} from './components'

const Routes = () => {
  return (
    <div>
        <Route exact path="/" component={Login} />
        <Route path="/home" component={Home} />
    </div>
  );
}

export default Routes