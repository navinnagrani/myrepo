//import logo from './logo.svg';
import './App.css';
import Login from './components/Login';
import { BrowserRouter as Router, Route, Switch} from "react-router-dom";
import  Home   from  './components/Home';


function App() {
  return (
    <div className="container-fluid">
      <nav>
        <div className="nav-wrapper center-align">
          <a href="/" className="brand-logo center">GS POC</a>
        </div>
      </nav>
      <div className="row">
        <Router>
          <Switch>
            <Route path='/' exact={true} component={Login} />
            <Route path='/home' exact={true} component={Home} />
          </Switch>
        </Router>
      </div>
    </div>
  );
}

export default App;
