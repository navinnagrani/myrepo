import { Component, EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public sidenavToggle = new EventEmitter();
  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  goToProducts() {
    this.router.navigate(["/products"])
  }
  goToLogin() {
    this.router.navigate(["/login"])
  }
  goToSupport(){
    this.router.navigate(["/support"])
  }
}
