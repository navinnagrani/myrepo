import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotificationService } from 'src/app/services/notification.service';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  cartItems = []
  cartTotal = 0
  constructor(public dialogRef: MatDialogRef<CartComponent>, @Inject(MAT_DIALOG_DATA) public data: any,private notifyService : NotificationService) {
  }

  ngOnInit(): void {
    this.cartItems = this.data.cartItems
    this.cartTotal = this.data.cartTotal

    for (let i in this.cartItems) {
      console.log(this.cartItems[i].productName)
    }

    console.log(this.cartTotal)
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  placeOrder() {
    this.notifyService.showSuccess("Order Placed", "Success")
    this.dialogRef.close();
  }
  private selectedLink: string = "gpay";
  setradio(e: string) {
    this.selectedLink = e;
  }
  isSelected(name: string): boolean {
    if (!this.selectedLink) { // if no radio button is selected, always return false so every nothing is shown  
      return false;
    }
    return (this.selectedLink === name); // if current radio button is selected, return true, else return false  
  }

}
