import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product';
import { MessengerService } from 'src/app/services/messenger.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { CheckoutComponent } from '../checkout/checkout.component';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems = [
    // {id:1,productId:1,productName:'Product 1',qty:4,price:100},
    // {id:2,productId:3,productName:'Product 3',qty:5,price:300},
    // {id:3,productId:2,productName:'Product 2',qty:6,price:200},
    // {id:4,productId:4,productName:'Product 4',qty:2,price:400},
  ]

  cartTotal = 0

  

  constructor(private msg:MessengerService,public dialog: MatDialog) { }

  ngOnInit(): void {
    this.msg.getMsg().subscribe( (product:Product) => {
      this.addProductToCart(product)
    })
    
  }

  proceedCheckout() {
    const dialogRef = this.dialog.open(CheckoutComponent, {
      width: '750px',
      height:'650px',
      data: {cartItems: this.cartItems, cartTotal: this.cartTotal}
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  deleteFromCart(product) {

    for(let item of this.cartItems) {
      
      if(item.productId === product.productId) {
        item.qty = item.qty - 1
        //this.cartTotal = Math.abs(this.cartTotal-(item.qty * item.price))
        
        
        // if((item.qty * item.price) === 0) {
        //   this.cartTotal = Math.abs((item.qty * item.price))
        // } else {
        //   this.cartTotal = Math.abs(this.cartTotal-(item.qty * item.price))
        // }
        
        
        // if(this.cartTotal === 0) {
        //   this.cartItems = []
        // }
      }
    }
    this.cartTotal = 0
    this.cartItems.forEach(item=>{
      this.cartTotal = Math.abs(this.cartTotal-(item.qty * item.price))
    })
  }

  addProductToCart(product: Product) {
    let productExists = false

    for(let i in this.cartItems) {
      if(this.cartItems[i].productId === product.id) {
        this.cartItems[i].qty++
        productExists = true
        break;
      }
    }

    if(!productExists) {
        this.cartItems.push({
        productId:product.id,
        productName: product.name,
        qty: 1,
        price:product.price
      })
    }

    // if(this.cartItems.length === 0) {
    //   this.cartItems.push({
    //     productId:product.id,
    //     productName: product.name,
    //     qty: 1,
    //     price:product.price
    //   })
    // } else {
    //   for(let i in this.cartItems) {
    //     if(this.cartItems[i].productId === product.id) {
    //       this.cartItems[i].qty++
    //       break;
    //     } else {
    //       this.cartItems.push({
    //         productId:product.id,
    //         productName: product.name,
    //         qty: 1,
    //         price:product.price
    //       })
    //     }
    //   }
    // }
    this.cartTotal = 0
    this.cartItems.forEach(item=>{
      this.cartTotal += (item.qty * item.price)
    })
  
  }

}
