export class Customer {
    firstName:string
    lastName:string
    mobileNumber:number
    email:string
    password:string
}
