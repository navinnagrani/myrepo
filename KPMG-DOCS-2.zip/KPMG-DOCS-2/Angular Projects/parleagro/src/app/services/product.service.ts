import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Customer } from '../models/customer';

import { Product } from '../models/product';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private REST_API_SERVER = "http://localhost:8082";


  //Populate products from API
  /*products:Observable<Product[]> = [
    new Product(1,'Product 1','This is product 1 description.The product is really cool',100,),
    new Product(2,'Product 2','This is product 2 description.The product is really cool',200,),
    new Product(3,'Product 3','This is product 3 description.The product is really cool',300,),
    new Product(4,'Product 4','This is product 4 description.The product is really cool',400,),
    new Product(5,'Product 5','This is product 5 description.The product is really cool',500,),
    new Product(6,'Product 6','This is product 6 description.The product is really cool',600)
    // 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyCoMA6ULFMxVytm_v3HA3XQmLKx0TWH3f7g&usqp=CAU'
    // 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeEd-prhCEXRYQDMLFsoIECB9ga0Y0gd_Sdg&usqp=CAU'
  ]*/
  
  
  constructor(private httpClient: HttpClient) { }
  
  public getProducts(): Observable<Product[]> {
    //Populate products from API and return an Observable
    return this.httpClient.get<Product[]>(this.REST_API_SERVER+'/metaphor/getProducts');
    //return this.products
  }

  public createNewCustomer(customer:Customer) {
    return this.httpClient.post(this.REST_API_SERVER+'/metaphor/signup',customer)
  }

  public checkLogin(email:string,password:string) {
    let params = new HttpParams();
    params = params.append('email', email);
    params = params.append('password', password);
    return this.httpClient.get(this.REST_API_SERVER+'/metaphor/login',{params: params})
  }

}
