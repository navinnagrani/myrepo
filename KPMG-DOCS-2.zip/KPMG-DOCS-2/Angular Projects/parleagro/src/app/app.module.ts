import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {DemoMaterialModule} from './demomaterial/demomaterial.module';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { FooterComponent } from './footer/footer.component';
import { FiltersComponent } from './products/filters/filters.component';
import { ProductlistComponent } from './products/productlist/productlist.component';
import { CartComponent } from './products/cart/cart.component';
import { CartitemComponent } from './products/cart/cartitem/cartitem.component';
import { ProductitemComponent } from './products/productlist/productitem/productitem.component';
import { SupportComponent } from './support/support.component';
import { CheckoutComponent } from './products/checkout/checkout.component';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    ProductsComponent,
    FooterComponent,
    FiltersComponent,
    ProductlistComponent,
    CartComponent,
    CartitemComponent,
    ProductitemComponent,
    SupportComponent,
    CheckoutComponent
  ],
  imports: [
    ToastrModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,

    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatSlideToggleModule,
    DemoMaterialModule,

    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
