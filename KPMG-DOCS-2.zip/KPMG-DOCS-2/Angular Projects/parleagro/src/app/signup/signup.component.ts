import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../models/customer';
import { NotificationService } from '../services/notification.service';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  customer:Customer = new Customer()

  constructor(private productService:ProductService,private notifyService : NotificationService
    ,private router: Router) { }

  ngOnInit(): void {
    
  }

  signup(customer:Customer) {
    this.productService.createNewCustomer(customer).subscribe((data) => {
      if(data === true) {
        this.notifyService.showSuccess("Welcome to Metaphor.", "Your profile is created")
        this.router.navigate(["/login"])
      }
    })
  }

  goToHome() {
    this.router.navigate(["/login"])
  }

}
