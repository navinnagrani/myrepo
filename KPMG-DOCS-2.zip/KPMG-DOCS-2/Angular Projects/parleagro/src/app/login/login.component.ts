import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService } from '../services/notification.service';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email:string
  password:string
  constructor(private router: Router,private productService:ProductService,private notifyService : NotificationService) { 
    
  }

  ngOnInit(): void {
  }

  goToSignup() {
    this.router.navigate(["/signup"])
  }

  goToProducts(event) {
    if(event.keyCode===13 || event.type==="click") {
      this.productService.checkLogin(this.email,this.password).subscribe((data) => {
        if(data===true) {
          this.router.navigate(["/products"])
        } else{
          this.notifyService.showError("Wrong Credentials", "Kindly enter correct details")
        }
      })
    } 
  }

}
