import React, { Component } from 'react';
import Education from './Education';

export default class AddEducationForm extends Component {
    constructor(props) {
        super(props);
        this.state = { value: [], count: 1 };
    }

    addMore() {
        this.setState({ count: this.state.count + 1 })
    }

    displayForm() {
        let forms = [];
        for (let i = 0; i < this.state.count; i++) {
            forms.push(
                <div key={i}>
                    <Education value={this.state.value[i] || ''} />
                </div>
            )
        }
        return forms || null;
    }
    render() {
        return (
            <div className="row">
                <button className="waves-effect waves-light btn"
                type="submit" name="action" onClick={this.addMore.bind(this)}>Add Education</button>
            </div>
        );
    }
}