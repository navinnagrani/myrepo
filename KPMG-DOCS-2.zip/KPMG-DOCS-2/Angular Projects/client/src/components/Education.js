import React, {Component} from 'react';

export default class Education extends Component {
    state= {showForm: false}

    showForm = () => {
        this.state.showForm = false;
        return (
            <div className="row">
                <form className="col s12">
                <div className="row">
                    <div className="input-field col s12">
                        <input ref="email" type="email" className="validate" />
                        <label htmlFor="email">University/College</label>
                    </div>
                    <div className="input-field col s12">
                        <input ref="email" type="email" className="validate" />
                        <label htmlFor="email">Stream</label>
                    </div>
                    <div className="input-field col s12">
                        <input ref="email" type="email" className="validate" />
                        <label htmlFor="email">Percentage/CGPA</label>
                    </div>
                </div>
                </form>
            </div>
        );
    }

    render() {
        return (
            <div className="row">
                <button  className="waves-effect waves-light btn" 
                onClick={() => this.setState({showForm: true}) }>Add Education</button>
                {this.state.showForm ? this.showForm() : null}
            </div>
        )
    }
}