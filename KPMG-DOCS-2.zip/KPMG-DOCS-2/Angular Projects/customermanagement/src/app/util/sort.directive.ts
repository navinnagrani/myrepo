import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';
import { Customer } from '../model/customer';
import { Sort } from './sort';

@Directive({
  selector: '[appSort]'
})
export class SortDirective {

  @Input() appSort: Customer[]

  constructor(private renderer:Renderer2,private targetEle:ElementRef) { }

  @HostListener("click")
  sortData() {
    const sort = new Sort()
    const ele = this.targetEle.nativeElement
    const order = ele.getAttribute("data-order")
    const type = ele.getAttribute("data-type")
    const property = ele.getAttribute("data-name")

    if(order === "asc") {
      this.appSort.sort(sort.startSort(property,order,type))
      ele.setAttribute("data-order","desc")
    } else {
      this.appSort.sort(sort.startSort(property,order,type))
      ele.setAttribute("data-order","asc")
    }

  }

}
