import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { Employee } from 'src/app/model/employee';
import { CustomerService } from 'src/app/services/customer.service';
import { MessageService } from 'src/app/services/message.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-customerrepo',
  templateUrl: './customerrepo.component.html',
  styleUrls: ['./customerrepo.component.css']
})
export class CustomerrepoComponent implements OnInit {
  customerList:Customer[] = []
  customer:Customer
  emp:Employee
  updatedCustomer:Customer = new Customer()
  showInterested:boolean = false
  customerListInterested:Customer[] = []
  showFullTable:boolean = true

  page = 1;
  pageSize = 8;
  collectionSize:number=0;

  constructor(private customerService:CustomerService,
    private messageService:MessageService,private notifyService : NotificationService) {}

  ngOnInit(): void {
    this.getCustomers()
    this.emp = this.messageService.getEmployee();
  }

  getCustomers(){
    this.customerService.getCustomers().subscribe((data: Customer[]) => {
      this.customerList = data;
      this.collectionSize = this.customerList.length
      this.customerList = this.customerList
      .map((customer,i)=>({id:i+1,...customer}))
      .slice((this.page-1) * this.pageSize,(this.page-1)*this.pageSize+this.pageSize)
    })
  }
  
  onChange(eventValue) {
    console.log(eventValue)
    this.showInterested = true
    this.showFullTable = false
    if(eventValue === "Interested") {
      this.customerListInterested = this.customerList.filter(item=>item.interest==="INTERESTED")
    } else {
      this.customerListInterested = this.customerList.filter(item=>item.interest==="NOT INTERESTED")
    }
  }
  
  update(customer:Customer) {
    this.messageService.setCustomer(customer)
  }

  updateCustomer(customerUpdated:Customer){
    this.customer = this.messageService.getCustomer()
    customerUpdated.id = this.customer.id
    if(this.customer.id === customerUpdated.id) {
      this.customer.name = customerUpdated.name
      this.customer.email = customerUpdated.email
      this.customer.mobileNumber = customerUpdated.mobileNumber
      this.customer.address = customerUpdated.address
      this.customerService.updateCustomer(this.customer,this.customer.id).subscribe((data) => {
        console.log(data)
        if(data != null) {
          this.notifyService.showSuccess("Customer Updated!!","Success")
        }
      })
    }
  }
}
