import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/services/customer.service';
import { NotificationService } from 'src/app/services/notification.service';



@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})

export class AddcustomerComponent implements OnInit {

  customer:Customer = new Customer()
  isChecked : boolean = false;
  currentDateTime

  constructor(private router:Router,private notifyService : NotificationService,
    private customerService: CustomerService,public datepipe: DatePipe) { 
      this.currentDateTime = this.datepipe.transform((new Date),'dd-MM-yyyy h:mm:ss')
    }

  ngOnInit(): void {
  }

  goToHome() {
    this.router.navigate(["/home"])
  }

  saveCustomer(customer:Customer) {
    if(this.isChecked) {
      customer.interest = "INTERESTED"
    } else {
      customer.interest = "NOT INTERESTED"
    }
    customer.createdDateTime = this.currentDateTime
    this.customerService.createNewCustomer(customer).subscribe((data) => {
      console.log(data)
      if(data != null) {
        this.notifyService.showSuccess("New Customer saved!!","Success")
      }
    })
  }

  

  

}
