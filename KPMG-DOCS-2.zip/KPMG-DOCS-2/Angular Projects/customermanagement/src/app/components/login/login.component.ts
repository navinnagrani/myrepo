import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Employee } from 'src/app/model/employee';
import { NotificationService } from 'src/app/services/notification.service';
import { CustomerService } from 'src/app/services/customer.service';
import { MessageService } from 'src/app/services/message.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form = new FormGroup({
    email: new FormControl('', [Validators.required, 
      Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    password: new FormControl('',Validators.required)
  });

  employee: Employee = new Employee();

  constructor(private router: Router,private notifyService:NotificationService,private customerService:CustomerService,private msgService:MessageService) { }

  ngOnInit(): void {
  }

  goToHome() {
    this.employee.email = this.Email.value
    this.employee.password = this.Password.value

    this.customerService.checkLogin(this.employee).subscribe((data: Employee) => {
      
      this.msgService.setEmployee(data)
      sessionStorage.setItem("email",data.email);
      sessionStorage.setItem("emp",JSON.stringify(data))
      this.router.navigate(["/home"])
    },(error)=>{
      if(error.status === 404) {
        this.notifyService.showError("No employee found","Enter correct creds")
      }
    })
  }

  get Email() {
    return this.form.get('email');
  }

  get Password() {
    return this.form.get('password');
  }

}
