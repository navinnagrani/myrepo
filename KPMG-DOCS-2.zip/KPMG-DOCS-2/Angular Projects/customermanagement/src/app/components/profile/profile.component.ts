import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { CustomerService } from 'src/app/services/customer.service';
import { MessageService } from 'src/app/services/message.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  emp: Employee;
  password = 'password';
  showPassword:boolean
  show:boolean = false;;
  constructor(private msgService: MessageService, private customerService: CustomerService, private notifyService: NotificationService) { }

  ngOnInit(): void {

    this.emp = this.msgService.getEmployee()
    if(this.emp === undefined) {
      this.emp = JSON.parse(sessionStorage.getItem('emp'))
    }
    // this.customerService.getEmployee(this.emp.id).subscribe((data: Employee) => {
    //   console.log(data)
    // })
  }

  updateEmployee(emp: Employee) {
    this.customerService.updateEmployee(emp,this.emp.id).subscribe((data: Employee) => {
      if(emp.password === data.password) {
        this.notifyService.showSuccess("Profile updated","Success")
      }
    },(error)=> {
      if(error.status === 304) {
        this.notifyService.showError("Cannot update details now","Error")
      }
    })
  }

  onClick() {
    if (this.password === 'password') {
      this.password = 'text';
      this.show = true;
    } else {
      this.password = 'password';
      this.show = false;
    }
  }
  

}
