import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  isEmpLoggedIn: boolean = false;
  emp:Employee;
  constructor(private router: Router,public customerService:CustomerService) { }

  ngOnInit(): void {
    this.isEmpLoggedIn = this.customerService.isEmployeeLoggedIn();
    this.emp = JSON.parse(sessionStorage.getItem('emp'));
  }

  goToLogin(){
    this.router.navigate(["/login"])
  }

  logOut() {
    sessionStorage.removeItem('email')
    sessionStorage.clear();
    this.goToLogin()
  }

}
