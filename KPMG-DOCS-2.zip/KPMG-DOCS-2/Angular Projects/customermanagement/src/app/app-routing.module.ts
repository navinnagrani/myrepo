import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcustomerComponent } from './components/addcustomer/addcustomer.component';
import { CustomerrepoComponent } from './components/customerrepo/customerrepo.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { ProfileComponent } from './components/profile/profile.component';
import { AuthguardService } from './services/authguard.service';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'' , redirectTo:'/login', pathMatch:'full'},
  {path:'home', component:HomeComponent,canActivate:[AuthguardService]},
  {path:'addcustomer',component:AddcustomerComponent,canActivate:[AuthguardService]},
  {path:'customerrepo',component:CustomerrepoComponent,canActivate:[AuthguardService]},
  {path:'profile',component:ProfileComponent,canActivate:[AuthguardService]}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
