import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  cus:Customer = new Customer();
  emp:Employee;
  constructor() { }

  
  setCustomer(customer:Customer) {
    this.cus = customer
  }

  getCustomer() {
    return this.cus
  }

  setEmployee(emp:Employee) {
    this.emp = emp;
  }

  getEmployee() {
    return this.emp
  }

}
