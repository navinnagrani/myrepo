import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { CustomerService } from './customer.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate {

  constructor(private router:Router,private custService:CustomerService) { }

  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot) {
    if(this.custService.isEmployeeLoggedIn()) {
      return true;
    }
    this.router.navigate(['login']);
    return false;
  }
}
