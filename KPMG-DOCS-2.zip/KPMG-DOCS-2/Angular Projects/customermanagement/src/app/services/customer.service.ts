import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Customer } from '../model/customer';
import { Employee } from '../model/employee';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization':'Basic Y3JtbWFuYWdlbWVudDpwYXNzd29yZA=='
  })
};

const baseUrl = 'http://localhost:8080/crm';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private REST_API_SERVER = "http://localhost:8080";
  constructor(private httpClient: HttpClient) { }

  public createNewCustomer(customer:Customer) {
    return this.httpClient.post(baseUrl+'/customer',customer,httpOptions)
  }

  public getCustomers(): Observable<Customer[]> {
    return this.httpClient.get<Customer[]>(baseUrl+'/getCustomers',httpOptions);
  }

  public updateCustomer(customer:Customer,customerId) {
    return this.httpClient.patch(`${baseUrl}/updatecustomer/${customerId}`,customer,httpOptions)
  }

  public checkLogin(employee:Employee) {
    return this.httpClient.post(baseUrl+'/checkLogin',employee,httpOptions);
  }

  public getEmployee(id:number) {
    return this.httpClient.get(`${baseUrl}/getEmployee/${id}`,httpOptions)
  }

  public updateEmployee(employee:Employee,employeeId) {
    return this.httpClient.patch(`${baseUrl}/updateemployee/${employeeId}`,employee,httpOptions)
  }

  public isEmployeeLoggedIn() {
    let emp = sessionStorage.getItem('email')
    return !(emp===null)
  }

  
}
