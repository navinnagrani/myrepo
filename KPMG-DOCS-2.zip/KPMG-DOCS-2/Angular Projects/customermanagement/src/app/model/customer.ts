export class Customer {
    id:number
    name:string
    email:string
    mobileNumber:number
    address:string
    interest:string
    createdDateTime:Date
}
