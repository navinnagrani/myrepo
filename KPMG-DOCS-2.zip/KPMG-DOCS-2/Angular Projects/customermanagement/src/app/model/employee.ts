export class Employee {
    id:number;
    name : string;
    email:string;
    password : string ;  
    role : string;
    imgUrl:string;
}
